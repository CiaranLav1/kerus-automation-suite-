package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 13/05/16.
 * Setting up the Study Home Page object.
 */
public class StudyHomePage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public StudyHomePage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("studyHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "studiesLink")
    private WebElement allStudiesBreadcrumb;

    @FindBy(how = How.ID, using = "currentStudy")
    private WebElement currentStudyBreadcrumb;

    /**
     * Locators for page and section headers.
     */
    @FindBy(how = How.ID, using = "studyHeader")
    private WebElement studyHeader;

    @FindBy(how = How.ID, using = "stageAHeader")
    private WebElement stageAHeader;

    @FindBy(how = How.ID, using = "stageBHeader")
    private WebElement stageBHeader;

    /**
     * Locators for Edit Study Details section
     */
    @FindBy(how = How.ID, using = "edit")
    private WebElement editStudyDetailsButton;

    @FindBy(how = How.ID, using = "studyLabel")
    private WebElement studyLabelFieldLabel;

    @FindBy(how = How.ID, using = "study.label")
    private WebElement studyLabelTextbox;

    @FindBy(how = How.ID, using = "studyDescription")
    private WebElement studyDescriptionFieldLabel;

    @FindBy(how = How.ID, using = "study.description")
    private WebElement studyDescriptionTextbox;

    @FindBy(how = How.ID, using = "saveStudy")
    private WebElement saveButton;

    @FindBy(how = How.ID, using = "reset")
    private WebElement cancelButton;

    /**
     * Locators for Stage A buttons.
     */
    @FindBy(how = How.ID, using = "sampleSizeButton")
    private WebElement defineSampleSizeButton;

    @FindBy(how = How.ID, using = "groupsButton")
    private WebElement defineGroupsButton;

    /**
     * Locators for Stage B buttons.
     */
    @FindBy(how = How.ID, using = "defineAllocationsButton")
    private WebElement defineAllocationsButton;

    @FindBy(how = How.ID, using = "DefineVariablesButton")
    private WebElement defineVariablesButton;

    @FindBy(how = How.ID, using = "defineRelationsButton")
    private WebElement defineRelationsButton;

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean getHelpIcon() { return helpIcon.isDisplayed(); }

    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public String getCurrentStudyBreadcrumb() {
        return currentStudyBreadcrumb.getText();
    }

    /**
     * Get the header text.
     */
    public String getStudyHomeHeader() {
        return studyHeader.getText();
    }

    public String getStageAHeaderHeader() {
        return stageAHeader.getText();
    }

    public String getStageBHeaderHeader() {
        return stageBHeader.getText();
    }

    /**
     * Get the edit information text entries.
     */
    public String getEditStudyDetailsButton() {
        return editStudyDetailsButton.getText();
    }

    public String getStudyLabelLabelText() {
        return studyLabelFieldLabel.getText();
    }

    public String getStudyLabelFieldText() {
        return studyLabelTextbox.getAttribute("value");
    }

    public String getStudyDescriptionLabelText() {
        return studyDescriptionFieldLabel.getText();
    }

    public String getStudyDescriptionFieldText() {
        return studyDescriptionTextbox.getAttribute("value");
    }

    public String getCancelButton() {
        return cancelButton.getText();
    }

    public String getSaveButton() {
        return saveButton.getText();
    }

    /**
     * Get the dashboard button text.
     */
    public String getDefineSampleSizesButton() {
        return defineSampleSizeButton.getText();
    }

    public String getDefineGroupsButton() {
        return defineGroupsButton.getText();
    }

    public String getDefineAllocationsButton() {
        return defineAllocationsButton.getText();
    }

    public String getDefineVariablesButton() {
        return defineVariablesButton.getText();
    }

    public String getDefineRelationsButton() {
        return defineRelationsButton.getText();
    }

    /**
     * Methods to click the dashboard buttons.
     */
    public void clickDefineSampleSizesButton() {
        defineSampleSizeButton.click();
    }

    public void clickDefineGroupsButton() {
        defineGroupsButton.click();
    }

    public void clickDefineAllocationsButton() {
        defineAllocationsButton.click();
    }

    public void clickDefineVariablesButton() {
        defineVariablesButton.click();
    }

    public void clickDefineRelationsButton() {
        defineRelationsButton.click();
    }

    /**
     * Method to click the Edit Study Details button.
     */
    public void clickEditStudyDetailsButton() {
        editStudyDetailsButton.click();
    }

    /**
     * Method to click the save button.
     */
    public void clickSaveButton() {
        saveButton.click();
    }

    /**
     * Method to click the cancel button.
     */
    public void clickCancelButton() {
        cancelButton.click();
    }

    /**
     * Method to click the Home icon.
     */
    public void clickHomeIcon() {
        homeIcon.click();
    }

    /**
     * Method to click the logout link.
     */
    public void clickLogoutIcon() {
        logoutIcon.click();
    }

    /**
     * Method to get the URL of the page.
     */
    public String getURL() {
        return driver.getCurrentUrl();
    }
}
