package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 12/05/16.
 * Setting up the Edit Project page object.
 */
public class EditProjectDetailsPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public EditProjectDetailsPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("projectLabelHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "currentproject")
    private WebElement currentProjectBreadcrumb;

    /**
     * Page header.
     */
    @FindBy(how = How.ID, using = "projectLabelHeader")
    private WebElement editProjectHeader;

    /**
     * Locators for buttons on the page,
     * NOTE: these are not always visible.
     */
    @FindBy(how = How.ID, using = "edit")
    private WebElement editProjectButton;

    @FindBy(how = How.ID, using = "saveProject")
    private WebElement saveProjectButton;

    @FindBy(how = How.ID, using = "reset")
    private WebElement cancelButton;

    /**
     * Locators for the edit Project fields
     * and field labels.
     */
    @FindBy(how = How.ID, using = "projectLabel")
    private WebElement projectLabelFieldLabel;

    @FindBy(how = How.ID, using = "label")
    private WebElement projectLabelTextbox;

    @FindBy(how = How.ID, using = "projectDescription")
    private WebElement projectDescriptionFieldLabel;

    @FindBy(how = How.ID, using = "description")
    private WebElement projectDescriptionTextbox;

    @FindBy(how = How.ID, using = "seedLabel")
    private WebElement seedFieldLabel;

    @FindBy(how = How.ID, using = "project.seed")
    private WebElement seedNumberbox;

    @FindBy(how = How.ID, using = "simulationsNumberLabel")
    private WebElement simulationsFieldLabel;

    @FindBy(how = How.ID, using = "numSimulations")
    private WebElement simulationsNumberbox;

    /**
     * Locators for the dashboard buttons.
     */
    @FindBy(how = How.ID, using = "studiesButton")
    private WebElement studiesButton;

    @FindBy(how = How.ID, using = "subgroupBuilderButton")
    private WebElement subgroupBuilderButton;

    @FindBy(how = How.ID, using = "sapButton")
    private WebElement statisticalAnalysisPlanButton;

    @FindBy(how = How.ID, using = "oeButton")
    private WebElement objectiveEvaluationButton;

    @FindBy(how = How.ID, using = "simButton")
    private WebElement simulateButton;

    @FindBy(how = How.ID, using = "outputButton")
    private WebElement outputButton;

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public boolean getHelpIcon() { return helpIcon.isDisplayed(); }

    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    /**
     * Get the text in the page header.
     */
    public String getEditProjectPageHeader() {
        return editProjectHeader.getText();
    }

    /**
     * Get the text for buttons on the page.
     */
    public String getEditProjectButton() {
        return editProjectButton.getText();
    }

    public String getSaveProjectButton() {
        return saveProjectButton.getText();
    }

    public String getCancelProjectButton() {
        return cancelButton.getText();
    }

    /**
     * Get the text for field labels in the
     * create project section and check the
     * field default for simulations.
     */
    public String getProjectLabelLabelText() {
        return projectLabelFieldLabel.getText();
    }

    public String getProjectLabelFieldText() {
        return projectLabelTextbox.getAttribute("value");
    }

    public String getProjectDescriptionLabelText() {
        return projectDescriptionFieldLabel.getText();
    }

    public String getProjectDescriptionFieldText() {
        return projectDescriptionTextbox.getAttribute("value");
    }

    public String getSeedLabelText() {
        return seedFieldLabel.getText();
    }

    public String getSeedFieldText() {
        return seedNumberbox.getAttribute("value");
    }


    public String getSimulationsLabelText() {
        return simulationsFieldLabel.getText();
    }

    public String getSimulationsFieldText() {
        return simulationsNumberbox.getAttribute("value");
    }

    /**
     * Methods to get the text on the dashboard
     * buttons.
     */
    public String getStudiesButton() {
        return studiesButton.getText();
    }

    public String getSubgroupBuilderButton() {
        return subgroupBuilderButton.getText();
    }

    public String getStatisticalAnalysisPlanButton() {
        return statisticalAnalysisPlanButton.getText();
    }

    public String getObjectiveEvaluationButton() {
        return objectiveEvaluationButton.getText();
    }

    public String getSimulateButton() {
        return simulateButton.getText();
    }

    public String getOutputButton() {
        return outputButton.getText();
    }

    /**
     * Methods to click each of the
     * dashboard buttons.
     */
    public void clickStudiesButton() {
        studiesButton.click();
    }

    public void clickSubgroupBuilderButton() {
        subgroupBuilderButton.click();
    }

    public void clickStatisticalAnalysisPlanButton() {
        statisticalAnalysisPlanButton.click();
    }

    public void clickObjectiveEvaluationButton() {
        objectiveEvaluationButton.click();
    }

    public void clickOutputButton() { outputButton.click();
    }

    public void clickSaveProjectButton() { saveProjectButton.click(); }

    /**
     * Method to click the Home link.
     */
    public void clickHomeIcon() {
        homeIcon.click();
    }

    /**
     * Method to click the logout link.
     */
    public void clickLogoutIcon() {
        logoutIcon.click();
    }

    /**
     * Method to click the Edit Project Details button.
     */
    public void clickEditProjectDetailsButton() {
        editProjectButton.click();
    }
}
