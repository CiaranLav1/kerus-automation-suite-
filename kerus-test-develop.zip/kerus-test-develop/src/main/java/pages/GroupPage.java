package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;
import java.util.concurrent.TimeUnit;

import utilities.Table;

/**
 * Created by heather.reid on 13/05/16.
 * Setting up the page object for the Group
 * page.
 */
public class GroupPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public GroupPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("groupListHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "studiesLink")
    private WebElement allStudiesBreadcrumb;

    @FindBy(how = How.ID, using = "cStudiesLink")
    private WebElement currentStudyBreadcrumb;

    @FindBy(how = How.ID, using = "groupsLink")
    private WebElement groupsBreadcrumb;

    /**
     * Locator for the group form header.
     */
    @FindBy(how = How.ID, using = "groupHeader")
    private WebElement groupsHeader;

    /**
     * Locators for fields and field labels.
     */
    @FindBy(how = How.ID, using = "labeldescription")
    private WebElement groupLabelFieldLabel;

    @FindBy(how = How.ID, using = "label")
    private WebElement groupLabelTextbox;

    @FindBy(how = How.ID, using = "descriptionLabel")
    private WebElement groupDescriptionFieldLabel;

    @FindBy(how = How.ID, using = "description")
    private WebElement groupDescriptionTextbox;

    @FindBy(how = How.ID, using = "valuerankLabel")
    private WebElement valueRankFieldLabel;

    @FindBy(how = How.ID, using = "valuerank")
    private WebElement valueRankTextbox;

    @FindBy(how = How.ID, using = "controlLabel")
    private WebElement controlFieldLabel;

    @FindBy(how = How.ID, using = "control")
    private WebElement controlCheckbox;

    /**
     * Locator for the add button.
     */
    @FindBy(how = How.ID, using = "saveGroup")
    private WebElement addButton;

    /**
     * Locator for the group list header.
     */
    @FindBy(how = How.ID, using = "groupListHeader")
    private WebElement groupListHeader;

    /**
     * Locator for the table.
     */
    @FindBy(how = How.ID, using = "groups")
    private WebElement groupTable;

    @FindBy(how = How.ID, using = "groups")
    private WebElement groupTable2;

    /**
     * Locators for the modal.
     */
    @FindBy(how = How.XPATH, using = "html/body/div[4]/div/div/div[1]/h3")
    private WebElement deleteModalHeader;

    @FindBy(how = How.XPATH, using = "html/body/div[4]/div/div/div[2]/p")
    private WebElement deleteModalBody;

    @FindBy(how = How.XPATH, using = "html/body/div[4]/div/div/div[3]/button[2]")
    private WebElement deleteModalOK;

    @FindBy(how = How.XPATH, using = "html/body/div[4]/div/div/div[3]/button[1]")
    private WebElement deleteModalCancel;

    @FindBy(how = How.NAME, using = "Delete")
    private WebElement deleteGroupButton;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public String getCurrentStudyBreadcrumb() {
        return currentStudyBreadcrumb.getText();
    }

    public String getGroupsBreadcrumb() {
        return groupsBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean getHelpIcon() { return helpIcon.isDisplayed(); }

    /**
     * Get text for the field labels.
     */
    public String getGroupLabelLabel() {
        return groupLabelFieldLabel.getText();
    }

    public String getGroupDescriptionLabel() {
        return groupDescriptionFieldLabel.getText();
    }

    public String getGroupValueRankLabel() {
        return valueRankFieldLabel.getText();
    }

    public String getGroupControlLabel() {
        return controlFieldLabel.getText();
    }

    /**
     * Get text for the add button.
     */
    public String getAddButton() {
        return addButton.getText();
    }

    /**
     * Get text for the group form header and group list header.
     */
    public String getGroupListHeader() {
        return groupListHeader.getText();
    }

    public String getGroupHeader() {
        return groupsHeader.getText();
    }

    /**
     * Get the text from the column headers.
     */
    public List<String> getTableColumnHeaders() {
        Table allGroupsTable = new Table(groupTable);
        return allGroupsTable.readAllColumnHeaders();
    }

    /**
     * Get text from the table entries
     * for each group that was added.
     */
    public String getColumnEntry(String header, String cellValue) {
        try {
            Table allGroupsTable = new Table(groupTable);
            return allGroupsTable.findCellByColumnAndKnownValue(header, cellValue).getText();
        } catch (org.openqa.selenium.StaleElementReferenceException e) {
            Table allGroupsTable = new Table(groupTable2);
            return allGroupsTable.findCellByColumnAndKnownValue(header, cellValue).getText();
        }
    }

    public String getControlEntry(String header, String cellValue, String knownCellHeader) throws Exception {
        try {
            Table allGroupsTable = new Table(groupTable);
            return allGroupsTable.findOnlyLinkButtonInCell(header, cellValue, knownCellHeader).getText();
        } catch (org.openqa.selenium.StaleElementReferenceException e) {
            Table allGroupsTable = new Table(groupTable2);
            return allGroupsTable.findOnlyLinkButtonInCell(header, cellValue, knownCellHeader).getText();
        }
    }

    /**
     * Get the text from the delete modal.
     */
    public String getDeleteModalHeader() {
        return deleteModalHeader.getText();
    }

    public String getDeleteModalBody() {
        return deleteModalBody.getText();
    }

    public String getDeleteModalOK() {
        return deleteModalOK.getText();
    }

    public String getDeleteModalCancel() {
        return deleteModalCancel.getText();
    }

    /**
     * Click the add button.
     */
    public void clickAddButton() {
        addButton.click();
    }

    /**
     * Click the delete button for the
     * a group that was added.
     */
    public void clickDeleteGroupButton(String buttonColumnHeader, String groupLabel, String labelColumnHeader) throws InterruptedException {
        Table allGroupsTable = new Table(groupTable);

       allGroupsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 2).click();
    }

    public void clickDeleteModalOK() {
        deleteModalOK.click();
    }

    /**
     * Check that the delete button for the table
     * row is displayed in the Actions column
     */
    public Boolean deleteButtonTableEntryDisplayed(String buttonColumnHeader, String groupLabel, String labelColumnHeader) {
        try {
            Table allGroupsTable = new Table(groupTable);
            return allGroupsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        } catch (org.openqa.selenium.StaleElementReferenceException e) {
            Table allGroupsTable = new Table(groupTable2);
            return allGroupsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 2).isDisplayed();
        }
    }

    /**
     * Check that the edit button for the table row is
     * displayed in the actions column.
     */
    public Boolean editButtonTableEntryDisplayed(String buttonColumnHeader, String groupLabel, String labelColumnHeader) {
        try {
            Table allGroupsTable = new Table(groupTable);
            return allGroupsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        } catch (org.openqa.selenium.StaleElementReferenceException e) {
            Table allGroupsTable = new Table(groupTable2);
            return allGroupsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 1).isDisplayed();
        }
    }

    /**
     * Enters the group information into the relevant fields.
     * @param groupLabel Required string
     * @param groupDescription String, possible to be empty from user
     * @param valueRank Number as a string
     * @param control true/false string
     */
    public void enterGroupDetails(String groupLabel, String groupDescription, String valueRank, String control) {
        groupLabelTextbox.sendKeys(groupLabel);

        groupDescriptionTextbox.sendKeys(groupDescription);

        valueRankTextbox.sendKeys(valueRank);

        if (control == "true") {
            // Click the control group
            controlCheckbox.click();
        }
    }

    /**
     * Method to click the Current Study breadcrumb.
     */
    public void clickCurrentStudyBreadcrumb() {
        currentStudyBreadcrumb.click();
    }


    public void waitUntilRowPopulates(String labelColumnHeader, final int rowCount) {
        try {
            new FluentWait<>(driver)
                    .withTimeout(60, TimeUnit.SECONDS)
                    .pollingEvery(5, TimeUnit.SECONDS)
                    .until((WebDriver d) -> {
                        Table allGroupsTable = new Table(groupTable);
                        return (allGroupsTable.readAllDataFromAColumn(labelColumnHeader).size() == rowCount);
                    });
        } catch (org.openqa.selenium.StaleElementReferenceException e) {
            new FluentWait<>(driver)
                    .withTimeout(60, TimeUnit.SECONDS)
                    .pollingEvery(5, TimeUnit.SECONDS)
                    .until((WebDriver d) -> {
                        Table allGroupsTable = new Table(groupTable2);
                        return (allGroupsTable.readAllDataFromAColumn(labelColumnHeader).size() == rowCount);
                    });
        }
    }
}