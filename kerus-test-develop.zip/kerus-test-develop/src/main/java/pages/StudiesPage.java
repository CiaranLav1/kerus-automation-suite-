package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 13/05/16.
 * Setting up the Studies Page object.
 */
public class StudiesPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public StudiesPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 25);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("projectHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "allStudies")
    private WebElement allStudiesBreadcrumb;

    /**
     * Locators for footer links.
     */
    @FindBy(how = How.ID, using = "DataTables_Table_0_previous")
    private WebElement previousLink;

    @FindBy(how = How.ID, using = "DataTables_Table_0_next")
    private WebElement nextLink;

    @FindBy(how = How.ID, using = "DataTables_Table_0_info")
    private WebElement showingEntriesText;

    /**
     * Locators for buttons on the page,
     * NOTE: these are not always visible.
     */
    @FindBy(how = How.ID, using = "addStudyForm")
    private WebElement createStudyButton;

    @FindBy(how = How.ID, using = "saveStudy")
    private WebElement addStudyButton;

    @FindBy(how = How.ID, using = "resetStudy")
    private WebElement cancelCreateStudyButton;

    /**
     * Locators for section headers.
     */
    @FindBy(how = How.ID, using = "projectHeader")
    private WebElement projectHeader;

    @FindBy(how = How.ID, using = "allstudiesHeader")
    private WebElement allStudiesHeader;

    /**
     * Locators for the All Studies section items.
     * This includes table column headers and search
     * fields.
     */
    @FindBy(how = How.ID, using = "DataTables_Table_0_length")
    private WebElement showBlockEntriesText;

    @FindBy(how = How.ID, using = "DataTables_Table_0_filter")
    private WebElement searchProjectsLabel;

    @FindBy(how = How.ID, using = "DataTables_Table_0")
    private WebElement studiesTable;

    /**
     * Need to re-locate the element because once
     * you click to add a study the form doesn't
     * disappear so the table has moved from its
     * initial location.
     */
    @FindBy(how = How.ID, using = "DataTables_Table_0")
    private WebElement studiesTable2;

    /**
     * Locators for the create Study fields
     * and field labels.
     */
    @FindBy(how = How.ID, using = "studyLabel")
    private WebElement studyLabelFieldLabel;

    @FindBy(how = How.ID, using = "study.label")
    private WebElement studyLabelTextbox;

    @FindBy(how = How.ID, using = "studyDescription")
    private WebElement studyDescriptionFieldLabel;

    @FindBy(how = How.ID, using = "study.description")
    private WebElement studyDescriptionTextbox;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean gethelpIcon() {return helpIcon.isDisplayed(); }

    /**
     * Get the text for field labels in the
     * create study section.
     */
    public String getStudyLabelLabelText() {
        return studyLabelFieldLabel.getText();
    }

    public String getStudyDescriptionLabelText() {
        return studyDescriptionFieldLabel.getText();
    }

    /**
     * Get the text for fields in the All
     * Studies section.
     */
    public String getBlockEntriesText() {
        return showBlockEntriesText.getText();
    }

    public String getSearchStudiesLabel() {
        return searchProjectsLabel.getText();
    }

    /**
     * Get column headings for the Studies table.
     */
    public List<String> getTableColumnHeaders() {
        Table allStudiesTable = new Table(studiesTable);
        return allStudiesTable.readAllColumnHeaders();
    }

    /**
     * Get table entries for the studies table.
     */
    public String getTableColumnEntry(String columnHeader, String cellValue) {
        Table allStudiesTable = new Table(studiesTable2);
        return allStudiesTable.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
    }

    /**
     * Get the text for buttons on the page.
     */
    public String getCreateStudiesButton() {
        return createStudyButton.getText();
    }

    public String getAddStudyButton() {
        return addStudyButton.getText();
    }

    public String getCancelCreateStudyButton() {
        return cancelCreateStudyButton.getText();
    }

    /**
     * Get text for headers on the page.
     */
    public String getProjectHeader() {
        return projectHeader.getText();
    }

    public String getAllStudiesHeader() {
        return allStudiesHeader.getText();
    }

    /**
     * Get the text for the footer items on the page.
     */
    public String getPreviousLink() {
        return previousLink.getText();
    }

    public String getNextLink() {
        return nextLink.getText();
    }

    public String getShowingEntries() {
        return showingEntriesText.getText();
    }

    /**
     * Method to wait until the study is
     * visible in the all studies table
     */
    public Boolean addedStudyVisible(String cellValue) {
        Table allStudiesTable = new Table(studiesTable2);
        return allStudiesTable.findCellByColumnAndKnownValue("Label", cellValue).isDisplayed();
    }

    /**
     * Method to click the logout link.
     */
    public void clickLogoutIcon() {
        logoutIcon.click();
    }

    /**
     * Method to click the Create project button.
     */
    public void clickCreateStudyButton() {
        createStudyButton.click();
    }

    /**
     * Method to enter study information to create
     * a study.
     */
    public void enterStudyInformation(String studyLabel, String studyDescription) {
        /**
         * Wait until each element is visible.
         * Check that all of the expected elements are on the page.
         * Send information to the fields.
         */
        studyLabelTextbox.sendKeys(studyLabel);
        studyDescriptionTextbox.sendKeys(studyDescription);
    }

    /**
     * Method to click the Add button.
     */
    public void clickAddStudyButton() {
        addStudyButton.click();
    }

    /**
     * Methods to check that the buttons in the actions
     * cell are displayed.
     */
    public Boolean viewButtonTableEntryDisplayed(String studyLabel) {
        try {
            Table allStudiesTable = new Table(studiesTable);
            return allStudiesTable.findIndexedButtonInCell("Actions", studyLabel, "Label", 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean copyButtonTableEntryDisplayed(String studyLabel) {
        try {
            Table allStudiesTable = new Table(studiesTable);
            return allStudiesTable.findIndexedButtonInCell("Actions", studyLabel, "Label", 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean deleteButtonTableEntryDisplayed(String studyLabel) {
        try {
            Table allStudiesTable = new Table(studiesTable);
            return allStudiesTable.findIndexedButtonInCell("Actions", studyLabel, "Label", 3).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Methods to click buttons in the All Projects table.
     */
    public void clickTableEditButton(String studyLabel) {
        Table allStudiesTable = new Table(studiesTable);

        allStudiesTable.findOnlyLinkButtonInCell("Actions", studyLabel, "Label").click();
    }

    public void clickTableViewButton(String studyLabel) {
        Table allStudiesTable = new Table(studiesTable);

        allStudiesTable.findIndexedButtonInCell("Actions", studyLabel, "Label", 1).click();
    }

    public void clickTableCopyButton(String studyLabel) {
        Table allStudiesTable = new Table(studiesTable);

        allStudiesTable.findIndexedButtonInCell("Actions", studyLabel, "Label", 2).click();
    }

    public void clickTableDeleteButton(String studyLabel) {
        Table allStudiesTable = new Table(studiesTable);

        allStudiesTable.findIndexedButtonInCell("Actions", studyLabel, "Label", 3).click();
    }
}
