package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 04/10/16.
 * Page Object for the Statistical Analysis
 * Plan page of the Kerus application.
 */
public class StatisticalAnalysisPlanPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public StatisticalAnalysisPlanPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sapHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "SAP")
    private WebElement statisticalAnalysisPlanBreadcrumb;

    /**
     * Locators for section headers.
     */
    @FindBy(how = How.ID, using = "sapHeader")
    private WebElement statisticalAnalysisPlanHeader;

    @FindBy(how = How.ID, using = "sapListHeader")
    private WebElement sapListHeader;

    /**
     * Locators for the fields & field labels.
     */
    @FindBy(how = How.ID, using = "variablesLabel")
    private WebElement variableLabel;

    @FindBy(how = How.ID, using = "analysisVariable")
    private WebElement variableField;

    @FindBy(how = How.ID, using = "testLabel")
    private WebElement testLabel;

    @FindBy(how = How.ID, using = "analysisTest")
    private WebElement testField;

    @FindBy(how = How.ID, using = "groupingLabel")
    private WebElement groupingLabel;

    @FindBy(how = How.ID, using = "analysisGrouping")
    private WebElement groupingField;

    @FindBy(how = How.ID, using = "bonferroniLabel")
    private WebElement bonferroniCorrectionLabel;

    @FindBy(how = How.ID, using = "bonferroni")
    private WebElement bonferroniCheckBox;

    /**
     * Locator for the Add button.
     */
    @FindBy(how = How.ID, using = "addAnalysis")
    private WebElement addButton;

    /**
     * Locator for the SAP list table.
     */
    @FindBy(how = How.ID, using = "Analysis")
    private WebElement sapTable;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getStatisticalAnalysisPlanBreadcrumb() {
        return statisticalAnalysisPlanBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    /**
     * Get the text from the headers.
     */
    public String getStatisticalAnalysisPlanHeader() {
        return statisticalAnalysisPlanHeader.getText();
    }

    public String getSAPListHeader() {
        return sapListHeader.getText();
    }

    /**
     * Get the text from the field labels and fields.
     */
    public String getVariableLabel() {
        return variableLabel.getText();
    }

    public String getVariableField() {
        Select variableList = new Select(variableField);
        return variableList.getFirstSelectedOption().getText();
    }

    public String getTestLabel() {
        return testLabel.getText();
    }

    public String getTestField() {
        Select testList = new Select(testField);
        return testList.getFirstSelectedOption().getText();
    }

    public String getGroupingLabel() {
        return groupingLabel.getText();
    }

    public String getGroupingField() {
        Select groupingList = new Select(groupingField);
        return groupingList.getFirstSelectedOption().getText();
    }

    public String getBonferroniCorrectionLabel() {
        return bonferroniCorrectionLabel.getText();
    }

    public Boolean getBonferroniCheckBox() {
        return bonferroniCheckBox.isSelected();
    }

    /**
     * Methods to get the list of all options from the fields.
     */
    public List<String> getTestOptions() {
        Select testList = new Select(testField);
        List<WebElement> options = testList.getOptions();
        List<String> allOptions = new ArrayList<String>();
        for (WebElement option : options) {
            allOptions.add(option.getText());
        }
        return allOptions;
    }

    public List<String> getGroupingOptions() {
        Select groupingList = new Select(groupingField);
        List<WebElement> options = groupingList.getOptions();
        List<String> allOptions = new ArrayList<String>();
        for (WebElement option : options) {
            allOptions.add(option.getText());
        }
        return allOptions;
    }

    /**
     * Get the text from the Add button.
     */
    public String getAddButton() {
        return addButton.getText();
    }

    /**
     * Get column headings for the projects table.
     */
    public List<String> getTableColumnHeaders() {
        Table sAPTable = new Table(sapTable);
        return sAPTable.readAllColumnHeaders();
    }

    /**
     * Get table entries for the SAP table.
     */
    public String getTableColumnEntry(String columnHeader, String cellValue) {
        Table sAPTable = new Table(sapTable);
        return sAPTable.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
    }

    /**
     * Methods to check that the buttons in the actions
     * cell are displayed.
     */
    public Boolean editButtonTableEntryDisplayed(String headerToSearch, String knownValue, String knownValueHeader) {
        try {
            Table sAPTable = new Table(sapTable);
            return sAPTable.findOnlyLinkButtonInCell(headerToSearch, knownValue, knownValueHeader).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean deleteButtonTableEntryDisplayed(String headerToSearch, String knownValue, String knownValueHeader) {
        try {
            Table sAPTable = new Table(sapTable);
            return sAPTable.findOnlyButtonInCell(headerToSearch, knownValue, knownValueHeader).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Method to select a variable from the list.
     * These methods are all separate so that
     * the population of the lists can be checked.
     * @param variable string of the variable to be selected.
     */
    public void selectVariable(String variable) {
        Select variableList = new Select(variableField);
        variableList.selectByVisibleText(variable);
    }

    /**
     * Method to select a test from the list.
     * @param test string of the test to be selected.
     */
    public void selectTest(String test) {
        Select testList = new Select(testField);
        testList.selectByVisibleText(test);
    }

    /**
     * Method to select a grouping option from the list.
     * @param grouping string of the grouping option to select.
     */
    public void selectGrouping(String grouping) {
        Select groupingList = new Select(groupingField);
        groupingList.selectByVisibleText(grouping);
    }

    /**
     * Method to select the Bonferroni correction
     * check box.
     */
    public void selectBonferroniCorrection() {
        bonferroniCheckBox.click();
    }

    /**
     * Method to click the Add button.
     */
    public void clickAddButton() {
        addButton.click();
    }

    /**
     * Click the current project breadcrumb.
     */
    public void clickCurrentProjectBreadcrumb() {
        currentProjectBreadcrumb.click();
    }
}
