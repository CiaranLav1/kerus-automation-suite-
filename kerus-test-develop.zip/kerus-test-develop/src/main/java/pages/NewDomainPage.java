package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 09/05/16.
 * Setting up the New Domain Page object.
 */
public class NewDomainPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public NewDomainPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("domainAdminSetupHeader")));
    }

    /**
     * Locators for Home and Logout links.
     * Also for the breadcrumb
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "domain")
    private WebElement addDomainBreadcrumb;

    /**
     * Locators for page elements.
     * Below items appear in the Domain Setup section.
     */
    @FindBy(how = How.ID, using = "domainSetupHeader")
    private WebElement domainSetupHeader;

    @FindBy(how = How.ID, using = "label")
    private WebElement domainLabelTextbox;

    @FindBy(how = How.ID, using = "domainNameLabel")
    private WebElement domainLabelFieldLabel;

    @FindBy(how = How.ID, using = "customerref")
    private WebElement customerRefTextbox;

    @FindBy(how = How.ID, using = "customeReferenceLabel")
    private WebElement customerRefFieldLabel;

    // Remember this is a drop down list.
    @FindBy(how = How.ID, using = "licencetype")
    private WebElement licenceTypeList;

    @FindBy(how = How.ID, using = "licenceTypeLabel")
    private WebElement licenceTypeFieldLabel;

    // This is also a drop down list.
    @FindBy(how = How.ID, using = "accounttype")
    private WebElement accountTypeList;

    @FindBy(how = How.ID, using = "DATlabel")
    private WebElement accountTypeFieldLabel;

    /**
     * Locators for the Domain Admin Setup section
     * and the section headers.
     */
    @FindBy(how = How.ID, using = "domainAdminSetupHeader")
    private WebElement domainAdminSetupHeader;

    @FindBy(how = How.ID, using = "username")
    private WebElement usernameTextbox;

    @FindBy(how = How.ID, using = "usernameLabel")
    private WebElement usernameFieldLabel;

    @FindBy(how = How.ID, using = "firstname")
    private WebElement firstNameTextbox;

    @FindBy(how = How.ID, using = "firstNameLabel")
    private WebElement firstNameFieldLabel;

    @FindBy(how = How.ID, using = "surname")
    private WebElement surnameTextbox;

    @FindBy(how = How.ID, using = "surnameLabel")
    private WebElement surnameFieldLabel;

    @FindBy(how = How.ID, using = "password")
    private WebElement passwordTextbox;

    @FindBy(how = How.ID, using = "passwordLabel")
    private WebElement passwordFieldLabel;

    @FindBy(how = How.ID, using = "repeatpassword")
    private WebElement repeatPasswordTextbox;

    @FindBy(how = How.ID, using = "repeatPasswordLabel")
    private WebElement repeatPasswordFieldLabel;

    @FindBy(how = How.ID, using = "email")
    private WebElement alternativeEmailTextbox;

    @FindBy(how = How.ID, using = "alternativeEmailLabel")
    private WebElement alternativeEmailFieldLabel;

    /**
     * Locators for buttons on the page.
     */
    @FindBy(how = How.ID, using = "addDomain")
    private WebElement addDomainButton;

    @FindBy(how = How.ID, using = "addDomain")
    private WebElement addDomainButton2;

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon(){
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon(){
        return logoutIcon.isDisplayed();
    }

    public String getAddDomainBreadcrumb(){
        return addDomainBreadcrumb.getText();
    }

    /**
     * Get the DomainSetup header, labels under
     * this section and the fields for data entry
     * in this section.
     */
    public String getDomainSetupHeader() {
        return domainSetupHeader.getText();
    }

    public String getDomainLabelLabel() {
        return domainLabelFieldLabel.getText();
    }

    public String getCustomerRefLabel() {
        return customerRefFieldLabel.getText();
    }

    public String getLicenceTypeList() {
        Select select = new Select(licenceTypeList);
        return select.getFirstSelectedOption().getText();
    }

    public String getLicenceTypeLabel() {
        return licenceTypeFieldLabel.getText();
    }

    public String getAccountTypeList() {
        Select select = new Select(accountTypeList);
        return select.getFirstSelectedOption().getText();
    }

    public String getAccountTypeLabel() {
        return accountTypeFieldLabel.getText();
    }

    /**
     * Get the DomainSetup header, labels under
     * this section and the fields for data entry
     * in this section.
     */
    public String getDomainAdminSetupHeader() {
        return domainAdminSetupHeader.getText();
    }

    public String getUsernameLabel() {
        return usernameFieldLabel.getText();
    }

    public String getFirstNameLabel() {
        return firstNameFieldLabel.getText();
    }

    public String getSurnameLabel() {
        return surnameFieldLabel.getText();
    }

    public String getPasswordLabel() {
        return passwordFieldLabel.getText();
    }

    public String getRepeatPasswordLabel() {
        return repeatPasswordFieldLabel.getText();
    }

    public String getAlternativeEmailLabel() {
        return alternativeEmailFieldLabel.getText();
    }

    /**
     * Get the Add Domain button.
     */
    public String getAddDomainButton() {
        return addDomainButton.getText();
    }

    /**
     * Method to enter the Domain information.
     */
    public void enterTestingDomainDetails(String domainLabel, String customerRef, String licenceType,
                                          String accountType, String username, String firstName, String surname,
                                          String password, String alternativeEmail) {
        domainLabelTextbox.sendKeys(domainLabel);
        customerRefTextbox.sendKeys(customerRef);
        licenceTypeList.sendKeys(licenceType);
        accountTypeList.sendKeys(accountType);
        usernameTextbox.sendKeys(username);
        firstNameTextbox.sendKeys(firstName);
        surnameTextbox.sendKeys(surname);
        passwordTextbox.sendKeys(password);
        repeatPasswordTextbox.sendKeys(password);
        alternativeEmailTextbox.sendKeys(alternativeEmail);
    }

    /**
     * Method to click the Save button.
     */
    public void clickSaveButton(){
        addDomainButton2.click();
    }

    /**
     * Method to click the Home link.
     */
    public void clickHome(){
        homeIcon.click();
    }

    /**
     * Method to click the logout link.
     */
    public void clickLogout(){
        logoutIcon.click();
    }
}