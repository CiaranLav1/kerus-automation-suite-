package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.ArrayList;
import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 13/10/16.
 * Setting up the page object for the
 * relation page.
 */
public class RelationPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public RelationPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("relationsHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "studiesLink")
    private WebElement allStudiesBreadcrumb;

    @FindBy(how = How.ID, using = "cStudiesLink")
    private WebElement currentStudyBreadcrumb;

    @FindBy(how = How.ID, using = "relation")
    private WebElement relationsBreadcrumb;

    /**
     * Locator for the relation form header
     * and relations list header.
     */
    @FindBy(how = How.ID, using = "relationsHeader")
    private WebElement relationsHeader;

    @FindBy(how = How.ID, using = "relationListHeader")
    private WebElement relationListHeader;

    /**
     * Locators for fields and field labels.
     */
    @FindBy(how = How.ID, using = "studies")
    private WebElement variableRelationTypeTable;

    @FindBy(how = How.ID, using = "relation.variable1")
    private WebElement variable1Field;

    @FindBy(how = How.ID, using = "relation.variable2")
    private WebElement variable2Field;

    @FindBy(how = How.ID, using = "relation.type")
    private WebElement relationTypeField;

    @FindBy(how = How.ID, using = "values")
    private WebElement relationValuesTable;

    @FindBy(how = How.ID, using = "groupLabel1")
    private WebElement relationValueLabel1;

    @FindBy(how = How.ID, using = "groupLabel2")
    private WebElement relationValueLabel2;

    @FindBy(how = How.ID, using = "minValue1")
    private WebElement relationValueField1;

    @FindBy(how = How.ID, using = "minValue2")
    private WebElement relationValueField2;

    /**
     * Locator for the Add button.
     */
    @FindBy(how = How.ID, using = "submitButton")
    private WebElement addButton;

    /**
     * Locator for the relation table.
     */
    @FindBy(how = How.ID, using = "relationTable")
    private WebElement relationTable;

    /**
     * Locators for the group labels in the relation list.
     */
    @FindBy(how = How.ID, using = "groupname01")
    private WebElement relation1Group1;

    @FindBy(how = How.ID, using = "groupname02")
    private WebElement relation1Group2;

    /**
     * Locators for the relation values in the relation list.
     */
    @FindBy(how = How.ID, using = "groupvalue01")
    private WebElement relation1parameter1;

    @FindBy(how = How.ID, using = "groupvalue02")
    private WebElement relation1parameter2;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public String getCurrentStudyBreadcrumb() {
        return currentStudyBreadcrumb.getText();
    }

    public String getRelationsBreadcrumb() {
        return relationsBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    /**
     * Get text for the relation form header and relation list header.
     */
    public String getRelationListHeader() {
        return relationListHeader.getText();
    }

    public String getRelationsHeader() {
        return relationsHeader.getText();
    }

    /**
     * Get the text for the headers of the
     * variable and relation type selection section.
     */
    public List<String> getVariableRelationTypeHeaders() {
        Table varRelTypeTable = new Table(variableRelationTypeTable);
        return varRelTypeTable.readAllColumnHeaders();
    }

    /**
     * Get all of the options in the Variable 1
     * drop down field.
     */
    public List<String> getVariable1Options() {
        Select variable1List = new Select(variable1Field);
        List<WebElement> options = variable1List.getOptions();
        List<String> allOptions = new ArrayList<String>();
        for (WebElement option : options) {
            allOptions.add(option.getText());
        }
        return allOptions;
    }

    /**
     * Check what the default selection is
     * for the Variable 1 field.
     */
    public String getVariable1Selection() {
        Select variable1List = new Select(variable1Field);
        return variable1List.getFirstSelectedOption().getText();
    }

    /**
     * Get all of the options in the Variable 2
     * drop down field.
     */
    public List<String> getVariable2Options() {
        Select variable1List = new Select(variable2Field);
        List<WebElement> options = variable1List.getOptions();
        List<String> allOptions = new ArrayList<String>();
        for (WebElement option : options) {
            allOptions.add(option.getText());
        }
        return allOptions;
    }

    /**
     * Check what the default selection is
     * for the Variable 2 field.
     */
    public String getVariable2Selection() {
        Select variable2List = new Select(variable2Field);
        return variable2List.getFirstSelectedOption().getText();
    }

    /**
     * Get all of the options in the Relation
     * Type drop down field.
     */
    public List<String> getRelationTypeOptions() {
        Select variable1List = new Select(relationTypeField);
        List<WebElement> options = variable1List.getOptions();
        List<String> allOptions = new ArrayList<String>();
        for (WebElement option : options) {
            allOptions.add(option.getText());
        }
        return allOptions;
    }

    /**
     * Check what the default selection is
     * for the Relation Type field.
     */
    public String getRelationTypeSelection() {
        Select relationType = new Select(relationTypeField);
        return relationType.getFirstSelectedOption().getText();
    }

    /**
     * Get the text from the relation parameters
     * form headers.
     */
    public List<String> getRelationParametersHeaders() {
        Table valuesTable = new Table(relationValuesTable);
        return valuesTable.readAllColumnHeaders();
    }

    /**
     * Get table entries for the relation table.
     */
    public String getTableColumnEntry(String columnHeader, String cellValue) {
        Table relationList = new Table(relationTable);
        return relationList.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
    }

    /**
     * Get group entries in the relation table.
     */
    public String getRelation1Group1() {
        return relation1Group1.getText();
    }

    public String getRelation1Group2() {
        return relation1Group2.getText();
    }

    /**
     * Get parameter entries in the relation table.
     */
    public String getRelation1Value1() {
        return relation1parameter1.getText();
    }

    public String getRelation1Value2() {
        return relation1parameter2.getText();
    }

    /**
     * Get the field labels for the parameter form.
     */
    public String getParameter1Label() {
        return relationValueLabel1.getText();
    }

    public String getParameter2Label() {
        return relationValueLabel2.getText();
    }

    /**
     * Get the text from the Add button.
     */
    public String getAddButton() {
        return addButton.getText();
    }

    /**
     * Get the text from the relation list column headers.
     */
    public List<String> getRelationListTableColumnHeaders() {
        Table allRelationsTable = new Table(relationTable);
        return allRelationsTable.readAllColumnHeaders();
    }

    /**
     * Method to select Variable 1.
     */
    public void selectVariable1(String variable1) {
        Select variable1List = new Select(variable1Field);
        variable1List.selectByVisibleText(variable1);
    }

    /**
     * Method to select Variable 2.
     */
    public void selectVariable2(String variable2) {
        Select variable2List = new Select(variable2Field);
        variable2List.selectByVisibleText(variable2);
    }

    /**
     * Method to select Relation Type.
     */
    public void selectRelationType(String relationType) {
        Select relationTypeList = new Select(relationTypeField);
        relationTypeList.selectByVisibleText(relationType);
    }

    /**
     * Method to enter relation parameter for the first field.
     */
    public void enterRelationParameter1(String relationParameter) {
        relationValueField1.sendKeys(relationParameter);
    }

    /**
     * Method to enter relation parameter for the second field.
     */
    public void enterRelationParameter2(String relationParameter) {
        relationValueField2.sendKeys(relationParameter);
    }

    /**
     * Click the add button.
     */
    public void clickAddButton() {
        addButton.click();
    }


    /**
     * Check that the delete button for the table
     * row is displayed in the Actions column
     */
    public Boolean deleteButtonTableEntryDisplayed(String buttonColumnHeader, String groupLabel, String labelColumnHeader) {
        try {
            Table allRelationsTable = new Table(relationTable);
            return allRelationsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        } //catch (org.openqa.selenium.StaleElementReferenceException e) {
           // Table allRelationsTable = new Table(relationTable);
            //return allRelationsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 2).isDisplayed();
        //}
    }

    /**
     * Check that the edit button for the table row is
     * displayed in the actions column.
     */
    public Boolean editButtonTableEntryDisplayed(String buttonColumnHeader, String groupLabel, String labelColumnHeader) {
        try {
            Table allRelationsTable = new Table(relationTable);
            return allRelationsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        } //catch (org.openqa.selenium.StaleElementReferenceException e) {
            //Table allRelationsTable = new Table(relationTable);
            //return allRelationsTable.findIndexedButtonInCell(buttonColumnHeader, groupLabel, labelColumnHeader, 1).isDisplayed();
        //}
    }

    /**
     * Method to click the Current Project breadcrumb.
     */
    public void clickCurrentProjectBreadcrumb() {
        currentProjectBreadcrumb.click();
    }
}
