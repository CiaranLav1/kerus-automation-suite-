package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 06/05/16.
 * Setting up the Login page object.
 */
public class LoginPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public LoginPage(WebDriver driver) {
        super(driver);
        driver.navigate().to("http://localhost:9000/");
        WebDriverWait wait = new WebDriverWait(driver, 90);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("loginHeader")));
    }

    /**
     * Locators
     */
    @FindBy(how = How.ID, using = "domain")
    private WebElement domainTextbox;

    @FindBy(how = How.ID, using = "username")
    private WebElement usernameTextbox;

    @FindBy(how = How.ID, using = "password")
    private WebElement passwordTextbox;

    @FindBy(how = How.ID, using = "buttonForgotLogin")
    private WebElement forgotLoginLink;

    @FindBy(how = How.ID, using = "login")
    private WebElement loginButton;

    // Page Header.
    @FindBy(how = How.ID, using = "loginHeader")
    private WebElement loginPageHeader;

    public String getPageHeader() {
        return loginPageHeader.getText();
    }

    /**
     * Method to log in to Kerus for any user.
     */
    public void enterUserDetails(String domain, String username, String password) {
        domainTextbox.sendKeys(domain);
        usernameTextbox.sendKeys(username);
        passwordTextbox.sendKeys(password);
    }

    /**
     * Method to click the log in button
     */
    public void clickLoginButton() {
        loginButton.click();
    }

    /**
     * Method to check that the forgot login button is present.
     */
    public String getForgotLoginLink() {
        return forgotLoginLink.getText();
    }
}
