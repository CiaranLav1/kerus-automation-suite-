package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 11/05/16.
 * Setting up the Projects page object.
 */
public class ProjectsPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public ProjectsPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("allProjectsHeader")));
    }

    /**
     * Locators for Home and Logout links.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "allproject")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    /**
     * Locators for footer links.
     */
    @FindBy(how = How.ID, using = "DataTables_Table_0_previous")
    private WebElement previousLink;

    @FindBy(how = How.ID, using = "DataTables_Table_0_next")
    private WebElement nextLink;

    @FindBy(how = How.ID, using = "DataTables_Table_0_info")
    private WebElement showingEntriesText;

    /**
     * Locators for buttons on the page,
     * NOTE: these are not always visible.
     */
    @FindBy(how = How.ID, using = "createProject")
    private WebElement createProjectButton;

    @FindBy(how = How.ID, using = "addProject")
    private WebElement addProjectButton;

    @FindBy(how = How.ID, using = "reset")
    private WebElement cancelCreateProjectButton;

    @FindBy(how = How.ID, using = "loadProject")
    private WebElement loadProjectButton;

    /**
     * Locators for section headers.
     */
    @FindBy(how = How.ID, using = "allProjectsHeader")
    private WebElement allProjectsHeader;

    /**
     * Locators for the All Projects section items.
     * This includes table column headers and search
     * fields.
     */
    @FindBy(how = How.ID, using = "DataTables_Table_0_length")
    private WebElement showBlockEntriesText;

    @FindBy(how = How.ID, using = "DataTables_Table_0_filter")
    private WebElement searchProjectsLabel;

    @FindBy(how = How.ID, using = "DataTables_Table_0")
    private WebElement projectsTable;

    /**
     * Locators for the create Project fields
     * and field labels.
     */
    @FindBy(how = How.ID, using = "projectLabel")
    private WebElement projectLabelFieldLabel;

    @FindBy(how = How.ID, using = "project.label")
    private WebElement projectLabelTextbox;

    @FindBy(how = How.ID, using = "projectDescriptionLabel")
    private WebElement projectDescriptionFieldLabel;

    @FindBy(how = How.ID, using = "project.description")
    private WebElement projectDescriptionTextbox;

    @FindBy(how = How.ID, using = "seedLabel")
    private WebElement seedFieldLabel;

    @FindBy(how = How.ID, using = "project.seed")
    private WebElement seedNumberbox;

    @FindBy(how = How.ID, using = "simulationsNumberLabel")
    private WebElement simulationsFieldLabel;

    @FindBy(how = How.ID, using = "project.numSimulations")
    private WebElement simulationsNumberbox;

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean getHelpIcon(){
        return helpIcon.isDisplayed();
    }

    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    /**
     * Get the text for field labels in the
     * create project section and check the
     * field default for simulations.
     */
    public String getProjectLabelLabelText() {
        return projectLabelFieldLabel.getText();
    }

    public String getProjectDescriptionLabelText() {
        return projectDescriptionFieldLabel.getText();
    }

    public String getSeedLabelText() {
        return seedFieldLabel.getText();
    }

    public String getSimulationsLabelText() {
        return simulationsFieldLabel.getText();
    }

    public String getSimulationsFieldText() {
        return simulationsNumberbox.getAttribute("value");
    }

    /**
     * Get the text for fields in the All
     * Projects section.
     */
    public String getBlockEntriesText() {
        return showBlockEntriesText.getText();
    }

    public String getSearchProjectsLabel() {
        return searchProjectsLabel.getText();
    }

    /**
     * Get column headings for the projects table.
     */
    public List<String> getTableColumnHeaders() {
        Table allProjectsTable = new Table(projectsTable);
        return allProjectsTable.readAllColumnHeaders();
    }

    /**
     * Get table entries for the projects table.
     */
    public String getTableColumnEntry(String columnHeader, String cellValue) {
        Table allProjectsTable = new Table(projectsTable);
        return allProjectsTable.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
    }

    /**
     * Get the text for buttons on the page.
     */
    public String getCreateProjectButton() {
        return createProjectButton.getText();
    }

    public String getLoadProjectButton(){ return loadProjectButton.getText(); }

    public String getAddProjectButton() {
        return addProjectButton.getText();
    }

    public String getCancelCreateProjectButton() {
        return cancelCreateProjectButton.getText();
    }


    /**
     * Get text for headers on the page.
     */
    public String getAllProjectsHeader() {
        return allProjectsHeader.getText();
    }

    /**
     * Get the text for the footer items on the page.
     */
    public String getPreviousLink() {
        return previousLink.getText();
    }

    public String getNextLink() {
        return nextLink.getText();
    }

    public String getShowingEntries() {
        return showingEntriesText.getText();
    }

    /**
     * Method to click the Home link.
     */
    public void clickHomeIcon() {
        homeIcon.click();
    }

    /**
     * Method to click the logout link.
     */
    public void clickLogoutIcon() {
        logoutIcon.click();
    }

    /**
     * Method to click the Create project button.
     */
    public void clickCreateProjectButton() {
        createProjectButton.click();
    }

    /**
     * Method to enter project information to
     * create a project.
     */
    public void enterProjectDetails(String projectLabel, String projectDescription, String seed, String noOfSimulations) {
        /**
         * Wait until each element is visible.
         * Check that all of the expected elements are on the page.
         * Send information to the fields.
         */
        projectLabelTextbox.sendKeys(projectLabel);
        projectDescriptionTextbox.sendKeys(projectDescription);
        seedNumberbox.sendKeys(seed);
        simulationsNumberbox.clear();
        simulationsNumberbox.sendKeys(noOfSimulations);
    }

    /**
     * Method to click the Add button.
     */
    public void clickAddProjectButton() {
        addProjectButton.click();
    }

    /**
     * Method to wait until a project has been added.
     * This will mean that some fields become invisible
     * on the UI.
     */
    public Boolean waitUntilProjectLabelFieldInvisible() {
        try {
            return projectLabelTextbox.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean waitUntilProjectDescriptionFieldInvisible() {
        return projectDescriptionTextbox.isDisplayed();
    }

    public Boolean waitUntilSeedFieldInvisible() {
        return seedNumberbox.isDisplayed();
    }

    public Boolean waitUntilSimsFieldInvisible() {
        try {
            return simulationsNumberbox.isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Methods to check that the buttons in the actions
     * cell are displayed.
     */
    public Boolean viewButtonTableEntryDisplayed(String projectLabel) {
        try {
            Table allProjectsTable = new Table(projectsTable);
            return allProjectsTable.findIndexedButtonInCell("Actions", projectLabel, "Label", 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean copyButtonTableEntryDisplayed(String projectLabel) {
        try {
            Table allProjectsTable = new Table(projectsTable);
            return allProjectsTable.findIndexedButtonInCell("Actions", projectLabel, "Label", 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean deleteButtonTableEntryDisplayed(String projectLabel) {
        try {
            Table allProjectsTable = new Table(projectsTable);
            return allProjectsTable.findIndexedButtonInCell("Actions", projectLabel, "Label", 3).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Methods to click buttons in the All Projects table.
     * From their Xpaths we know what the index of each
     * button is.
     */
    public void clickTableEditButton(String projectLabel) throws Exception {
        Table allProjectsTable = new Table(projectsTable);

        allProjectsTable.findOnlyLinkButtonInCell("Actions", projectLabel, "Label").click();
    }

    public void clickTableViewButton(String projectLabel) {
        Table allProjectsTable = new Table(projectsTable);

        allProjectsTable.findIndexedButtonInCell("Actions", projectLabel, "Label", 1).click();
    }

    public void clickTableCopyButton(String projectLabel) {
        Table allProjectsTable = new Table(projectsTable);

        allProjectsTable.findIndexedButtonInCell("Actions", projectLabel, "Label", 2).click();
    }

    public void clickTableDeleteButton(String projectLabel) {
        Table allProjectsTable = new Table(projectsTable);

        allProjectsTable.findIndexedButtonInCell("Actions", projectLabel, "Label", 3).click();
    }
}
