package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 09/05/16.
 * Setting up the Change Password Page object.
 */
public class ChangePasswordPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public ChangePasswordPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("changePasswordHeader")));
    }

    /**
     * Locators for page elements.
     */
    @FindBy(how = How.ID, using = "oldpassword")
    private WebElement oldPasswordTextbox;

    @FindBy(how = How.ID, using = "newpassword")
    private WebElement newPasswordTextbox;

    @FindBy(how = How.ID, using = "repeatpassword")
    private WebElement confirmPasswordTextbox;

    @FindBy(how = How.ID, using = "savePassword")
    private WebElement savePasswordButton;

    @FindBy(how = How.ID, using = "oldPasswordLabel")
    private WebElement oldPasswordFieldLabel;

    @FindBy(how = How.ID, using = "newPasswordLabel")
    private WebElement newPasswordFieldLabel;

    @FindBy(how = How.ID, using = "confirmPasswordLabel")
    private WebElement confirmPasswordFieldLabel;

    // Page Header.
    @FindBy(how = How.ID, using = "changePasswordHeader")
    private WebElement changePasswordHeader;

    // Header links
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "password")
    private WebElement changePasswordBreadcrumb;

    /**
     * SuperAdmin information to change password
     */
    private static final String OLDPASSWORD = "Admin123!";
    private static final String NEWPASSWORD = "Password01!";
    private static final String CONFIRMPASSWORD = "Password01!";

    /**
     * Method to get the header of the page.
     */
    public String getPageHeader() {
        return changePasswordHeader.getText();
    }

    /**
     * Get the field labels on the page.
     */
    public String getOldPasswordLabel() {
        return oldPasswordFieldLabel.getText();
    }

    public String getNewPasswordLabel() {
        return newPasswordFieldLabel.getText();
    }

    public String getConfirmPasswordLabel() {
        return confirmPasswordFieldLabel.getText();
    }

    /**
     * Method to change the password of the SuperAdmin user.
     */
    public void changeSuperAdminPassword(String oldPassword, String newPassword) {
        oldPasswordTextbox.sendKeys(oldPassword);
        newPasswordTextbox.sendKeys(newPassword);
        confirmPasswordTextbox.sendKeys(newPassword);
    }

    /**
     * Method to click confirm password change.
     */
    public void clickConfirmPassword() {
        savePasswordButton.click();
    }

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public String getChangePasswordBreadcrumb() {
        return changePasswordBreadcrumb.getText();
    }

}
