package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 16/05/16.
 * Setting up Page Object for Group Allocations.
 */
public class GroupAllocationsPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public GroupAllocationsPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("allocationListHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "studiesLink")
    private WebElement allStudiesBreadcrumb;

    @FindBy(how = How.ID, using = "cStudiesLink")
    private WebElement currentStudyBreadcrumb;

    @FindBy(how = How.ID, using = "allocation")
    private WebElement allocationsBreadcrumb;

    /**
     * Field locators including field labels.
     */
    @FindBy(how = How.ID, using = "allocationLabel1")
    public WebElement allocationFieldLabel1;

    @FindBy(how = How.ID, using = "allocationLabel2")
    public WebElement allocationFieldLabel2;

    @FindBy(how = How.ID, using = "allocationField1")
    public WebElement allocationTextbox1;

    @FindBy(how = How.ID, using = "allocationField2")
    public WebElement allocationTextbox2;

    /**
     * Page and sections headers.
     */
    @FindBy(how = How.ID, using = "allocationListHeader")
    private WebElement allocationListHeader;

    /**
     * Button locators.
     */
    @FindBy(how = How.ID, using = "saveAllocation")
    private WebElement saveButton;

    /**
     * Locator for the table. Need to have a
     * second locator because when you land on
     * the page the only header that populates
     * is Actions. Once something is added to
     * the table the rest of the headers
     * populate.
     */
    @FindBy(how = How.ID, using = "allocations")
    private WebElement allocationsTable;

    @FindBy(how = How.ID, using = "allocations")
    private WebElement allocationsTable2;

    /**
     * Get the navigation banner links.
     */
    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public String getCurrentStudyBreadcrumb() {
        return currentStudyBreadcrumb.getText();
    }

    public String getAllocationBreadcrumb() {
        return allocationsBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean getHelpIcon() { return helpIcon.isDisplayed(); }
    /**
     * Get string for field labels. Have each of these
     * as their own individual method because I can
     * control how many of them appear at any time.
     */
    public String getAllocationFieldLabel1(){
        return allocationFieldLabel1.getText();
    }

    public String getAllocationFieldLabel2(){
        return allocationFieldLabel2.getText();
    }

    /**
     * Get string for headers.
     */
    public String getAllocationListHeader() {
        return allocationListHeader.getText();
    }

    /**
     * Get string for buttons.
     */
    public String getAddButton() {
        return saveButton.getText();
    }

    /**
     * Get the text from the column headers.
     * Have a second method to be called
     * once the table has started to be
     * populated. It is anticipated that
     * the developers will change this which
     * will allow the second method to be
     * deleted & the first to be updated
     * for the locator.
     */
    public List<String> getTableColumnHeaders() {
        Table allAllocationsTable = new Table(allocationsTable);
        return allAllocationsTable.readAllColumnHeaders();
    }

    public String getTableColumnHeaders2() {
        Table allAllocationsTable = new Table(allocationsTable);
        List<String> allHeaders = allAllocationsTable.readAllColumnHeaders();
        if (allHeaders.size() == 1) {
            return allHeaders.get(0);
        } else {
            String listString = "";
            for (String s : allHeaders) {
                listString += s + "\t";
            }
            return listString;
        }
    }

    /**
     * Get strings from table elements.
     */
    public String getAllocationColumnEntry(String groupLabel, String cellValue) {
        Table allAllocationsTable = new Table(allocationsTable);
        return allAllocationsTable.findCellByColumnAndKnownValue(groupLabel, cellValue).getText();
    }

    /**
     * Check that the delete button for the table
     * row is displayed in the Actions column
     */
    public Boolean deleteButtonTableEntryDisplayed(String buttonColumnHeader, String allocationValue, String knownColumn) {
        try {
            Table allAllocationsTable = new Table(allocationsTable);
            //TODO update to remove two when the xpath has been fixed.
            return allAllocationsTable.findOnlyButtonInCellTWO(buttonColumnHeader, allocationValue, knownColumn).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Enter valid allocation information.
     * Again, have individual methods for each
     * of these because I can control the number
     * of them that appear.
     */
    public void enterAllocation1(String allocationEntry) {
        allocationTextbox1.sendKeys(allocationEntry);
    }

    public void enterAllocation2(String allocationEntry){
        allocationTextbox2.sendKeys(allocationEntry);
    }

    /**
     * Click the Add button. Need to handle
     * the alert that pops up just now.
     */
    public void clickAddButton() {
        saveButton.click();
    }

    /**
     * Click the delete button for the
     * an allocation that was added.
     */
    public void clickDeleteGroupButton(String columnHeader, String allocationValue, String knownColumn) {
        Table allAllocationsTable = new Table(allocationsTable);
        //TODO update to remove two when the xpath has been fixed.
        allAllocationsTable.findOnlyButtonInCellTWO(columnHeader, allocationValue, knownColumn).click();
    }

    /**
     * Method to click the Current Study breadcrumb.
     */
    public void clickCurrentStudyBreadcrumb() {
        currentStudyBreadcrumb.click();
    }
}
