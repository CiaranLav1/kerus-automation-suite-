package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import utilities.Table;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by heather.reid on 20/10/16.
 * Page Object for the Objective Evaluation
 * page of the Kerus application.
 */
public class ObjectiveEvaluationPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public ObjectiveEvaluationPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("objevalHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "oE")
    private WebElement objectiveEvaluationBreadcrumb;

    /**
     * Locators for the headers
     */
    @FindBy(how = How.ID, using = "objevalHeader")
    private WebElement objectiveEvaluationHeader;

    @FindBy(how = How.ID, using = "allObjectivesHeader")
    private WebElement objectivesListHeader;

    /**
     * Locators for the fields and field labels.
     */
    @FindBy(how = How.ID, using = "objectivesVariableLabel")
    private WebElement variableLabel;

    @FindBy(how = How.ID, using = "objectivesVariable")
    private WebElement variableField;

    @FindBy(how = How.ID, using = "objectivesTestLabel")
    private WebElement testLabel;

    @FindBy(how = How.ID, using = "objectiveTest-Model")
    private WebElement testField;

    @FindBy(how = How.ID, using = "objectivesMeanLabel")
    private WebElement meanLabel;
// TODO look up ID for this
    @FindBy(how = How.ID, using = "")
    private WebElement meanField;

    @FindBy(how = How.ID, using = "objectivesStatisticLabel")
    private WebElement statisticLabel;

    @FindBy(how = How.ID, using = "objectiveStatistics")
    private WebElement statisticField;

    @FindBy(how = How.ID, using = "objectivesGrouping1Label")
    private WebElement groupingComparisonLabel;

    @FindBy(how = How.ID, using = "objectiveGrouping")
    private WebElement groupingComparisonField;

    @FindBy(how = How.ID, using = "objectivesLogicTypeLabel")
    private WebElement operatorLabel;

    @FindBy(how = How.ID, using = "objectiveLogic")
    private WebElement operatorField;

    @FindBy(how = How.ID, using = "objectivesValueLabel")
    private WebElement valueLabel;

    @FindBy(how = How.ID, using = "objectiveValue")
    private WebElement valueField;

    @FindBy(how = How.ID, using = "objectivesSimpleLabelLabel")
    private WebElement simpleObjectiveLabelLabel;

    @FindBy(how = How.ID, using = "simpleLabel")
    private WebElement simpleObjectiveLabelField;

    /**
     * Locators for the buttons.
     */
    @FindBy(how = How.ID, using = "saveObjective")
    private WebElement addButton;

    @FindBy(how = How.ID, using = "combineObjective")
    private WebElement combineObjectiveButton;

    /**
     * Locators for the table, add a second one to
     * avoid stale element exceptions.
     */
    @FindBy(how = How.ID, using = "DataTables_Table_0")
    private WebElement objectiveListTable;

    @FindBy(how = How.ID, using = "DataTables_Table_0")
    private WebElement objectiveListTable2;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getObjectiveEvaluationBreadcrumb() {
        return objectiveEvaluationBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    /**
     * Get the text from the headers.
     */
    public String getObjectiveEvaluationHeader() {
        return objectiveEvaluationHeader.getText();
    }

    public String getObjectiveListHeader() {
        return objectivesListHeader.getText();
    }

    /**
     * Get the text from the field labels and
     * the default field selections.
     */
    public String getVariableLabel() {
        return variableLabel.getText();
    }

    public String getVariableField() {
        Select variableList = new Select(variableField);
        return variableList.getFirstSelectedOption().getText();
    }

    public String getTestLabel() {
        return testLabel.getText();
    }

    public String getTestField() {
        Select testList = new Select(testField);
        return testList.getFirstSelectedOption().getText();
    }

    /**
     * Note the mean field is not visible by default on the UI.
     */
    public String getMeanLabel() {
        return meanLabel.getText();
    }

    public String getMeanField() {
        Select meanList = new Select(meanField);
        return meanList.getFirstSelectedOption().getText();
    }

    public String getStatisticLabel() {
        return statisticLabel.getText();
    }

    public String getStatisticField() {
        Select statisticList = new Select(statisticField);
        return statisticList.getFirstSelectedOption().getText();
    }

    public String getGroupingComparisonLabel() {
        return groupingComparisonLabel.getText();
    }

    public String getGroupingComparisonField() {
        Select comparatorList = new Select(groupingComparisonField);
        return comparatorList.getFirstSelectedOption().getText();
    }

    public String getOperatorLabel() {
        return operatorLabel.getText();
    }

    public String getOperatorField() {
        Select operatorList = new Select(operatorField);
        return operatorList.getFirstSelectedOption().getText();
    }

    public String getValueLabel() {
        return valueLabel.getText();
    }

    public String getValueField() {
        return valueField.getText();
    }

    public String getSimpleLabelLabel() {
        return simpleObjectiveLabelLabel.getText();
    }

    public String getSimpleLabelField() {
        return simpleObjectiveLabelField.getText();
    }

    /**
     * Methods to get the list of all options from the fields.
     */
    public List<String> getOperatorOptions() {
        Select operatorList = new Select(operatorField);
        List<WebElement> options = operatorList.getOptions();
        List<String> allOptions = new ArrayList<String>();
        for (WebElement option : options) {
            allOptions.add(option.getText());
        }
        return allOptions;
    }

    /**
     * Get the text from the buttons.
     */
    public String getAddButton() {
        return addButton.getText();
    }

    public String getCombineObjectivesButton() {
        return combineObjectiveButton.getText();
    }

    /**
     * Get the text from the table headers.
     */
    public List<String> getTableColumnHeaders() {
        Table objectiveTable = new Table(objectiveListTable);
        return objectiveTable.readAllColumnHeaders();
    }

    /**
     * Get the table entries.
     */
    public String getTableColumnEntry(String columnHeader, String cellValue) {
        try {
            Table objectiveTable = new Table(objectiveListTable);
            return objectiveTable.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
        } catch (org.openqa.selenium.StaleElementReferenceException e) {
            Table objectiveTable = new Table(objectiveListTable2);
            return objectiveTable.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
        }
    }

    /**
     * Get the actions buttons from the table.
     */
    public Boolean editButtonTableEntryDisplayed(String headerToSearch, String knownValue, String knownValueHeader) {
        try {
            Table objectiveTable = new Table(objectiveListTable);
            return objectiveTable.findIndexedButtonInCell(headerToSearch, knownValue, knownValueHeader, 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean deleteButtonTableEntryDisplayed(String headerToSearch, String knownValue, String knownValueHeader) {
        try {
            Table objectiveTable = new Table(objectiveListTable);
            return objectiveTable.findIndexedButtonInCell(headerToSearch, knownValue, knownValueHeader, 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }


    /**
     * Method to select a variable from the list.
     * These methods are all separate so that
     * the population of the lists can be checked.
     * @param variable string of the variable to be selected.
     */
    public void selectVariable(String variable) {
        Select variableList = new Select(variableField);
        variableList.selectByVisibleText(variable);
    }

    /**
     * Method to select a test from the list.
     * @param test string of the test to be selected.
     */
    public void selectTest(String test) {
        Select testList = new Select(testField);
        testList.selectByVisibleText(test);
    }

    public void selectMean(String mean) {
        Select meanList = new Select(meanField);
        meanList.selectByVisibleText(mean);
    }

    /**
     * Method to select a statistic from the list.
     * @param statistic string of the statistic to be selected.
     */
    public void selectStatistic(String statistic) {
        Select statisticList = new Select(statisticField);
        statisticList.selectByVisibleText(statistic);
    }

    /**
     * Method to select a grouping option from the list.
     * @param grouping string of the grouping option to select.
     */
    public void selectGroupingComparison(String grouping) {
        Select groupingComparisonList = new Select(groupingComparisonField);
        groupingComparisonList.selectByVisibleText(grouping);
    }

    /**
     * Method to select an operator from the list.
     * @param operator string of the operator to select.
     */
    public void selectOperator(String operator) {
        Select operatorList = new Select(operatorField);
        operatorList.selectByVisibleText(operator);
    }

    /**
     * Method to enter a value into the value field.
     * @param value string of the value to enter.
     */
    public void enterValue(String value) {
        valueField.sendKeys(value);
    }

    public void enterSimpleLabel(String label) {
        simpleObjectiveLabelField.sendKeys(label);
    }

    /**
     * Click the add button.
     */
    public void clickAddButton() {
        addButton.click();
    }

    /**
     * Click the current project breadcrumb.
     */
    public void clickCurrentProjectBreadcrumb() {
        currentProjectBreadcrumb.click();
    }
}
