package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 13/05/16.
 * Setting up the page object for the
 * Studies Samples page.
 */
public class StudiesSamplesPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public StudiesSamplesPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("sampleSizeHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "studiesLink")
    private WebElement allStudiesBreadcrumb;

    @FindBy(how = How.ID, using = "cStudiesLink")
    private WebElement currentStudyBreadcrumb;

    @FindBy(how = How.ID, using = "sampleSize")
    private WebElement sampleSizeBreadcrumb;

    /**
     * Locator for section header.
     */
    @FindBy(how = How.ID, using = "sampleSizeHeader")
    private WebElement sampleSizeHeader;

    @FindBy(how = How.ID, using = "sampleSizeSingleHeader")
    private WebElement sampleSingleHeader;

    @FindBy(how = How.ID, using = "sampleSizeRangeHeader")
    private WebElement sampleSizeRangeHeader;

    @FindBy(how = How.ID, using = "sampleSizeStartLabel")
    private WebElement sampleSizeStartLabel;

    @FindBy(how = How.ID, using = "sampleSizeEndLabel")
    private WebElement sampleSizeEndLabel;

    @FindBy(how = How.ID, using = "sampleSizeIncrementLabel")
    private WebElement sampleSizeIncrementLabel;

    /**
     * Locator for Field label & field.
     */
    @FindBy(how = How.ID, using = "sampleSizeLabel")
    private WebElement sampleSizeFieldLabel;

    @FindBy(how = How.ID, using = "samples.number")
    private WebElement sampleSizeTextbox;

    /**
     * Locator for the Add button.
     */
    @FindBy(how = How.ID, using = "add")
    private WebElement addButton;

    /**
     * Locator for the sample sizes table
     */
    @FindBy(how = How.ID, using = "sampleSizes")
    private WebElement sampleSizesTable;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public String getCurrentStudyBreadcrumb() {
        return currentStudyBreadcrumb.getText();
    }

    public String getSampleSizeBreadcrumb() {
        return sampleSizeBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean getHelpIcon() { return helpIcon.isDisplayed(); }

    /**
     * Get the text from the header.
     */
    public String getSampleSizesHeader() {
        return sampleSizeHeader.getText();
    }

    public String getSampleSizeSingleHeader() { return sampleSingleHeader.getText(); }

    public String getSampleSizeRangeHeader() { return sampleSizeRangeHeader.getText(); }

    public String getSampleSizeStartLabel() { return sampleSizeStartLabel.getText(); }

    public String getSampleSizeEndLabel() { return sampleSizeEndLabel.getText(); }

    public String getSampleSizeIncrementLabel() { return sampleSizeIncrementLabel.getText(); }

    /**
     * Get the text from the field label.
     */
    public String getSampleSizesLabel() {
        return sampleSizeFieldLabel.getText();
    }

    /**
     * Get the text from the add button.
     */
    public String getAddButton() {
        return addButton.getText();
    }

    /**
     * Get column headings for the Studies table.
     */
    public List<String> getTableColumnHeaders() {
        Table allSampleSizesTable = new Table(sampleSizesTable);
        return allSampleSizesTable.readAllColumnHeaders();
    }

    /**
     * Get table entries for the studies table.
     */
    public String getSamplesizeTableEntry(String cellValue) {
        Table allSampleSizesTable = new Table(sampleSizesTable);
        return allSampleSizesTable.findCellByColumnAndKnownValue("Samples", cellValue).getText();
    }

    public Boolean deleteButtonTableEntryDisplayed(String sampleSizeValue) {
        try {
            Table allSampleSizesTable = new Table(sampleSizesTable);
            return allSampleSizesTable.findOnlyButtonInCell("Actions", sampleSizeValue, "Samples").isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Method to enter first sample size.
     */
    public void enterSampleSizeValue(String sampleSize) {
        sampleSizeTextbox.clear();
        sampleSizeTextbox.sendKeys(sampleSize);
    }

    /**
     * Method to click the Add button.
     */
    public void clickAddButton() {
        addButton.click();
    }

    /**
     * Method to delete the first sample size value that was added.
     */
    public void clickDeleteSampleSize(String sampleSizeValue) {
        Table allSampleSizesTable = new Table(sampleSizesTable);
        allSampleSizesTable.findOnlyButtonInCell("Actions", sampleSizeValue, "Samples").click();
    }

    /**
     * Method to click the Current Study breadcrumb.
     */
    public void clickCurrentStudyBreadcrumb() {
        currentStudyBreadcrumb.click();
    }
}
