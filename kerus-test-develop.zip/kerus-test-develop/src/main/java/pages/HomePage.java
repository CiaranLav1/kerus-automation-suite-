package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 06/05/16.
 * Setting up the Home Page object.
 */
public class HomePage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public HomePage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 80);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("welcomeMessage")));
    }

    /**
     * Locators
     */
    // Header links
    @FindBy(how = How.ID, using = "homePageLink")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutLink")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "helpLink")
    private WebElement helpIcon;

    // Kerus Administration buttons
    @FindBy(how = How.ID, using = "buttonAdd")
    private WebElement addDomainButton;

    @FindBy(how = How.ID, using = "buttonUsage")
    private WebElement systemUsageButton;

    // Domain Management buttons
    @FindBy(how = How.ID, using = "buttonProjects")
    private WebElement projectsButton;

    @FindBy(how = How.ID, using = "buttonUserManagement")
    private WebElement userManagementButton;

    @FindBy(how = How.ID, using = "buttonDSU")
    private WebElement domainSystemUsageButton;

    // Account Management buttons
    @FindBy(how = How.ID, using = "buttonDetailSettings")
    private WebElement yourDetailsButton;

    @FindBy(how = How.ID, using = "buttonSecurityQuestion")
    private WebElement securityQuestionsButton;

    @FindBy(how = How.ID, using = "buttonChangePwd")
    private WebElement changePasswordButton;

    // Page Header.
    @FindBy(how = How.ID, using = "welcomeMessage")
    private WebElement homePageHeader;

    // Section Headers.
    @FindBy(how = How.ID, using = "kerusAdminHeader")
    private WebElement kerusAdminHeader;

    @FindBy(how = How.ID, using = "domainMgmtHeader")
    private WebElement domainManagementHeader;

    @FindBy(how = How.ID, using = "myAccountHeader")
    private WebElement myAccountHeader;

    /**
     * Method to get the header of the page.
     */
    public String getPageHeader() {
        return homePageHeader.getText();
    }

    /**
     * Methods to get the Kerus Administration
     * section headers and the dashboard
     * buttons in this section.
     */
    public String getKerusAdminHeader() {
        return kerusAdminHeader.getText();
    }

    public String getAddDomainButton() {
        return addDomainButton.getText();
    }

    public String getSystemUsageButton() {
        return systemUsageButton.getText();
    }

    /**
     * Methods to get the Domain Management
     * section headers and the dashboard
     * buttons in this section.
     */
    public String getDomainManagementHeader() {
        return domainManagementHeader.getText();
    }

    public String getProjectsButton() {
        return projectsButton.getText();
    }

    public String getUserManagementButton() {
        return userManagementButton.getText();
    }

    public String getDomainSystemUsageButton() {
        return domainSystemUsageButton.getText();
    }

    /**
     * Methods to get the My Account
     * section headers and the dashboard
     * buttons in this section.
     */
    public String getMyAccountHeader() {
        return myAccountHeader.getText();
    }

    public String getYourDetailsSettingsButton() {
        return yourDetailsButton.getText();
    }

    public String getSecurityQuestionsButton() {
        return securityQuestionsButton.getText();
    }

    public String getChangePasswordButton() {
        return changePasswordButton.getText();
    }

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    public Boolean getHelpIcon(){
        return helpIcon.isDisplayed();
    }

    /**
     * Method to click the Home link.
     */
    public void clickHome() {
        homeIcon.click();
    }

    /**
     * Method to click the logout link.
     */
    public void clickLogout() {
        logoutIcon.click();
    }

    /**
     * Method to click the add domain button.
     */
    public void clickAddDomainButton() {
        addDomainButton.click();
    }

    /**
     * Method to click the system usage button.
     */
    public void clickSystemUsageButton() { systemUsageButton.click(); }

    /**
     * Method to click the projects button.
     */
    public void clickProjectsButton() {
        projectsButton.click();
    }

    /**
     * Method to click the user management button.
     */
    public void clickUserManagementButton() {
        userManagementButton.click();
    }

    /**
     * Method to click the domain system usage button.
     */
    public void clickDomainSystemUsageButton() {
        domainSystemUsageButton.click();
    }
    /**
     * Method to click the your details button.
     */
    public void clickYourDetailsButton() {
        yourDetailsButton.click();
    }

    /**
     * Method to click the security questions button.
     */
    public void clickSecurityQuestionsButton() {
        securityQuestionsButton.click();
    }
    /**
     * Method to click the change password button.
     */
    public void clickChangePasswordButton() {
        changePasswordButton.click();
    }
}
