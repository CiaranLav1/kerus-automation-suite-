package driver;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Created by heather.reid on 06/05/16.
 * This is a webdriver class that injects the
 * browser driver for the tests.
 */
public class DriverManager {
    public static WebDriver get()
    {
        String ChromeDriverLocation = "/home/dev/Documents/kerus-test/chromedriver";
        System.setProperty("webdriver.chrome.driver", ChromeDriverLocation);
        return new ChromeDriver();
    }
}
