package myaccount;

import driver.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.SecurityQuestionsPage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by heather.reid on 09/05/16.
 */
public class SecurityQuestionsTest {

    private static WebDriver driver;
    private static LoginPage loginPage;
    private static HomePage homePage;
    private static SecurityQuestionsPage securityQuestionsPage;

    /**
     * SuperAdmin login information.
     */
    private String superAdminDomain = "SuperAdmin";
    private String username = "admin@exploristics.com";
    private String password1 = "Admin123!";

    // String header to check on the login page.
    private String loginPageHeaderContains = "Please login";
    private String forgotLoginLinkContains = "Forgot Login";

    // String headers to check on the home page.
    private String homePageHeaderContains = "Welcome Super Admin";
    private String kerusAdminHeaderContains = "KERUS ADMINISTRATION";
    private String domainManagementHeaderContains = "DOMAIN MANAGEMENT";
    private String myAccountHeaderContains = "MY ACCOUNT";

    // String to check the Security Questions button.
    private String securityQuestionsButtonContains = "Security Questions";

    // Strings to check on the Your details page.
    private String securityQuestionsPageHeaderContains = "UPDATE SECURITY QUESTIONS";
    private String securityQuestionsBreadcrumbContains = "Security Questions";
    private String confirmButtonContains = "Confirm";
    private String securityQuestion1LabelContains = "Security Question 1";
    private String securityQuestion1FieldContains = "What is your mother maiden name?";
    private String hintLabelContains = "Hint";
    private String hint1FieldContains = "hint1";
    private String answerLabelContains = "Answer";
    private String answer1FieldContains = "";
    private String securityQuestion2LabelContains = "Security Question 2";
    private String securityQuestion2FieldContains = "What is your favourite colour?";
    private String hint2FieldContains = "hint2";
    private String answer2FieldContains = "";
    private String securityQuestion3LabelContains = "Security Question 3";
    private String securityQuestion3FieldContains = "What is the name of your first pet?";
    private String hint3FieldContains = "hint3";
    private String answer3FieldContains = "";

    @BeforeClass
    public void setup() {
        driver = DriverManager.get();
        driver.manage().window().maximize();

        // Declare that we plan to use the login page and homepage.
        loginPage = new LoginPage(driver);

        /**
         * Check that the header on the login page is correct.
         * Also check that the forgot login link is present.
         */
        assertThat(loginPage.getPageHeader(), containsString(loginPageHeaderContains));
        assertThat(loginPage.getForgotLoginLink(), containsString(forgotLoginLinkContains));

        /**
         * Login as SuperAdmin and wait for the home
         * page to display.
         */
        loginPage.enterUserDetails(superAdminDomain, username, password1);
        loginPage.clickLoginButton();
    }

    @Test (description = "TCM-352 - verify that user can view & edit their security questions")
    public void verifyViewSecurityQuestions() throws InterruptedException {
        homePage = new HomePage(driver);
        /**
         * Check all of the headers on the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderContains));
        assertThat(homePage.getKerusAdminHeader(), containsString(kerusAdminHeaderContains));
        assertThat(homePage.getDomainManagementHeader(), containsString(domainManagementHeaderContains));
        assertThat(homePage.getMyAccountHeader(), containsString(myAccountHeaderContains));
        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(homePage.getHomeIcon(), equalTo(true));
        assertThat(homePage.getLogoutIcon(), equalTo(true));
        // Check that the button is there.
        assertThat(homePage.getSecurityQuestionsButton(), containsString(securityQuestionsButtonContains));
        // Navigate to the page
        homePage.clickSecurityQuestionsButton();

        securityQuestionsPage = new SecurityQuestionsPage(driver);

        /**
         * Check that all of the correct text in the
         * fields and their labels.
         */
        assertThat(securityQuestionsPage.getSecurityQuestionsPageHeader(), containsString(securityQuestionsPageHeaderContains));
        assertThat(securityQuestionsPage.getSecurityQuestionsBreadcrumb(), containsString(securityQuestionsBreadcrumbContains));
        assertThat(securityQuestionsPage.getHomeIcon(), equalTo(true));
        assertThat(securityQuestionsPage.getLogoutIcon(), equalTo(true));
        assertThat(securityQuestionsPage.getConfirmButton(), containsString(confirmButtonContains));
        // Security question 1.
        Thread.sleep(4000);
        assertThat(securityQuestionsPage.getSecurityQuestion1Label(), containsString(securityQuestion1LabelContains));
        assertThat(securityQuestionsPage.getSecurityQuestion1Field(), containsString(securityQuestion1FieldContains));
        assertThat(securityQuestionsPage.getAnswer1Label(), containsString(answerLabelContains));
        assertThat(securityQuestionsPage.getAnswer1Field(), containsString(answer1FieldContains));
        assertThat(securityQuestionsPage.getHint1Label(), containsString(hintLabelContains));
        /**
         * TODO field is not editable yet so the text can't be tested from it.
         */
        //assertThat(securityQuestionsPage.getHint1Field(), containsString(hint1FieldContains));
        // Security question 2.
        Thread.sleep(4000);
        assertThat(securityQuestionsPage.getSecurityQuestion2Label(), containsString(securityQuestion2LabelContains));
        assertThat(securityQuestionsPage.getSecurityQuestion2Field(), containsString(securityQuestion2FieldContains));
        assertThat(securityQuestionsPage.getAnswer2Label(), containsString(answerLabelContains));
        assertThat(securityQuestionsPage.getAnswer2Field(), containsString(answer2FieldContains));
        assertThat(securityQuestionsPage.getHint2Label(), containsString(hintLabelContains));
        /**
         * TODO field is not editable yet so the text can't be tested from it.
         */
        //assertThat(securityQuestionsPage.getHint2Field(), containsString(hint2FieldContains));
        // Security question 3.
        Thread.sleep(4000);
        assertThat(securityQuestionsPage.getSecurityQuestion3Label(), containsString(securityQuestion3LabelContains));
        assertThat(securityQuestionsPage.getSecurityQuestion3Field(), containsString(securityQuestion3FieldContains));
        assertThat(securityQuestionsPage.getAnswer3Label(), containsString(answerLabelContains));
        assertThat(securityQuestionsPage.getAnswer3Field(), containsString(answer3FieldContains));
        assertThat(securityQuestionsPage.getHint3Label(), containsString(hintLabelContains));
        /**
         * TODO field is not editable yet so the text can't be tested from it.
         */
        //assertThat(securityQuestionsPage.getHint3Field(), containsString(hint3FieldContains));

        /**
         * TODO need to add in the tests for edit when functionality is added to the application for it.
         */
    }

    @AfterClass
    public void tearDown(){
        driver.quit();
    }
}
