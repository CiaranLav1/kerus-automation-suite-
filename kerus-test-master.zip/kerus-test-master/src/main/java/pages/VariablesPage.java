package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 16/05/16.
 * Setting up the Page Object for the
 * Variables page.
 */
public class VariablesPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public VariablesPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("variableHeader")));
    }

    /**
     * Locators for the navigation links.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "studiesLink")
    private WebElement allStudiesBreadcrumb;

    @FindBy(how = How.ID, using = "cStudiesLink")
    private WebElement currentStudyBreadcrumb;

    @FindBy(how = How.ID, using = "variablesLink")
    private WebElement variablesBreadcrumb;

    /**
     * Locators for the section headers.
     */
    @FindBy(how = How.ID, using = "variableHeader")
    private WebElement variablesHeader;

    @FindBy(how = How.ID, using = "variableListHeader")
    private WebElement variableListHeader;

    /**
     * Locators for the field labels and
     * fields for entry.
     */
    @FindBy(how = How.ID, using = "variableLabel")
    public WebElement variableFieldLabel;

    @FindBy(how = How.ID, using = "variable.label")
    public WebElement variableLabelTextbox;

    @FindBy(how = How.ID, using = "variableDescription")
    public WebElement variableDescriptionFieldLabel;

    @FindBy(how = How.ID, using = "variable.description")
    public WebElement variableDescriptionTextbox;

    @FindBy(how = How.ID, using = "variableDistribution")
    public WebElement variableDistributionFieldLabel;

    @FindBy(how = How.ID, using = "variable.distribution")
    public WebElement variableDistributionTextbox;

    /**
     * Locators for the buttons in the
     * Variables section.
     */
    @FindBy(how = How.ID, using = "saveVariable")
    public WebElement createButton;

    @FindBy(how = How.ID, using = "resetVariable")
    public WebElement cancelButton;

    /**
     * Locator for the table.
     */
    @FindBy(how = How.ID, using = "variables")
    private WebElement variablesTable;

    /**
     * Get the strings from the navigation links.
     */
    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getAllStudiesBreadcrumb() {
        return allStudiesBreadcrumb.getText();
    }

    public String getCurrentStudyBreadcrumb() {
        return currentStudyBreadcrumb.getText();
    }

    public String getVariablesBreadcrumb() {
        return variablesBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    /**
     * Get the strings for the section headers.
     */
    public String getVariablesHeader() {
        return variablesHeader.getText();
    }

    public String getVariablesListHeader() {
        return variableListHeader.getText();
    }

    /**
     * Get the strings for the field labels.
     */
    public String getVariableLabelLabel() {
        return variableFieldLabel.getText();
    }

    public String getVariableDescriptionLabel() {
        return variableDescriptionFieldLabel.getText();
    }

    public String getVariableDistributionLabel() {
        return variableDistributionFieldLabel.getText();
    }

    public String getVariableDistributionField() {
        Select distributionList = new Select(variableDistributionTextbox);
        return distributionList.getFirstSelectedOption().getText();
    }

    /**
     * Get the strings for the buttons in the
     * Variables section.
     */
    public String getSubmitButton() {
        return createButton.getText();
    }

    public String getCancelButton() {
        return cancelButton.getText();
    }

    /**
     * Get the text from the column headers.
     */
    public List<String> getTableColumnHeaders() {
        Table allVariablesTable = new Table(variablesTable);
        return allVariablesTable.readAllColumnHeaders();
    }

    /**
     * Get the strings for the entries.
     */
    public String getTableColumnEntry(String columnHeader, String cellValue) {
        Table allVariablesTable = new Table(variablesTable);
        return allVariablesTable.findCellByColumnAndKnownValue(columnHeader, cellValue).getText();
    }

    public String getParametersColumnEntry(String headerToSearch, String variableLabel) {
        Table allVariablesTable = new Table(variablesTable);

        return allVariablesTable.findOnlyLinkButtonInCell(headerToSearch, variableLabel, "Label").getText();
    }

    /**
     * Methods to check that the buttons in the actions
     * cell are displayed.
     */
    public Boolean editButtonTableEntryDisplayed(String variableLabel) {
        try {
            Table allVariablesTable = new Table(variablesTable);
            return allVariablesTable.findIndexedButtonInCell("Actions", variableLabel, "Label", 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean copyButtonTableEntryDisplayed(String variableLabel) {
        try {
            Table allVariablesTable = new Table(variablesTable);
            return allVariablesTable.findIndexedButtonInCell("Actions", variableLabel, "Label", 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean deleteButtonTableEntryDisplayed(String variableLabel) {
        try {
            Table allVariablesTable = new Table(variablesTable);
            return allVariablesTable.findIndexedButtonInCell("Actions", variableLabel, "Label", 3).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Method to enter the variable information.
     */
    public void enterVariableInformation(String variableLabel, String variableDescription, String distribution) {
        variableLabelTextbox.sendKeys(variableLabel);
        variableDescriptionTextbox.sendKeys(variableDescription);

        Select distributionList = new Select(variableDistributionTextbox);
        distributionList.selectByVisibleText(distribution);
    }

    /**
     * Method to click the add button.
     */
    public void clickCreateButton() {
        createButton.click();
    }

    /**
     * Method to click the reset button.
     */
    public void clickCancelButton() {
        cancelButton.click();
    }

    /**
     * Methods to click buttons in the All Projects table.
     */
    public void clickTableEditButton(String variableLabel) {
        Table allVariablesTable = new Table(variablesTable);

        allVariablesTable.findOnlyLinkButtonInCell("Actions", variableLabel, "Label").click();
    }

    public void clickTableCopyButton(String variableLabel) {
        Table allVariablesTable = new Table(variablesTable);

        allVariablesTable.findIndexedButtonInCell("Actions", variableLabel, "Label", 1).click();
    }

    public void clickTableDeleteButton(String variableLabel) {
        Table allVariablesTable = new Table(variablesTable);

        allVariablesTable.findIndexedButtonInCell("Actions", variableLabel, "Label", 2).click();
    }

    public void clickSetUnsetLink(String headerToSearch, String variableLabel) {
        Table allVariablesTable = new Table(variablesTable);

        allVariablesTable.findOnlyLinkButtonInCell(headerToSearch, variableLabel, "Label").click();
    }

    /**
     * Method to click the Current Study breadcrumb.
     */
    public void clickCurrentStudyBreadcrumb() {
        currentStudyBreadcrumb.click();
    }

    public void clickCurrentProjectBreadcrumb() {
        currentProjectBreadcrumb.click();
    }

    /**
     * Method to get the URL of the page.
     */
    public String getURL() {
        return driver.getCurrentUrl();
    }
}
