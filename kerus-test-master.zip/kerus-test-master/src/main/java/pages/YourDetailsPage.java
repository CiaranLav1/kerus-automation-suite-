package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 09/05/16.
 * Setting up the Your Details (Settings) Page object.
 */
public class YourDetailsPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public YourDetailsPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("accDetailsHeader")));
    }

    /**
     * Locators for page elements.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "settings")
    private WebElement yourDetailsBreadcrumb;

    @FindBy(how = How.ID, using = "accDetailsHeader")
    private WebElement yourDetailsPageHeader;

    // Edit button.
    @FindBy(how = How.ID, using = "edit")
    private WebElement editButton;

    // Field labels and field entry boxes.
    @FindBy(how = How.ID, using = "emailLabel")
    private WebElement alternativeEmailFieldLabel;

    @FindBy(how = How.ID, using = "emailForm")
    private WebElement alternativeEmailTextbox;

    @FindBy(how = How.ID, using = "securityLabel1")
    private WebElement securityQuestion1FieldLabel;

    @FindBy(how = How.ID, using = "securityForm1")
    private WebElement securityQuestion1Textbox;

    @FindBy(how = How.ID, using = "hintLabel1")
    private WebElement hint1FieldLabel;

    @FindBy(how = How.ID, using = "hintForm1")
    private WebElement hint1Textbox;

    @FindBy(how = How.ID, using = "answerLabel1")
    private WebElement answer1FieldLabel;

    @FindBy(how = How.ID, using = "answerForm1")
    private WebElement answer1Textbox;

    @FindBy(how = How.ID, using = "securityLabel2")
    private WebElement securityQuestion2FieldLabel;

    @FindBy(how = How.ID, using = "securityForm2")
    private WebElement securityQuestion2Textbox;

    @FindBy(how = How.ID, using = "hintLabel2")
    private WebElement hint2FieldLabel;

    @FindBy(how = How.ID, using = "hintForm2")
    private WebElement hint2Textbox;

    @FindBy(how = How.ID, using = "answerLabel2")
    private WebElement answer2FieldLabel;

    @FindBy(how = How.ID, using = "answerForm2")
    private WebElement answer2Textbox;

    @FindBy(how = How.ID, using = "securityLabel3")
    private WebElement securityQuestion3FieldLabel;

    @FindBy(how = How.ID, using = "securityForm3")
    private WebElement securityQuestion3Textbox;

    @FindBy(how = How.ID, using = "hintLabel3")
    private WebElement hint3FieldLabel;

    @FindBy(how = How.ID, using = "hintForm3")
    private WebElement hint3Textbox;

    @FindBy(how = How.ID, using = "answerLabel3")
    private WebElement answer3FieldLabel;

    @FindBy(how = How.ID, using = "answerForm3")
    private WebElement answer3Textbox;

    /**
     * Get the field labels on the page.
     */
    public String getYourDetailsPageHeader() {
        return yourDetailsPageHeader.getText();
    }

    public String getYourDetailsBreadcrumb() {
        return yourDetailsBreadcrumb.getText();
    }

    public String getEditButton() {
        return editButton.getText();
    }

    public String getAlternativeEmailLabel() {
        return alternativeEmailFieldLabel.getText();
    }

    public String getAlternativeEmailField() {
        return alternativeEmailTextbox.getText();
    }

    public String getSecurityQuestion1Label() {
        return securityQuestion1FieldLabel.getText();
    }

    public String getSecurityQuestion1Field() {
        return securityQuestion1Textbox.getText();
    }

    public String getHint1Label() {
        return hint1FieldLabel.getText();
    }

    public String getHint1Field() {
        return hint1Textbox.getText();
    }

    public String getAnswer1Label() {
        return answer1FieldLabel.getText();
    }

    public String getAnswer1Field() {
        return answer1Textbox.getText();
    }

    public String getSecurityQuestion2Label() {
        return securityQuestion2FieldLabel.getText();
    }

    public String getSecurityQuestion2Field() {
        return securityQuestion2Textbox.getText();
    }

    public String getHint2Label() {
        return hint2FieldLabel.getText();
    }

    public String getHint2Field() {
        return hint2Textbox.getText();
    }

    public String getAnswer2Label() {
        return answer2FieldLabel.getText();
    }

    public String getAnswer2Field() {
        return answer2Textbox.getText();
    }

    public String getSecurityQuestion3Label() {
        return securityQuestion3FieldLabel.getText();
    }

    public String getSecurityQuestion3Field() {
        return securityQuestion3Textbox.getText();
    }

    public String getHint3Label() {
        return hint3FieldLabel.getText();
    }

    public String getHint3Field() {
        return hint3Textbox.getText();
    }

    public String getAnswer3Label() {
        return answer3FieldLabel.getText();
    }

    public String getAnswer3Field() {
        return answer3Textbox.getText();
    }

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    /**
     * Method to click the Home link.
     */
    public void clickHomeLink() {
        homeIcon.click();
    }
    /**
     * Method to click the logout link.
     */
    public void clickLogoutLink() {
        logoutIcon.click();
    }

    /**
     * Method to click the Edit button.
     */
    public void clickEditButton() {
        editButton.click();
    }
}
