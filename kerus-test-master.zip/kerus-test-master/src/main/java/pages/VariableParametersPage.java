package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

import static org.openqa.selenium.support.ui.ExpectedConditions.invisibilityOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.visibilityOfElementLocated;

/**
 * Created by heather.reid on 16/05/16.
 * Setting up the page object for the
 * variable parameters page.
 */
public class VariableParametersPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public VariableParametersPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("variableParametersHeader")));
    }

    /**
     * Locator for page headers.
     */
    @FindBy(how = How.ID, using = "variableHeader")
    private WebElement variableLabelHeader;

    @FindBy(how = How.ID, using = "variableParametersHeader")
    private WebElement variableParametersHeader;

    /**
     * Locator for the back button.
     */
    @FindBy(how = How.ID, using = "backLink")
    private WebElement backButton;

    /**
     * Locator for the table.
     */
    @FindBy(how = How.ID, using = "groupTable")
    private WebElement parametersTable;

    @FindBy(how = How.ID, using = "groupTable")
    private WebElement parametersTable2;

    /**
     * Locators for the buttons, NOTE: not
     * always visible on the page.
     */
    @FindBy(how = How.ID, using = "editButton")
    public WebElement editButton;

    @FindBy(how = How.ID, using = "submitButton")
    public WebElement saveButton;

    @FindBy(how = How.ID, using = "cancelButton")
    public WebElement cancelButton;

    /**
     * Get text from the page headers.
     */
    public String getVariableLabelHeader() {
        return variableLabelHeader.getText();
    }

    public String getVariableParametersHeader() {
        return variableParametersHeader.getText();
    }

    /**
     * Get the text from the column headers.
     */
    public List<String> getTableColumnHeaders() {
        Table parameterEntryTable = new Table(parametersTable);
        return parameterEntryTable.readAllColumnHeaders();
    }

    /**
     * Get text from the row headers.
     */
    public List<String> getTableRowHeaders() {
        Table parameterEntryTable = new Table(parametersTable);
        return parameterEntryTable.readAllDataFromColumnWithNoHeader(1);
    }

    /**
     * Get Row entries given column header.
     */
    public List<String> getParameterColumnEntries(String columnHeader) {
        Table parameterEntryTable = new Table(parametersTable);
        return parameterEntryTable.readAllDataFromAMismatchColumn(columnHeader);
    }

    /**
     * Get text from the buttons
     */
    public String getEditButton() {
        return editButton.getText();
    }

    public String getSaveButton() {
        return saveButton.getText();
    }

    public String getCancelButton() {
        return cancelButton.getText();
    }

    /**
     * Method to click the edit button.
     */
    public void clickEditButton() {
        editButton.click();
    }

    /**
     * Method to enter variable parameters
     * given column header and row headers.
     */
    public void enterDistributionParameters(String columnHeader, List<String> parametersToEnter, List<String> rowHeaders) throws Exception {
        Table parameterEntryTable = new Table(parametersTable2);
        if (rowHeaders.size() == parametersToEnter.size()) {
            for (int i = 0; i < rowHeaders.size(); i++) {
                parameterEntryTable.readColumnValueForRowMismatchHeader(columnHeader, rowHeaders.get(i), 2).sendKeys(parametersToEnter.get(i));
            }
        }
    }

    /**
     * Method to click the back button.
     */
    public void clickBackButton() {
        backButton.click();;
    }

    /**
     * Method to click the ok button.
     */
    public void clickOkButton() {
        saveButton.click();
    }

    /**
     * Method to click the cancel button.
     */
    public void clickCancelButton() {
        cancelButton.click();
    }
}
