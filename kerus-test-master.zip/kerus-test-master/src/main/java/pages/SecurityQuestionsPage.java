package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

/**
 * Created by heather.reid on 09/05/16.
 * Setting up the Security Questions page object.
 */
public class SecurityQuestionsPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public SecurityQuestionsPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 10);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("updateSecurityQuestionHeader")));
    }

    /**
     * Locators for page elements.
     */
    // Header links
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "sQ")
    private WebElement securityQuestionsBreadcrumb;

    @FindBy(how = How.ID, using = "updateSecurityQuestionHeader")
    private WebElement securityQuestionsPageHeader;

    // Confirm button.
    @FindBy(how = How.ID, using = "addSecurityQA")
    private WebElement confirmButton;

    // Security Questions, hints & answers.
    @FindBy(how = How.ID, using = "securityQuestionLabel1")
    private WebElement securityQuestion1FieldLabel;

    @FindBy(how = How.ID, using = "securityquestion1")
    private WebElement securityQuestion1Textbox;

    @FindBy(how = How.ID, using = "hintLabel1")
    private WebElement hint1FieldLabel;

    @FindBy(how = How.ID, using = "hint1")
    private WebElement hint1Textbox;

    @FindBy(how = How.ID, using = "answerLabel1")
    private WebElement answer1FieldLabel;

    @FindBy(how = How.ID, using = "securityanswer1")
    private WebElement answer1Textbox;

    @FindBy(how = How.ID, using = "securityQuestionLabel2")
    private WebElement securityQuestion2FieldLabel;

    @FindBy(how = How.ID, using = "securityquestion2")
    private WebElement securityQuestion2Textbox;

    @FindBy(how = How.ID, using = "hintLabel2")
    private WebElement hint2FieldLabel;

    @FindBy(how = How.ID, using = "hint2")
    private WebElement hint2Textbox;

    @FindBy(how = How.ID, using = "answerLabel2")
    private WebElement answer2FieldLabel;

    @FindBy(how = How.ID, using = "securityanswer2")
    private WebElement answer2Textbox;

    @FindBy(how = How.ID, using = "securityQuestionLabel3")
    private WebElement securityQuestion3FieldLabel;

    @FindBy(how = How.ID, using = "securityquestion3")
    private WebElement securityQuestion3Textbox;

    @FindBy(how = How.ID, using = "hintLabel3")
    private WebElement hint3FieldLabel;

    @FindBy(how = How.ID, using = "hint3")
    private WebElement hint3Textbox;

    @FindBy(how = How.ID, using = "answerLabel3")
    private WebElement answer3FieldLabel;

    @FindBy(how = How.ID, using = "securityanswer3")
    private WebElement answer3Textbox;

    /**
     * Get the field labels on the page.
     */
    public String getSecurityQuestionsPageHeader() {
        return securityQuestionsPageHeader.getText();
    }

    public String getSecurityQuestionsBreadcrumb() {
        return securityQuestionsBreadcrumb.getText();
    }

    public String getConfirmButton() {
        return confirmButton.getText();
    }

    public String getSecurityQuestion1Label(){
        return securityQuestion1FieldLabel.getText();
    }

    public String getSecurityQuestion1Field() {
        return securityQuestion1Textbox.getText();
    }

    public String getHint1Label() {
        return hint1FieldLabel.getText();
    }

    public String getHint1Field() {
        return hint1Textbox.getText();
    }

    public String getAnswer1Label() {
        return answer1FieldLabel.getText();
    }

    public String getAnswer1Field() {
        return answer1Textbox.getText();
    }

    public String getSecurityQuestion2Label() {
        return securityQuestion2FieldLabel.getText();
    }

    public String getSecurityQuestion2Field() {
        return securityQuestion2Textbox.getText();
    }

    public String getHint2Label() {
        return hint2FieldLabel.getText();
    }

    public String getHint2Field() {
        return hint2Textbox.getText();
    }

    public String getAnswer2Label() {
        return answer2FieldLabel.getText();
    }

    public String getAnswer2Field() {
        return answer2Textbox.getText();
    }

    public String getSecurityQuestion3Label() {
        return securityQuestion3FieldLabel.getText();
    }

    public String getSecurityQuestion3Field() {
        return securityQuestion3Textbox.getText();
    }

    public String getHint3Label() {
        return hint3FieldLabel.getText();
    }

    public String getHint3Field() {
        return hint3Textbox.getText();
    }

    public String getAnswer3Label() {
        return answer3FieldLabel.getText();
    }

    public String getAnswer3Field() {
        return answer3Textbox.getText();
    }

    /**
     * Get the navigation banner links.
     */
    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }
}
