package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

import utilities.Table;

/**
 * Created by heather.reid on 14/12/16.
 */
public class SubgroupBuilderPage extends PageObject {
    /**
     * Method for declaring webdriver.
     */
    public SubgroupBuilderPage(WebDriver driver) {
        super(driver);
        WebDriverWait wait = new WebDriverWait(driver, 20);
        wait.until(ExpectedConditions.presenceOfElementLocated(By.id("subgroupBuilderHeader")));
    }

    /**
     * Locators for breadcrumbs & Logout icon.
     */
    @FindBy(how = How.ID, using = "home")
    private WebElement homeIcon;

    @FindBy(how = How.ID, using = "logoutIcon")
    private WebElement logoutIcon;

    @FindBy(how = How.ID, using = "projectLink")
    private WebElement allProjectsBreadcrumb;

    @FindBy(how = How.ID, using = "cProjectLink")
    private WebElement currentProjectBreadcrumb;

    @FindBy(how = How.ID, using = "subgroupBuilderLink")
    private WebElement subgroupBuilderBreadcrumb;

    /**
     * Locators for the section headers.
     */
    @FindBy(how = How.ID, using = "subgroupBuilderHeader")
    private WebElement subgrpBuilderHeader;

    @FindBy(how = How.ID, using = "subgroupHeader")
    private WebElement subgroupListHeader;

    /**
     * Locators for subgroup builder selection options.
     */
    @FindBy(how = How.ID, using = "variableLabel1")
    private WebElement element1Label;

    @FindBy(how = How.ID, using = "varCheckbox1")
    private WebElement element1Checkbox;

    @FindBy(how = How.ID, using = "variableLabel2")
    private WebElement element2Label;

    @FindBy(how = How.ID, using = "varCheckbox2")
    private WebElement element2Checkbox;

    /**
     * Locators for buttons on the page.
     */
    @FindBy(how = How.ID, using = "saveSelection")
    private WebElement confirmButton;

    @FindBy(how = How.ID, using = "saveList")
    private WebElement saveButton;

    /**
     * Locator for the subgroup list table.
     */
    @FindBy(how = How.ID, using = "subgroupTable")
    private WebElement subgroupListTable;

    /**
     * Locator for the success message.
     */
    @FindBy(how = How.ID, using = "successMessage")
    private WebElement saveSuccessfulMessage;

    /**
     * Get the navigation banner links.
     */
    public String getAllProjectsBreadcrumb() {
        return allProjectsBreadcrumb.getText();
    }

    public String getCurrentProjectBreadcrumb() {
        return currentProjectBreadcrumb.getText();
    }

    public String getSubgroupBuilderBreadcrumb() {
        return subgroupBuilderBreadcrumb.getText();
    }

    public Boolean getHomeIcon() {
        return homeIcon.isDisplayed();
    }

    public Boolean getLogoutIcon() {
        return logoutIcon.isDisplayed();
    }

    /**
     * Get the text from the section headers.
     */
    public String getSubgroupBuilderHeader() {
        return subgrpBuilderHeader.getText();
    }

    public String getSubgroupListHeader() {
        return subgroupListHeader.getText();
    }

    /**
     * Get text from the buttons.
     */
    public String getConfirmButton() {
        return confirmButton.getText();
    }

    public String getSaveButton() {
        return saveButton.getText();
    }

    /**
     * Methods to check the options for the subgroup builder.
     */
    public String getElement1() {
        return element1Label.getText();
    }

    public String getElement2() {
        return element2Label.getText();
    }

    /**
     * Methods to check that all options for the subgroups
     * are default to unselected.
     */
    public Boolean element1CheckboxSelected() {
        return element1Checkbox.isSelected();
    }

    public Boolean element2CheckboxSelected() {
        return element2Checkbox.isSelected();
    }

    /**
     * Get the headers from the subgroup table.
     */
    public List<String> getTableColumnHeaders() {
        Table subgroupTable = new Table(subgroupListTable);
        return subgroupTable.readAllColumnHeaders();
    }

    /**
     * Get Row entries given column header.
     */
    public List<String> getColumnEntries(String columnHeader) {
        Table subgroupTable = new Table(subgroupListTable);
        return subgroupTable.readAllDataFromAColumn(columnHeader);
    }

    /**
     * Methods to check that the hide checkboxes present
     * and whether they are ticked or not.
     */
    public List<Boolean> getHideColumnEntries(String columnHeader) {
        Table subgroupTable = new Table(subgroupListTable);
        return subgroupTable.readAllCheckBoxesFromAColumn(columnHeader);
    }

    /**
     * Methods to check that the buttons in the actions
     * cell are displayed.
     */
    public Boolean editButtonTableEntryDisplayed(String headerToSearch, String knownValue, String knownValueHeader) {
        try {
            Table subgroupTable = new Table(subgroupListTable);
            return subgroupTable.findIndexedButtonInCell(headerToSearch, knownValue, knownValueHeader, 1).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    public Boolean deleteButtonTableEntryDisplayed(String headerToSearch, String knownValue, String knownValueHeader) {
        try {
            Table subgroupTable = new Table(subgroupListTable);
            return subgroupTable.findIndexedButtonInCell(headerToSearch, knownValue, knownValueHeader, 2).isDisplayed();
        } catch (org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }

    /**
     * Method to check the text of the success message.
     */
    public String getSuccessMessage() {
        return saveSuccessfulMessage.getText();
    }

    /**
     * Methods to select the options for the subgroups.
     */
    public void selectElement1() {
        element1Checkbox.click();
    }

    public void selectElement2() {
        element2Checkbox.click();
    }

    /**
     * Method to click the Confirm button.
     */
    public void clickConfirmButton() {
        confirmButton.click();
    }

    /**
     * Method to click the save button.
     */
    public void clickSaveButton() {
        saveButton.click();
    }

    /**
     * Method to click the Current Project breadcrumb.
     */
    public void clickCurrentProjectBreadcrumb() {
        currentProjectBreadcrumb.click();
    }
}
