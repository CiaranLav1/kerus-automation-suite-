package myaccount;

import driver.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.YourDetailsPage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by heather.reid on 09/05/16.
 */
public class YourDetailsTest {

    private static WebDriver driver;
    private static LoginPage loginPage;
    private static HomePage homePage;
    private static YourDetailsPage yourDetailsPage;

    // String header to check on the login page.
    private String loginPageHeaderContains = "Please login";
    private String forgotLoginLinkContains = "Forgot Login";

    /**
     * SuperAdmin login information.
     */
    private String superAdminDomain = "SuperAdmin";
    private String username = "admin@exploristics.com";
    private String password1 = "Admin123!";

    // String headers to check on the home page.
    private String homePageHeaderContains = "Welcome Super Admin";
    private String kerusAdminHeaderContains = "KERUS ADMINISTRATION";
    private String domainManagementHeaderContains = "DOMAIN MANAGEMENT";
    private String myAccountHeaderContains = "MY ACCOUNT";

    // String to check the Your Details button.
    private String yourDetailsButtonContains = "Your Details (Settings)";

    // Strings to check on the Your details page.
    private String yourDetailsPageHeaderContains = "ACCOUNT DETAILS";
    private String yourDetailsBreadcrumbContains = "Your Details";
    private String editButtonContains = "Edit";
    private String alternativeEmailLabelContains = "Alternative email Address";
    private String alternativeEmailFieldContains = "empty";
    private String securityQuestion1LabelContains = "Security Question 1";
    private String securityQuestion1FieldContains = "What is your mother maiden name?";
    private String hintLabelContains = "Hint";
    private String hint1FieldContains = "hint1";
    private String answerLabelContains = "Security Answer";
    private String answerFieldContains = "";
    private String securityQuestion2LabelContains = "Security Question 2";
    private String securityQuestion2FieldContains = "What is your favourite colour?";
    private String hint2FieldContains = "hint2";
    private String securityQuestion3LabelContains = "Security Question 3";
    private String securityQuestion3FieldContains = "What is the name of your first pet?";
    private String hint3FieldContains = "hint3";

    @BeforeClass
    public void setup() {
        driver = DriverManager.get();
        driver.manage().window().maximize();

        // Declare that we plan to use the login page and homepage.
        loginPage = new LoginPage(driver);

        /**
         * Check that the header on the login page is correct.
         * Also check that the forgot login link is present.
         */
        assertThat(loginPage.getPageHeader(), containsString(loginPageHeaderContains));
        assertThat(loginPage.getForgotLoginLink(), containsString(forgotLoginLinkContains));
        /**
         * Login as SuperAdmin and wait for the home
         * page to display.
         */
        loginPage.enterUserDetails(superAdminDomain, username, password1);
        loginPage.clickLoginButton();
    }

    @Test (description = "TCM-351 - Verify that a user can view their account details")
    public void verifyViewAccountDetails() throws InterruptedException {
        homePage = new HomePage(driver);

        /**
         * Check all of the headers on the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderContains));
        assertThat(homePage.getKerusAdminHeader(), containsString(kerusAdminHeaderContains));
        assertThat(homePage.getDomainManagementHeader(), containsString(domainManagementHeaderContains));
        assertThat(homePage.getMyAccountHeader(), containsString(myAccountHeaderContains));
        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(homePage.getHomeIcon(), equalTo(true));
        assertThat(homePage.getLogoutIcon(), equalTo(true));

        // Check that the button is there to click
        assertThat(homePage.getYourDetailsSettingsButton(), containsString(yourDetailsButtonContains));
        // Navigate to the page
        homePage.clickYourDetailsButton();

        yourDetailsPage = new YourDetailsPage(driver);

        /**
         * Check that the Home & Logout links are visible.
         * Also check the breadcrumbs.
         */
        assertThat(yourDetailsPage.getHomeIcon(), equalTo(true));
        assertThat(yourDetailsPage.getYourDetailsBreadcrumb(), containsString(yourDetailsBreadcrumbContains));
        assertThat(yourDetailsPage.getLogoutIcon(), equalTo(true));

        /**
         * Check that all of the correct text in the
         * fields and their labels.
         */
        assertThat(yourDetailsPage.getYourDetailsPageHeader(), containsString(yourDetailsPageHeaderContains));
        assertThat(yourDetailsPage.getEditButton(), containsString(editButtonContains));
        assertThat(yourDetailsPage.getAlternativeEmailLabel(), containsString(alternativeEmailLabelContains));
        assertThat(yourDetailsPage.getAlternativeEmailField(), containsString(alternativeEmailFieldContains));
        // Security question 1.
        assertThat(yourDetailsPage.getSecurityQuestion1Label(), containsString(securityQuestion1LabelContains));
        assertThat(yourDetailsPage.getSecurityQuestion1Field(), containsString(securityQuestion1FieldContains));
        assertThat(yourDetailsPage.getAnswer1Label(), containsString(answerLabelContains));
        assertThat(yourDetailsPage.getAnswer1Field(), containsString(answerFieldContains));
        assertThat(yourDetailsPage.getHint1Label(), containsString(hintLabelContains));
        assertThat(yourDetailsPage.getHint1Field(), containsString(hint1FieldContains));
        // Security question 2.
        assertThat(yourDetailsPage.getSecurityQuestion2Label(), containsString(securityQuestion2LabelContains));
        assertThat(yourDetailsPage.getSecurityQuestion2Field(), containsString(securityQuestion2FieldContains));
        assertThat(yourDetailsPage.getAnswer2Label(), containsString(answerLabelContains));
        assertThat(yourDetailsPage.getAnswer2Field(), containsString(answerFieldContains));
        assertThat(yourDetailsPage.getHint2Label(), containsString(hintLabelContains));
        assertThat(yourDetailsPage.getHint2Field(), containsString(hint2FieldContains));
        // Security question 3.
        assertThat(yourDetailsPage.getSecurityQuestion3Label(), containsString(securityQuestion3LabelContains));
        assertThat(yourDetailsPage.getSecurityQuestion3Field(), containsString(securityQuestion3FieldContains));
        assertThat(yourDetailsPage.getAnswer3Label(), containsString(answerLabelContains));
        assertThat(yourDetailsPage.getAnswer3Field(), containsString(answerFieldContains));
        assertThat(yourDetailsPage.getHint3Label(), containsString(hintLabelContains));
        assertThat(yourDetailsPage.getHint3Field(), containsString(hint3FieldContains));
    }

    /**
     * TODO: add in the edit functionality once it
     * has been added to the application.
     */

    @AfterClass
    public void tearDown(){
        driver.quit();
    }
}
