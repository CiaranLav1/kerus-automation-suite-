package myaccount;


import driver.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.ChangePasswordPage;
import pages.HomePage;
import pages.LoginPage;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by heather.reid on 06/05/16.
 * This will test that a user who is logged
 * in can change their password in the My
 * Account section.
 */
public class ChangePasswordTest {

    private static WebDriver driver;
    private static LoginPage loginPage;
    private static HomePage homePage;
    private static ChangePasswordPage changePasswordPage;

    // String header to check on the login page.
    private String loginPageHeaderContains = "Please login";
    private String forgotLoginLinkContains = "Forgot Login";

    /**
     * User login information.
     */
    private String superAdminDomain = "SuperAdmin";
    private String username = "admin@exploristics.com";
    private String password1 = "Admin123!";
    private String password2 = "Password01!";

    // String headers to check on the home page.
    private String homePageHeaderContains = "Welcome Super Admin";
    private String kerusAdminHeaderContains = "KERUS ADMINISTRATION";
    private String domainManagementHeaderContains = "DOMAIN MANAGEMENT";
    private String myAccountHeaderContains = "MY ACCOUNT";

    // String to check the Change Password button.
    private String changePasswordButtonContains = "Change Password";

    // Field labels on the change password page.
    private String oldPasswordLabelContains = "Old Password";
    private String newPasswordLabelContains = "New Password";
    private String confirmPasswordLabelContains = "Confirm Password";

    // This will only be executed once if it is before class.
    @BeforeClass
    public void setup() {
        driver = DriverManager.get();
        driver.manage().window().maximize();

        // Declare that we plan to use the login page and homepage.
        loginPage = new LoginPage(driver);

        /**
         * Check that the header on the login page is correct.
         * Also check that the forgot login link is present.
         */
        assertThat(loginPage.getPageHeader(), containsString(loginPageHeaderContains));
        assertThat(loginPage.getForgotLoginLink(), containsString(forgotLoginLinkContains));

        /**
         * Login as SuperAdmin and wait for the home
         * page to display.
         */
        loginPage.enterUserDetails(superAdminDomain, username, password1);
        loginPage.clickLoginButton();
    }

    @Test (description = "TCM-350 - Verify that a user can change their password")
    public void verifyChangePassword() throws InterruptedException {
        homePage = new HomePage(driver);
        /**
         * Check all of the headers on the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderContains));
        assertThat(homePage.getKerusAdminHeader(), containsString(kerusAdminHeaderContains));
        assertThat(homePage.getDomainManagementHeader(), containsString(domainManagementHeaderContains));
        assertThat(homePage.getMyAccountHeader(), containsString(myAccountHeaderContains));
        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(homePage.getHomeIcon(), equalTo(true));
        assertThat(homePage.getLogoutIcon(), equalTo(true));

        // Check the text on the change password button.
        assertThat(homePage.getChangePasswordButton(), containsString(changePasswordButtonContains));

        // Click the change password button.
        homePage.clickChangePasswordButton();

        changePasswordPage = new ChangePasswordPage(driver);

        assertThat(changePasswordPage.getChangePasswordBreadcrumb(), containsString(changePasswordButtonContains));
        assertThat(changePasswordPage.getHomeIcon(), equalTo(true));
        assertThat(changePasswordPage.getLogoutIcon(), equalTo(true));

        /**
         * Check that the correct field labels are displayed.
         */
        assertThat(changePasswordPage.getOldPasswordLabel(), containsString(oldPasswordLabelContains));
        assertThat(changePasswordPage.getNewPasswordLabel(), containsString(newPasswordLabelContains));
        assertThat(changePasswordPage.getConfirmPasswordLabel(), containsString(confirmPasswordLabelContains));

        /**
         * Enter information to change password.
         */
        changePasswordPage.changeSuperAdminPassword(password1, password2);
        changePasswordPage.clickConfirmPassword();
        Thread.sleep(4000);
        /**
         * Check that user is directed back to
         * the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderContains));
        /**
         * Log out and then back in again to check
         * password successfully changed.
         */
        homePage.clickLogout();
        loginPage.enterUserDetails(superAdminDomain, username, password2);
        loginPage.clickLoginButton();
        Thread.sleep(4000);
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderContains));
        /**
         * Change password back to original.
         */
        homePage.clickChangePasswordButton();
        /**
         * Check that the correct field labels are displayed.
         */
        assertThat(changePasswordPage.getOldPasswordLabel(), containsString(oldPasswordLabelContains));
        assertThat(changePasswordPage.getNewPasswordLabel(), containsString(newPasswordLabelContains));
        assertThat(changePasswordPage.getConfirmPasswordLabel(), containsString(confirmPasswordLabelContains));
        /**
         * Change password.
         */
        changePasswordPage.changeSuperAdminPassword(password2, password1);
        changePasswordPage.clickConfirmPassword();
        Thread.sleep(4000);
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderContains));
    }


    @AfterClass
    public void tearDown(){
        driver.quit();
    }

}
