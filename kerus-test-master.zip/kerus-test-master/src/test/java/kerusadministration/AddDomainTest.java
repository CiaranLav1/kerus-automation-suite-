package kerusadministration;

import driver.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.NewDomainPage;

import java.util.concurrent.TimeUnit;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by heather.reid on 11/05/16.
 * This will test that when the SuperAdmin
 * user is logged in, they can create a new
 * domain in the Kerus Administration section.
 */
public class AddDomainTest {
    private static WebDriver driver;
    private static LoginPage loginPage;
    private static HomePage homePage;
    private static NewDomainPage newDomainPage;

    // String header to check on the login page.
    private String loginPageHeaderContains = "Please login";
    private String forgotLoginLinkContains = "Forgot Login";

    /**
     * SuperAdmin login information.
     */
    private String superAdminDomain = "SuperAdmin";
    private String username = "admin@exploristics.com";
    private String password1 = "Admin123!";

    // String headers to check on the home page.
    private String homePageHeaderSuperAdminContains = "Welcome Super Admin";
    private String homePageHeaderTestDomainContains = "Welcome Anne-Marie O'Neill";
    private String kerusAdminHeaderContains = "KERUS ADMINISTRATION";
    private String domainManagementHeaderContains = "DOMAIN MANAGEMENT";
    private String myAccountHeaderContains = "MY ACCOUNT";

    // String to check the Add Domain button on the Home Page.
    private String addDomainButtonContains = "Create Domain";

    // String Headers on the Add Domain page.
    private String domainSetupHeaderContains = "DOMAIN SETUP";
    private String domainAdminSetupHeaderContains = "DOMAIN ADMIN SETUP";

    // Field labels on the Add Domain page.
    private String domainLabelLabelContains = "Domain Label";
    private String customerRefLabelContains = "Customer Reference";
    private String licenceTypeListContains = "-- Please Select --";
    private String licenceTypeLabelContains = "Licence Type";
    private String accountTypeListContains = "-- Please Select --";
    private String accountTypeLabelContains = "Domain Account Type";
    private String usernameLabelContains = "Username";
    private String firstNameLabelContains = "First Name";
    private String surnameLabelContains = "Surname";
    private String passwordLabelContains = "Password";
    private String repeatPasswordLabelContains = "Repeat Password";
    private String alternativeEmailLabelContains = "Alternative Email Address";

    // Button labels on the Add Domain page.
    private String saveDomainButtonContains = "Save";

    /**
     * User information.
     */
    private String customerRef = "Custm001";
    private String licenceType = "Full";
    private String accountType = "Single User";
    private String firstName = "Anne-Marie";
    private String surname = "O'Neill";
    private String alternativeEmail = "user@exploristics.com";
    private String password2 = "Password01!";
    private String testingDomain = "TestingDomain";

    /**
     * This will only be executed once, before the
     * set of tests runs.
     */
    @BeforeClass
    public void setup() {
        driver = DriverManager.get();
        driver.manage().window().maximize();

        // Declare that we plan to use the login page and homepage.
        loginPage = new LoginPage(driver);

        /**
         * Check that the header on the login page is correct.
         * Also check that the forgot login link is present.
         */
        assertThat(loginPage.getPageHeader(), containsString(loginPageHeaderContains));
        assertThat(loginPage.getForgotLoginLink(), containsString(forgotLoginLinkContains));

        /**
         * Login as SuperAdmin and wait for the home
         * page to display.
         */
        loginPage.enterUserDetails(superAdminDomain, username, password1);
        loginPage.clickLoginButton();
    }

    @Test (description = "TCM-354 - verify that the Super Admin user can create a new domain")
    public void verifyAddDomain() throws InterruptedException {
        homePage = new HomePage(driver);

        /**
         * Check all of the headers on the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderSuperAdminContains));
        assertThat(homePage.getKerusAdminHeader(), containsString(kerusAdminHeaderContains));
        assertThat(homePage.getDomainManagementHeader(), containsString(domainManagementHeaderContains));
        assertThat(homePage.getMyAccountHeader(), containsString(myAccountHeaderContains));
        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(homePage.getHomeIcon(), equalTo(true));
        assertThat(homePage.getLogoutIcon(), equalTo(true));

        // Check the text on the add domain button.
        assertThat(homePage.getAddDomainButton(), containsString(addDomainButtonContains));

        // Click the add domain button.
        homePage.clickAddDomainButton();

        newDomainPage = new NewDomainPage(driver);

        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(newDomainPage.getHomeIcon(), equalTo(true));
        assertThat(newDomainPage.getLogoutIcon(), equalTo(true));
        assertThat(newDomainPage.getAddDomainBreadcrumb(), containsString(addDomainButtonContains));

        /**
         * Get the Section Headers.
         */
        assertThat(newDomainPage.getDomainSetupHeader(), containsString(domainSetupHeaderContains));
        assertThat(newDomainPage.getDomainAdminSetupHeader(), containsString(domainAdminSetupHeaderContains));

        /**
         * Check that the correct field labels are displayed.
         * Check that the two drop down lists have the correct
         * selection displayed.
         */
        assertThat(newDomainPage.getDomainLabelLabel(), containsString(domainLabelLabelContains));
        assertThat(newDomainPage.getCustomerRefLabel(), containsString(customerRefLabelContains));
        assertThat(newDomainPage.getLicenceTypeList(), containsString(licenceTypeListContains));
        assertThat(newDomainPage.getLicenceTypeLabel(), containsString(licenceTypeLabelContains));
        assertThat(newDomainPage.getAccountTypeList(), containsString(accountTypeListContains));
        assertThat(newDomainPage.getAccountTypeLabel(), containsString(accountTypeLabelContains));
        assertThat(newDomainPage.getUsernameLabel(), containsString(usernameLabelContains));
        assertThat(newDomainPage.getFirstNameLabel(), containsString(firstNameLabelContains));
        assertThat(newDomainPage.getSurnameLabel(), containsString(surnameLabelContains));
        assertThat(newDomainPage.getPasswordLabel(), containsString(passwordLabelContains));
        assertThat(newDomainPage.getRepeatPasswordLabel(), containsString(repeatPasswordLabelContains));
        assertThat(newDomainPage.getAlternativeEmailLabel(), containsString(alternativeEmailLabelContains));
        assertThat(newDomainPage.getAddDomainButton(), containsString(saveDomainButtonContains));

        /**
         * Enter information to create domain.
         */
        newDomainPage.enterTestingDomainDetails(testingDomain, customerRef, licenceType, accountType,
                username, firstName, surname, password2, alternativeEmail);
        newDomainPage.clickSaveButton();
        Thread.sleep(3000);
        /**
         * Check that user is directed back to
         * the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderSuperAdminContains));

        /**
         * Log out and then back in again as the new
         * user to check that it was created correctly.
         */
        homePage.clickLogout();
        loginPage.enterUserDetails(testingDomain, username, password2);
        loginPage.clickLoginButton();
        Thread.sleep(5000);
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderTestDomainContains));
    }

    @AfterClass
    public void tearDown(){
        driver.quit();
    }
}
