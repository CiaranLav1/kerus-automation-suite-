package domainmanagement;

import driver.DriverManager;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import pages.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;

/**
 * Created by heather.reid on 12/05/16.
 * This will test that when a user is
 * logged in they can navigate to the
 * projects page and create a project.
 */
public class ProjectsTest {
    private static WebDriver driver;
    private static LoginPage loginPage;
    private static HomePage homePage;
    private static ProjectsPage projectsPage;
    private static EditProjectDetailsPage editProjectDetailsPage;
    private static StudiesPage studiesPage;
    private static StudyHomePage studyHomePage;
    private static StudiesSamplesPage studiesSamplesPage;
    private static GroupPage groupPage;
    private static GroupAllocationsPage groupAllocationsPage;
    private static VariablesPage variablesPage;
    private static VariableParametersPage variableParametersPage;
    private static RelationPage relationPage;
    private static SubgroupBuilderPage subgroupBuilderPage;
    private static StatisticalAnalysisPlanPage statisticalAnalysisPlanPage;
    private static ObjectiveEvaluationPage objectiveEvaluationPage;

    // String header to check on the login page.
    private String loginPageHeaderContains = "Please login";
    private String forgotLoginLinkContains = "Forgot Login";

    /**
     * SuperAdmin login information.
     */
    private String superAdminDomain = "SuperAdmin";
    private String username = "admin@exploristics.com";
    private String password1 = "Admin123!";

    /**
     * Strings for breadcrumb navigation in the application.
     */
    // Strings for navigation banner.
    private String allProjectsBreadcrumbContains = "All Projects";
    private String currentProjectBreadcrumbContains = "Current Project";
    private String allStudiesBreadcrumbContains = "All Studies";
    private String currentStudyBreadcrumbContains = "Current Study";
    private String groupsBreadcrumbContains = "Groups";
    private String allocationsBreadcrumbContains = "Allocations";
    private String variablesBreadcrumbContains = "Variables";

    // String headers to check on the home page.
    private String homePageHeaderSuperAdminContains = "Welcome Super Admin";
    private String kerusAdminHeaderContains = "KERUS ADMINISTRATION";
    private String domainManagementHeaderContains = "DOMAIN MANAGEMENT";
    private String myAccountHeaderContains = "MY ACCOUNT";

    // String to check the Projects button on the Home Page.
    private String projectsButtonContains = "Projects";

    // String headers on the Projects page.
    private String allProjectsHeaderContains = "ALL PROJECTS";

    /**
     * Create Project section on the Projects
     * page, field labels and defaults.
     */
    private String projectLabelLabelContains = "Project Label";
    private String projectDescriptionLabelContains = "Project Description";
    private String seedLabelContains = "Seed";
    private String numberOfSimulationsLabelContains = "No. Simulations";
    private String numberOfSimulationsFieldContains = "100";

    // String footers on the Projects page.
    private String previousLinkContains = "Previous";
    private String nextLinkContains = "Next";
    private String showingEntriesTextContains = "Showing";

    /**
     * All Projects section fields and column headers.
     */
    private String blockEntriesTextContains = "Show";
    private String searchLabelContains = "Search";
    private String labelTableColumnHeaderContains = "Label";
    private String descriptionTableColumnHeaderContains = "Description";
    private String seedTableColumnHeaderContains = "Seed";
    private String simsTableColumnHeaderContains = "Sims";
    private String projectOwnerTableColumnHeaderContains = "Project Owner";
    private String actionsTableColumnHeaderContains = "Actions";

    // Buttons on the pages.
    private String createProjectButtonContains = "Create Project";
    private String createButtonContains = "Create";
    private String cancelButtonContains = "Cancel";
    private String editProjectDetailsButtonContains = "Edit Project Details";
    private String saveButtonContains = "Save";

    /**
     * Check that the created project appears
     * in the all projects table.
     */
    private String projectLabelTableEntry = "SeProj";
    private String projectDescriptionTableEntry = "I am a project for test automation.";
    private String seedTableEntry = "12";
    private String noOfSimulationsTableEntry = "115";

    /**
     * Check the text that appears on the dashboard
     * after user clicks on edit for project.
     */
    private String studiesButtonContains = "Studies";
    private String subgroupBuilderButtonContains = "Subgroup Builder";
    private String statisticalAnalysisPlanButtonContains = "Statistical Analysis Plan";
    private String objectiveEvaluationButtonContains = "Objective Evaluation";
    private String simulateButtonContains = "Simulate";
    private String outputButtonContains = "Output";

    /**
     * Strings to check on studies page.
     */
    private String createStudyButtonContains = "Create Study";
    private String allStudiesHeaderContains = "ALL STUDIES";
    private String statusTableColumnHeaderContains = "Status";
    private String studyLabelLabelContains = "Study Label";
    private String studyDescriptionLabelContains = "Study Description";
    private String studyLabelTableEntryContains = "SeStudy";
    private String studyDescriptionTableEntryContains = "I am a study for test automation.";
    private String studyStatusTableEntryContains = "Status";

    /**
     * Strings for checks on the Study Home page.
     */
    private String stageAHeaderContains = "STAGE A";
    private String stageBHeaderContains = "STAGE B";
    private String defineSampleSizesButtonContains = "1. Define Sample Sizes";
    private String defineGroupsButtonContains = "2. Define Groups";
    private String defineAllocationsButtonContains = "3. Define Allocations";
    private String defineVariablesButtonContains = "4. Define Variables";
    private String defineRelationsButtonContains = "5. Define Relations";
    private String editStudyDetailsButtonContains = "Edit Study Details";
    private String studyHomeURLContains = "localhost:9000/study/";

    /**
     * Strings for checks on the Studies Samples page.
     */
    private String sampleSizesHeaderContains = "SAMPLE SIZES";
    private String sampleSizesLabelContains = "Sample Size";
    private String addButtonContains = "Add";
    private String sampleSizesColumnHeaderContains = "Samples";
    private String sampleSize1Contains = "100";
    private String sampleSize2Contains = "200";

    /**
     * Strings for checks on the Group Page.
     */
    private String groupPageHeaderContains = "GROUPS";
    private String valueRankLabelContains = "Value/Rank";
    private String controlLabelContains = "Control";
    private String groupListHeaderContains = "GROUPS LIST";
    private String groupLabel1TableEntry = "Group1";
    private String groupDescriptionTableEntry = "I am a group for selenium testing";
    private String groupValueRank1TableEntry = "17";
    private String groupControlTrueTableEntry = "true";
    private String groupLabel2TableEntry = "Group2";
    private String groupValueRank2TableEntry = "30";
    private String groupControlFalseTableEntry = "false";
    private String groupLabel3TableEntry = "Group3";
    private String groupValueRank3TableEntry = "10";
    private String unicodeTrue = "✔"; //&#x2714
    private String unicodeFalse = "✘";//"&#x2718";
    private String proceedContains = "Proceed?";
    private String deleteGroupModalContains = "Deleting this group may affect the previously defined allocations, subgroups, statistical analysis plans, objectives, and derived variables. Are you sure you want to continue?";
    private String okButtonContains = "OK";

    /**
     * Strings for checks on the Group Allocation page.
     */
    private String allocationListHeader = "ALLOCATION LIST";
    private String allocation1TableEntry = "1.9";
    private String allocation2TableEntry = "5";
    private String allocation3TableEntry = "25";
    private String allocation4TableEntry = "75";

    /**
     * Strings for checks on the Variables Page.
     */
    private String variablesHeaderContains = "VARIABLES";
    private String variablesListHeaderContains = "VARIABLES LIST";
    private String variableLabelLabelContains = "Variable Label";
    private String variableDescriptionContains = "Variable Description";
    private String variableDistributionLabelContains = "Variable Distribution";
    private String pleaseSelectDashedFieldContains = "-- Please Select --";
    private String distributionDerivationTableHeaderContains = "Distribution/Derivation Type";
    private String parametersTableHeaderContains = "Parameters";
    private String unsetContains = "Unset";
    private String setContains = "Set";
    private String normalVariableLabel1Contains = "SeNorm";
    private String variable1DescriptionContains = "I am a variable for selenium tests.";
    private String normalDistributionContains = "Normal";
    private String binomialVariableLabel1Contains = "SeBin";
    private String binomialDistributionContains = "Binomial";

    /**
     * Strings for checks on the Variable Parameters page.
     */
    private String variableParametersHeaderContains = "VARIABLE PARAMETERS";
    private String meanHeaderContains = "Mean";
    private String standardDeviationHeaderContains = "Standard Deviation";
    private String defaultParameterValueContains = "Not Set";
    private String editButtonContains = "Edit";
    private String normalMean1Contains = "10";
    private String normalMean2Contains = "15";
    private String normalStandardDeviation1Contains = "19";
    private String normalStandardDeviation2Contains = "20.2";
    private String probabilityHeaderContains = "Probability";
    private String binomialProbability1Contains = "0.3";
    private String binomialProbability2Contains = "0.75";
    private String variablesPageURLContains = "ocalhost:9000/study/variable";

    /**
     * Strings for checks on the Relations page.
     */
    private String relationBreadcrumbContains = "Relations";
    private String relationsHeaderContains = "RELATIONS";
    private String relationListHeaderContains = "RELATION LIST";
    private String variable1LabelContains = "Variable 1";
    private String variable2LabelContains = "Variable 2";
    private String relationTypeLabelContains = "Relation Type";
    private String spearmanRho = "Spearman Rho";
    private String relationParametersLabelContains = "Relation Parameters";
    private String group = "Group";
    private String valueHeaderContains = "Value";
    private String relationValue1 = "0";
    private String relationValue2 = "-0.1";

    /**
     * Strings for checks on the Subgroup Builder page.
     */
    private String subgroupBuilderBreadcrumbContains = "Subgroup Builder";
    private String subgroupBuilderHeaderContains = "SUBGROUP BUILDER";
    private String confirmButtonContains = "Confirm";
    private String subgroupListHeaderContains = "SUBGROUPS LIST";
    private String subgroupTableHeaderContains = "Subgroup";
    private String hideTableHeaderContains = "Hide";
    private String successMessageContains = "Success! Subgroups have been saved correctly";

    /**
     * Strings for checks on the Statistical Analysis Plan page.
     */
    private String statisticalAnalysisPlanHeaderContains = "STATISTICAL ANALYSIS PLAN";
    private String variableFieldLabelContains = "Variable";
    private String testFieldLabelContains = "Test";
    private String groupingFieldLabelContains = "Grouping";
    private String bonferroniFieldLabelContains = "Perform Bonferroni Correction";
    private String defaultSAPFieldContains = "Please Select";
    private String sapListHeaderContains = "SAP LIST";
    private String twoSampleTTest = "Two Sample T-Test";
    private String anovaTest = "ANOVA";
    private String oneSampleTTest = "One Sample T-Test";
    private String emptyValue = "";

    /**
     * Strings for checks on the Objective evaluation page.
     */
    private String objectiveEvaluationHeader = "OBJECTIVE EVALUATION";
    private String objectiveListHeader = "OBJECTIVES LIST";
    private String statisticLabelContains = "Statistic";
    private String groupingComparisonLabelContains = "Grouping/Comparison";
    private String operatorLabelContains = "Operator";
    private String greaterThanLogic = ">";
    private String lessThanLogic = "<";
    private String equalToLogic = "==";
    private String greaterThanOrEqualToLogic = ">=";
    private String lessThanOrEqualToLogic = "<=";
    private String notEqualToLogic = "!=";
    private String combineObjectiveButtonContains = "Combine Objective";
    private String objectiveHeaderContains = "Objective";
    private String pValueContains = "P-Value";
    private String groupLabel2VSgroupLabel3 = "Group2 vs Group3";
    private String objectiveValue = "0.05";
    private String objectiveLabelContains = "Objective Label";
    private String objective1Label = "Two Sample T-Test objective for selenium1";

    /**
     * This will only be executed once, before the
     * set of tests runs.
     */
    @BeforeClass
    public void setup() {
        driver = DriverManager.get();
        driver.manage().window().maximize();

        // Declare that we plan to use the login page and homepage.
        loginPage = new LoginPage(driver);

        /**
         * Check that the header on the login page is correct.
         * Also check that the forgot login link is present.
         */
        assertThat(loginPage.getPageHeader(), containsString(loginPageHeaderContains));
        assertThat(loginPage.getForgotLoginLink(), containsString(forgotLoginLinkContains));

        /**
         * Login as SuperAdmin and wait for the home
         * page to display.
         */
        loginPage.enterUserDetails(superAdminDomain, username, password1);
        loginPage.clickLoginButton();
    }

    /**
     * Run this test first to create the project
     * for the other tests that will follow.
     */
    @Test (priority = 1, description = "TCM-355 - Test that a user can create a project.")
    public void verifyCreateProject() throws InterruptedException {
        homePage = new HomePage(driver);
        /**
         * Check all of the headers on the home page.
         */
        assertThat(homePage.getPageHeader(), containsString(homePageHeaderSuperAdminContains));
        assertThat(homePage.getKerusAdminHeader(), containsString(kerusAdminHeaderContains));
        assertThat(homePage.getDomainManagementHeader(), containsString(domainManagementHeaderContains));
        assertThat(homePage.getMyAccountHeader(), containsString(myAccountHeaderContains));
        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(homePage.getHomeIcon(), equalTo(true));
        assertThat(homePage.getLogoutIcon(), equalTo(true));

        // Check the text on the Projects button.
        assertThat(homePage.getProjectsButton(), containsString(projectsButtonContains));

        // Click the Projects button.
        homePage.clickProjectsButton();

        projectsPage = new ProjectsPage(driver);

        /**
         * Check that the Home & Logout links are visible.
         */
        assertThat(projectsPage.getHomeIcon(), equalTo(true));
        assertThat(projectsPage.getLogoutIcon(), equalTo(true));

        /**
         * Check that the Create Project button is visible.
         */
        assertThat(projectsPage.getCreateProjectButton(), containsString(createProjectButtonContains));

        /**
         * Check the headers on the page.
         */
        assertThat(projectsPage.getAllProjectsHeader(), containsString(allProjectsHeaderContains));
        assertThat(projectsPage.getHomeIcon(), equalTo(true));
        assertThat(projectsPage.getLogoutIcon(), equalTo(true));
        assertThat(projectsPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));

        /**
         * Check the footer items on the page.
         */
        assertThat(projectsPage.getPreviousLink(), containsString(previousLinkContains));
        assertThat(projectsPage.getNextLink(), containsString(nextLinkContains));
        assertThat(projectsPage.getShowingEntries(), containsString(showingEntriesTextContains));

        /**
         * Check the items in the All Projects section.
         */
        assertThat(projectsPage.getBlockEntriesText(), containsString(blockEntriesTextContains));
        assertThat(projectsPage.getSearchProjectsLabel(), containsString(searchLabelContains));

        List<String> ExpectedColumnHeaders = new ArrayList<String>();
        ExpectedColumnHeaders.add(labelTableColumnHeaderContains);
        ExpectedColumnHeaders.add(descriptionTableColumnHeaderContains);
        ExpectedColumnHeaders.add(seedTableColumnHeaderContains);
        ExpectedColumnHeaders.add(simsTableColumnHeaderContains);
        ExpectedColumnHeaders.add(projectOwnerTableColumnHeaderContains);
        ExpectedColumnHeaders.add(actionsTableColumnHeaderContains);
        assertThat(projectsPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        /**
         * Click the Create Project button.
         */
        projectsPage.clickCreateProjectButton();

        /**
         * Check that the correct field labels and
         * field defaults display.
         */
        assertThat(projectsPage.getAddProjectButton(), containsString(createButtonContains));
        assertThat(projectsPage.getCancelCreateProjectButton(), containsString(cancelButtonContains));
        assertThat(projectsPage.getProjectLabelLabelText(), containsString(projectLabelLabelContains));
        assertThat(projectsPage.getProjectDescriptionLabelText(), containsString(projectDescriptionLabelContains));
        assertThat(projectsPage.getSeedLabelText(), containsString(seedLabelContains));
        assertThat(projectsPage.getSimulationsLabelText(), containsString(numberOfSimulationsLabelContains));
        assertThat(projectsPage.getSimulationsFieldText(), containsString(numberOfSimulationsFieldContains));

        /**
         * Enter the project information.
         */
        projectsPage.enterProjectDetails(projectLabelTableEntry, projectDescriptionTableEntry, seedTableEntry, noOfSimulationsTableEntry);
        projectsPage.clickAddProjectButton();
        Thread.sleep(5000);
        /**
         * Check that the project displays in the
         * all projects list & all relevant fields
         * have correct information.
         * These are pretty redundant checks but
         * have to keep them for now to check I
         * haven't broken anything.
         */
        assertThat(projectsPage.getTableColumnEntry(labelTableColumnHeaderContains, projectLabelTableEntry), containsString(projectLabelTableEntry));
        assertThat(projectsPage.getTableColumnEntry(descriptionTableColumnHeaderContains, projectDescriptionTableEntry), containsString(projectDescriptionTableEntry));
        assertThat(projectsPage.getTableColumnEntry(seedTableColumnHeaderContains, seedTableEntry), containsString(seedTableEntry));
        assertThat(projectsPage.getTableColumnEntry(simsTableColumnHeaderContains, noOfSimulationsTableEntry), containsString(noOfSimulationsTableEntry));
        assertThat(projectsPage.getTableColumnEntry(projectOwnerTableColumnHeaderContains, username), containsString(username));

        /**
         * Click the action buttons for that project to
         * assert that they are present.
         */
        assertThat(projectsPage.copyButtonTableEntryDisplayed(projectLabelTableEntry), equalTo(true));
        assertThat(projectsPage.deleteButtonTableEntryDisplayed(projectLabelTableEntry), equalTo(true));
        assertThat(projectsPage.viewButtonTableEntryDisplayed(projectLabelTableEntry), equalTo(true));
    }

    @Test (priority = 2, description = "TCM-356 - Test that a user can edit project details.")
    public void verifyProjectHomePageIsDisplayedCorrectly() throws Exception {
        /**
         * Click on the edit button for the project on
         * the All Projects section of the Projects page.
         */
        projectsPage.clickTableEditButton(projectLabelTableEntry);

        editProjectDetailsPage = new EditProjectDetailsPage(driver);

        assertThat(editProjectDetailsPage.getEditProjectPageHeader(), containsString(projectLabelTableEntry));
        assertThat(editProjectDetailsPage.getEditProjectButton(), containsString(editProjectDetailsButtonContains));
        editProjectDetailsPage.clickEditProjectDetailsButton();

        /**
         * Check the header links on the page.
         */
        assertThat(editProjectDetailsPage.getHomeIcon(), equalTo(true));
        assertThat(editProjectDetailsPage.getLogoutIcon(), equalTo(true));
        assertThat(editProjectDetailsPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(editProjectDetailsPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));

        /**
         * Check that the information displayed in
         * the fields is correct and the field labels
         * are correct.
         */
        assertThat(editProjectDetailsPage.getProjectLabelLabelText(), containsString(projectLabelLabelContains));
        assertThat(editProjectDetailsPage.getProjectLabelFieldText(), containsString(projectLabelTableEntry));
        assertThat(editProjectDetailsPage.getProjectDescriptionLabelText(), containsString(projectDescriptionLabelContains));
        assertThat(editProjectDetailsPage.getProjectDescriptionFieldText(), containsString(projectDescriptionTableEntry));
        assertThat(editProjectDetailsPage.getSeedLabelText(), containsString(seedLabelContains));
        assertThat(editProjectDetailsPage.getSeedFieldText(), containsString(seedTableEntry));
        assertThat(editProjectDetailsPage.getSimulationsLabelText(), containsString(numberOfSimulationsLabelContains));
        assertThat(editProjectDetailsPage.getSimulationsFieldText(), containsString(noOfSimulationsTableEntry));

        /**
         * Check the buttons.
         */
        assertThat(editProjectDetailsPage.getSaveProjectButton(), containsString(saveButtonContains));
        assertThat(editProjectDetailsPage.getCancelProjectButton(), containsString(cancelButtonContains));

        /**
         * Check the Dashboard buttons.
         */
        assertThat(editProjectDetailsPage.getStudiesButton(), containsString(studiesButtonContains));
        assertThat(editProjectDetailsPage.getSubgroupBuilderButton(), containsString(subgroupBuilderButtonContains));
        assertThat(editProjectDetailsPage.getStatisticalAnalysisPlanButton(), containsString(statisticalAnalysisPlanButtonContains));
        assertThat(editProjectDetailsPage.getObjectiveEvaluationButton(), containsString(objectiveEvaluationButtonContains));
        assertThat(editProjectDetailsPage.getSimulateButton(), containsString(simulateButtonContains));
        assertThat(editProjectDetailsPage.getOutputButton(), containsString(outputButtonContains));
    }

    @Test (priority = 3, description = "TCM-357 & TCM-358 - Test that a user can navigate to studies page & create a study")
    public void verifyCreateStudy() throws InterruptedException {
        /**
         * Navigate to the studies page.
         */
        editProjectDetailsPage.clickStudiesButton();
        studiesPage = new StudiesPage(driver);

        /**
         * Check that the projects, studies & logout links are available.
         * Also check the page header & section header.
         */
        assertThat(studiesPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(studiesPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(studiesPage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(studiesPage.getHomeIcon(), equalTo(true));
        assertThat(studiesPage.getLogoutIcon(), equalTo(true));
        assertThat(studiesPage.getProjectHeader(), containsString(projectLabelTableEntry));
        assertThat(studiesPage.getAllStudiesHeader(), containsString(allStudiesHeaderContains));

        // Check the text on the create studies button.
        assertThat(studiesPage.getCreateStudiesButton(), containsString(createStudyButtonContains));

        /**
         * Check the footer items on the page.
         */
        assertThat(studiesPage.getPreviousLink(), containsString(previousLinkContains));
        assertThat(studiesPage.getNextLink(), containsString(nextLinkContains));
        assertThat(studiesPage.getShowingEntries(), containsString(showingEntriesTextContains));

        /**
         * Check the items in the All Studies section.
         */
        assertThat(studiesPage.getBlockEntriesText(), containsString(blockEntriesTextContains));
        assertThat(studiesPage.getSearchStudiesLabel(), containsString(searchLabelContains));
        List<String> ExpectedColumnHeaders = new ArrayList<String>();
        ExpectedColumnHeaders.add(labelTableColumnHeaderContains);
        ExpectedColumnHeaders.add(descriptionTableColumnHeaderContains);
        ExpectedColumnHeaders.add(statusTableColumnHeaderContains);
        ExpectedColumnHeaders.add(actionsTableColumnHeaderContains);
        assertThat(studiesPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        /**
         * Click the button to create a study and
         * check that the correct fields display
         * before entering valid information.
         */
        studiesPage.clickCreateStudyButton();
        assertThat(studiesPage.getStudyLabelLabelText(), containsString(studyLabelLabelContains));
        assertThat(studiesPage.getStudyDescriptionLabelText(), containsString(studyDescriptionLabelContains));
        assertThat(studiesPage.getAddStudyButton(), containsString(createButtonContains));
        assertThat(studiesPage.getCancelCreateStudyButton(), containsString(cancelButtonContains));

        /**
         * Enter the information to the fields and
         * click the create button.
         */
        studiesPage.enterStudyInformation(studyLabelTableEntryContains, studyDescriptionTableEntryContains);
        studiesPage.clickAddStudyButton();

        /**
         * Check that the study is added to the all
         * studies table.
         */
        Thread.sleep(4000);
        assertThat(studiesPage.getTableColumnEntry(labelTableColumnHeaderContains, studyLabelTableEntryContains), containsString(studyLabelTableEntryContains));
        assertThat(studiesPage.getTableColumnEntry(descriptionTableColumnHeaderContains, studyDescriptionTableEntryContains), containsString(studyDescriptionTableEntryContains));
        assertThat(studiesPage.getTableColumnEntry(statusTableColumnHeaderContains, studyStatusTableEntryContains), containsString(studyStatusTableEntryContains));

        /**
         * Check that the action buttons are.
         */
        assertThat(studiesPage.copyButtonTableEntryDisplayed(studyLabelTableEntryContains), equalTo(true));
        assertThat(studiesPage.deleteButtonTableEntryDisplayed(studyLabelTableEntryContains), equalTo(true));
        assertThat(studiesPage.viewButtonTableEntryDisplayed(studyLabelTableEntryContains), equalTo(true));
    }

    @Test (priority = 4, description = "TCM-359 - Test that user can navigate to study home page")
    public void verifyStudyHomePageIsDisplayedCorrectly() {
        /**
         * Click the edit button on the row for the study.
         */
        studiesPage.clickTableEditButton(studyLabelTableEntryContains);

        studyHomePage = new StudyHomePage(driver);

        studyHomePage.clickEditStudyDetailsButton();
        /**
         * Check the headers and header links.
         */
        assertThat(studyHomePage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(studyHomePage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(studyHomePage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(studyHomePage.getCurrentStudyBreadcrumb(), containsString(currentStudyBreadcrumbContains));
        assertThat(studyHomePage.getHomeIcon(), equalTo(true));
        assertThat(studyHomePage.getLogoutIcon(), equalTo(true));
        assertThat(studyHomePage.getStudyHomeHeader(), containsString(studyLabelTableEntryContains));
        assertThat(studyHomePage.getStageAHeaderHeader(), containsString(stageAHeaderContains));
        assertThat(studyHomePage.getStageBHeaderHeader(), containsString(stageBHeaderContains));

        /**
         * Check the edit details section.
         */
        assertThat(studyHomePage.getEditStudyDetailsButton(), containsString(editStudyDetailsButtonContains));
        assertThat(studyHomePage.getStudyLabelLabelText(), containsString(studyLabelLabelContains));
        assertThat(studyHomePage.getStudyLabelFieldText(), containsString(studyLabelTableEntryContains));
        assertThat(studyHomePage.getStudyDescriptionLabelText(), containsString(studyDescriptionLabelContains));
        assertThat(studyHomePage.getStudyDescriptionFieldText(), containsString(studyDescriptionTableEntryContains));
        assertThat(studyHomePage.getCancelButton(), containsString(cancelButtonContains));
        assertThat(studyHomePage.getSaveButton(), containsString(saveButtonContains));

        /**
         * Check the button text for buttons on the page.
         */
        assertThat(studyHomePage.getDefineSampleSizesButton(), containsString(defineSampleSizesButtonContains));
        assertThat(studyHomePage.getDefineGroupsButton(), containsString(defineGroupsButtonContains));
        assertThat(studyHomePage.getDefineAllocationsButton(), containsString(defineAllocationsButtonContains));
        assertThat(studyHomePage.getDefineVariablesButton(), containsString(defineVariablesButtonContains));
        assertThat(studyHomePage.getDefineRelationsButton(), containsString(defineRelationsButtonContains));
    }

    @Test (priority = 5, description = "TCM-360 - Test that user can add & delete sample size values")
    public void verifyAddDeleteSampleSize(){
        /**
         * Navigate to the page to add sample size values.
         */
        studyHomePage.clickDefineSampleSizesButton();
        studiesSamplesPage = new StudiesSamplesPage(driver);

        /**
         * Check that the page displays correctly.
         */
        assertThat(studiesSamplesPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(studiesSamplesPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(studiesSamplesPage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(studiesSamplesPage.getCurrentStudyBreadcrumb(), containsString(currentStudyBreadcrumbContains));
        assertThat(studiesSamplesPage.getSampleSizeBreadcrumb(), containsString(sampleSizesLabelContains));
        assertThat(studiesSamplesPage.getHomeIcon(), equalTo(true));
        assertThat(studiesSamplesPage.getLogoutIcon(), equalTo(true));
        assertThat(studiesSamplesPage.getSampleSizesHeader(), containsString(sampleSizesHeaderContains));
        assertThat(studiesSamplesPage.getSampleSizesLabel(), containsString(sampleSizesLabelContains));
        assertThat(studiesSamplesPage.getAddButton(), containsString(addButtonContains));

        /**
         * Enter the sample sizes. Check that
         * they appear in the sample sizes
         * table & the delete button appears
         * beside each entry.
         */
        studiesSamplesPage.enterSampleSizeValue(sampleSize1Contains);
        studiesSamplesPage.clickAddButton();

        List<String> ExpectedColumnHeaders = new ArrayList<String>();
        ExpectedColumnHeaders.add(sampleSizesColumnHeaderContains);
        ExpectedColumnHeaders.add(actionsTableColumnHeaderContains);
        assertThat(studiesSamplesPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));
        assertThat(studiesSamplesPage.getSamplesizeTableEntry(sampleSize1Contains), containsString(sampleSize1Contains));
        assertThat(studiesSamplesPage.deleteButtonTableEntryDisplayed(sampleSize1Contains), equalTo(true));

        studiesSamplesPage.enterSampleSizeValue(sampleSize2Contains);
        studiesSamplesPage.clickAddButton();
        assertThat(studiesSamplesPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));
        // Check that both entries are now displayed in the table.
        assertThat(studiesSamplesPage.getSamplesizeTableEntry(sampleSize1Contains), containsString(sampleSize1Contains));
        assertThat(studiesSamplesPage.deleteButtonTableEntryDisplayed(sampleSize1Contains), equalTo(true));
        assertThat(studiesSamplesPage.getSamplesizeTableEntry(sampleSize2Contains), containsString(sampleSize2Contains));
        assertThat(studiesSamplesPage.deleteButtonTableEntryDisplayed(sampleSize2Contains), equalTo(true));

        /**
         * Delete the first sample size value that was added.
         * This should move the second sample size value to
         * the xpath position of the first.
         */
        studiesSamplesPage.clickDeleteSampleSize(sampleSize1Contains);
        assertThat(studiesSamplesPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));
        assertThat(studiesSamplesPage.getSamplesizeTableEntry(sampleSize2Contains), containsString(sampleSize2Contains));
        assertThat(studiesSamplesPage.deleteButtonTableEntryDisplayed(sampleSize2Contains), equalTo(true));

        /**
         * Navigate back to the Study Home Page.
         * Check that the page displays correctly.
         */
        studiesSamplesPage.clickCurrentStudyBreadcrumb();

        /**
         * Check that we have navigated to the correct page.
         */
        assertThat(studyHomePage.getURL(), containsString(studyHomeURLContains));
    }

    @Test (priority = 6, description = "TCM-361 - Test that user can add & delete groups")
    public void verifyAddDeleteGroups() throws Exception {
        /**
         * Navigate to the page.
         */
        studyHomePage.clickDefineGroupsButton();
        groupPage = new GroupPage(driver);

        /**
         * Verify all of the field labels, the button,
         * section header and table headings display correctly.
         */
        assertThat(groupPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(groupPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(groupPage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(groupPage.getCurrentStudyBreadcrumb(), containsString(currentStudyBreadcrumbContains));
        assertThat(groupPage.getGroupsBreadcrumb(), containsString(groupsBreadcrumbContains));
        assertThat(groupPage.getHomeIcon(), equalTo(true));
        assertThat(groupPage.getLogoutIcon(), equalTo(true));
        assertThat(groupPage.getGroupLabelLabel(), containsString(labelTableColumnHeaderContains));
        assertThat(groupPage.getGroupDescriptionLabel(), containsString(descriptionTableColumnHeaderContains));
        assertThat(groupPage.getGroupValueRankLabel(), containsString(valueRankLabelContains));
        assertThat(groupPage.getGroupControlLabel(), containsString(controlLabelContains));

        // Add button.
        assertThat(groupPage.getAddButton(), containsString(addButtonContains));

        // Section header.
        assertThat(groupPage.getGroupListHeader(), containsString(groupListHeaderContains));
        assertThat(groupPage.getGroupHeader(), containsString(groupPageHeaderContains));

        // Table headers.
        List<String> ExpectedColumnHeaders = new ArrayList<String>();
        ExpectedColumnHeaders.add(labelTableColumnHeaderContains);
        ExpectedColumnHeaders.add(descriptionTableColumnHeaderContains);
        ExpectedColumnHeaders.add(valueRankLabelContains);
        ExpectedColumnHeaders.add(controlLabelContains);
        ExpectedColumnHeaders.add(actionsTableColumnHeaderContains);
        assertThat(groupPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        /**
         * Enter information for first group and verify that
         * it appears in the group list.
         */
        groupPage.enterGroupDetails(groupLabel1TableEntry, groupDescriptionTableEntry, groupValueRank1TableEntry, groupControlTrueTableEntry);
        groupPage.clickAddButton();
        groupPage.waitUntilRowPopulates(ExpectedColumnHeaders.get(0), 1);

        // Check that the table headers still appear.
        assertThat(groupPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        // Check that the table entries appear.
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(0), groupLabel1TableEntry), containsString(groupLabel1TableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(1), groupDescriptionTableEntry), containsString(groupDescriptionTableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(2), groupValueRank1TableEntry), containsString(groupValueRank1TableEntry));
        assertThat(groupPage.getControlEntry(ExpectedColumnHeaders.get(3), groupLabel1TableEntry, ExpectedColumnHeaders.get(0)), equalTo(unicodeTrue));
        assertThat(groupPage.deleteButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel1TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(groupPage.editButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel1TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));

        /**
         * Enter information for the second group and verify
         * that it appears in the group list.
         */
        groupPage.enterGroupDetails(groupLabel2TableEntry, groupDescriptionTableEntry, groupValueRank2TableEntry, groupControlFalseTableEntry);
        groupPage.clickAddButton();
        groupPage.waitUntilRowPopulates(ExpectedColumnHeaders.get(0), 2);

        // Check that the table headers still appear.
        assertThat(groupPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        // Check that the table entries appear.
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(0), groupLabel2TableEntry), containsString(groupLabel2TableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(1), groupDescriptionTableEntry), containsString(groupDescriptionTableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(2), groupValueRank2TableEntry), containsString(groupValueRank2TableEntry));
        assertThat(groupPage.getControlEntry(ExpectedColumnHeaders.get(3), groupLabel2TableEntry, ExpectedColumnHeaders.get(0)), equalTo(unicodeFalse));
        assertThat(groupPage.deleteButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel2TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(groupPage.editButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel2TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));

        /**
         * Enter information for the third group and verify
         * that it appears in the group list.
         */
        groupPage.enterGroupDetails(groupLabel3TableEntry, groupDescriptionTableEntry, groupValueRank3TableEntry, groupControlFalseTableEntry);
        groupPage.clickAddButton();
        groupPage.waitUntilRowPopulates(ExpectedColumnHeaders.get(0), 3);

        // Check that the table headers still appear.
        assertThat(groupPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        // Check that the table entries appear.
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(0), groupLabel3TableEntry), containsString(groupLabel3TableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(1), groupDescriptionTableEntry), containsString(groupDescriptionTableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(2), groupValueRank3TableEntry), containsString(groupValueRank3TableEntry));
        assertThat(groupPage.getControlEntry(ExpectedColumnHeaders.get(3), groupLabel3TableEntry, ExpectedColumnHeaders.get(0)), equalTo(unicodeFalse));
        assertThat(groupPage.deleteButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel3TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(groupPage.editButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel3TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));

        /**
         * Delete the first group that was added.
         */
        groupPage.clickDeleteGroupButton(ExpectedColumnHeaders.get(4), groupLabel1TableEntry, ExpectedColumnHeaders.get(0));
        Thread.sleep(6000);
        assertThat(groupPage.getDeleteModalHeader(), containsString(proceedContains));
        assertThat(groupPage.getDeleteModalBody(), containsString(deleteGroupModalContains));
        assertThat(groupPage.getDeleteModalCancel(), containsString(cancelButtonContains));
        assertThat(groupPage.getDeleteModalOK(), containsString(okButtonContains));
        groupPage.clickDeleteModalOK();
        groupPage.waitUntilRowPopulates(ExpectedColumnHeaders.get(0), 2);

        /**
         * Check that the second group moves to the position
         * of the first group in the table.
         */
        assertThat(groupPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        // Check that the table entries appear.
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(0), groupLabel2TableEntry), containsString(groupLabel2TableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(1), groupDescriptionTableEntry), containsString(groupDescriptionTableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(2), groupValueRank2TableEntry), containsString(groupValueRank2TableEntry));
        assertThat(groupPage.getControlEntry(ExpectedColumnHeaders.get(3), groupLabel2TableEntry, ExpectedColumnHeaders.get(0)), equalTo(unicodeFalse));
        assertThat(groupPage.deleteButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel2TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(groupPage.editButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel2TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(0), groupLabel3TableEntry), containsString(groupLabel3TableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(1), groupDescriptionTableEntry), containsString(groupDescriptionTableEntry));
        assertThat(groupPage.getColumnEntry(ExpectedColumnHeaders.get(2), groupValueRank3TableEntry), containsString(groupValueRank3TableEntry));
        assertThat(groupPage.getControlEntry(ExpectedColumnHeaders.get(3), groupLabel3TableEntry, ExpectedColumnHeaders.get(0)), equalTo(unicodeFalse));
        assertThat(groupPage.deleteButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel3TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(groupPage.editButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), groupLabel3TableEntry, ExpectedColumnHeaders.get(0)), equalTo(true));

        /**
         * Navigate back to the study home page and verify that
         * the page loads correctly.
         */
        groupPage.clickCurrentStudyBreadcrumb();

        /**
         * Check that we have navigated to the correct page.
         */
        assertThat(studyHomePage.getURL(), containsString(studyHomeURLContains));
    }

    @Test (priority = 7, description = "TCM-362 - Test that user can add & delete allocation values.")
    public void verifyAddDeleteAllocations() throws InterruptedException {
        /**
         * Navigate to the page for defining allocations.
         */
        studyHomePage.clickDefineAllocationsButton();
        groupAllocationsPage = new GroupAllocationsPage(driver);

        /**
         * Check that the correct fields are visible
         * and the page/section headers are visible.
         */
        assertThat(groupAllocationsPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(groupAllocationsPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(groupAllocationsPage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(groupAllocationsPage.getCurrentStudyBreadcrumb(), containsString(currentStudyBreadcrumbContains));
        assertThat(groupAllocationsPage.getAllocationBreadcrumb(), containsString(allocationsBreadcrumbContains));
        assertThat(groupAllocationsPage.getHomeIcon(), equalTo(true));
        assertThat(groupAllocationsPage.getLogoutIcon(), equalTo(true));

        Thread.sleep(3000);
        assertThat(groupAllocationsPage.getAllocationFieldLabel1(), containsString(groupLabel2TableEntry));
        assertThat(groupAllocationsPage.getAllocationFieldLabel2(), containsString(groupLabel3TableEntry));
        assertThat(groupAllocationsPage.getAddButton(), containsString(addButtonContains));
        assertThat(groupAllocationsPage.getAllocationListHeader(), containsString(allocationListHeader));

        List<String> allocationHeaders = new ArrayList<String>();
        allocationHeaders.add(groupLabel2TableEntry);
        allocationHeaders.add(groupLabel3TableEntry);
        allocationHeaders.add(actionsTableColumnHeaderContains);
        assertThat(groupAllocationsPage.getTableColumnHeaders(), equalTo(allocationHeaders));

        /**
         * Enter information for allocation 1.
         */
        groupAllocationsPage.enterAllocation1(allocation1TableEntry);
        groupAllocationsPage.enterAllocation2(allocation2TableEntry);
        groupAllocationsPage.clickAddButton();

        /**
         * Check that the correct information is displayed.
         */
        Thread.sleep(5000);
        assertThat(groupAllocationsPage.getTableColumnHeaders(), equalTo(allocationHeaders));
        assertThat(groupAllocationsPage.getAllocationColumnEntry(groupLabel2TableEntry, allocation1TableEntry), containsString(allocation1TableEntry));
        assertThat(groupAllocationsPage.getAllocationColumnEntry(groupLabel3TableEntry, allocation2TableEntry), containsString(allocation2TableEntry));
        assertThat(groupAllocationsPage.deleteButtonTableEntryDisplayed(allocationHeaders.get(2), allocation1TableEntry, groupLabel2TableEntry), equalTo(true));

        /**
         * Enter information for allocation 2.
         */
        groupAllocationsPage.enterAllocation1(allocation3TableEntry);
        groupAllocationsPage.enterAllocation2(allocation4TableEntry);
        groupAllocationsPage.clickAddButton();
        Thread.sleep(5000);

        /**
         * Check that the correct information is displayed.
         */
        assertThat(groupAllocationsPage.getTableColumnHeaders(), equalTo(allocationHeaders));
        assertThat(groupAllocationsPage.getAllocationColumnEntry(groupLabel2TableEntry, allocation3TableEntry), containsString(allocation3TableEntry));
        assertThat(groupAllocationsPage.getAllocationColumnEntry(groupLabel3TableEntry, allocation4TableEntry), containsString(allocation4TableEntry));
        assertThat(groupAllocationsPage.deleteButtonTableEntryDisplayed(allocationHeaders.get(2), allocation3TableEntry, groupLabel2TableEntry), equalTo(true));

        /**
         * Delete the first allocation value.
         */
        groupAllocationsPage.clickDeleteGroupButton(allocationHeaders.get(2), allocation1TableEntry, groupLabel2TableEntry);

        /**
         * Check that the second value now moves to
         * the position of the first in the table.
         */
        assertThat(groupAllocationsPage.getTableColumnHeaders(), equalTo(allocationHeaders));
        assertThat(groupAllocationsPage.getAllocationColumnEntry(groupLabel2TableEntry, allocation3TableEntry), containsString(allocation3TableEntry));
        assertThat(groupAllocationsPage.getAllocationColumnEntry(groupLabel3TableEntry, allocation4TableEntry), containsString(allocation4TableEntry));
        assertThat(groupAllocationsPage.deleteButtonTableEntryDisplayed(allocationHeaders.get(2), allocation3TableEntry, groupLabel2TableEntry), equalTo(true));

        /**
         * Navigate back to the study home page and verify that
         * the page loads correctly.
         */
        groupAllocationsPage.clickCurrentStudyBreadcrumb();

        /**
         * Check that we have navigated to the correct page.
         */
        assertThat(studyHomePage.getURL(), containsString(studyHomeURLContains));
    }

    @Test (priority = 8, description = "TCM-363 - Test that the user can add a variable with Normal distribution.")
    public void verifyAddNormalVariable() throws Exception {
        /**
         * Navigate to the page for defining allocations.
         */
        studyHomePage.clickDefineVariablesButton();
        variablesPage = new VariablesPage(driver);

        /**
         * Verify that the correct elements are on the page.
         * Check the navigation links.
         */
        assertThat(variablesPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(variablesPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(variablesPage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(variablesPage.getCurrentStudyBreadcrumb(), containsString(currentStudyBreadcrumbContains));
        assertThat(variablesPage.getVariablesBreadcrumb(), containsString(variablesBreadcrumbContains));
        assertThat(variablesPage.getHomeIcon(), equalTo(true));
        assertThat(variablesPage.getLogoutIcon(), equalTo(true));

        /**
         * Check the headers on the page.
         */
        assertThat(variablesPage.getVariablesHeader(), containsString(variablesHeaderContains));
        assertThat(variablesPage.getVariablesListHeader(), containsString(variablesListHeaderContains));

        /**
         * Check the field labels on the page and the
         * button in the variables section.
         */
        assertThat(variablesPage.getVariableLabelLabel(), containsString(variableLabelLabelContains));
        assertThat(variablesPage.getVariableDescriptionLabel(), containsString(variableDescriptionContains));
        assertThat(variablesPage.getVariableDistributionLabel(), containsString(variableDistributionLabelContains));
        // Check the default distribution selection.
        assertThat(variablesPage.getVariableDistributionField(), containsString(pleaseSelectDashedFieldContains));
        assertThat(variablesPage.getSubmitButton(), containsString(createButtonContains));
        assertThat(variablesPage.getCancelButton(), containsString(cancelButtonContains));

        /**
         * Check the column headers on the page.
         */
        List<String> variableTableHeaders = new ArrayList<String>();
        variableTableHeaders.add(labelTableColumnHeaderContains);
        variableTableHeaders.add(descriptionTableColumnHeaderContains);
        variableTableHeaders.add(distributionDerivationTableHeaderContains);
        variableTableHeaders.add(parametersTableHeaderContains);
        variableTableHeaders.add(actionsTableColumnHeaderContains);
        assertThat(variablesPage.getTableColumnHeaders(), equalTo(variableTableHeaders));

        /**
         * Enter variable 1 information.
         */
        variablesPage.enterVariableInformation(normalVariableLabel1Contains, variable1DescriptionContains, normalDistributionContains);
        variablesPage.clickCreateButton();

        /**
         * Verify that it appears in the variables list.
         */
        Thread.sleep(4000);
        assertThat(variablesPage.getParametersColumnEntry(parametersTableHeaderContains, normalVariableLabel1Contains), containsString(unsetContains));
        assertThat(variablesPage.getTableColumnEntry(labelTableColumnHeaderContains, normalVariableLabel1Contains), containsString(normalVariableLabel1Contains));
        assertThat(variablesPage.getTableColumnEntry(descriptionTableColumnHeaderContains, variable1DescriptionContains), containsString(variable1DescriptionContains));
        assertThat(variablesPage.getTableColumnEntry(distributionDerivationTableHeaderContains, normalDistributionContains), containsString(normalDistributionContains));

        /**
         * Check that the action buttons are present.
         */
        assertThat(variablesPage.copyButtonTableEntryDisplayed(normalVariableLabel1Contains), equalTo(true));
        assertThat(variablesPage.deleteButtonTableEntryDisplayed(normalVariableLabel1Contains), equalTo(true));
        assertThat(variablesPage.editButtonTableEntryDisplayed(normalVariableLabel1Contains), equalTo(true));

        /**
         * Click the edit button for the variable.
         */
        variablesPage.clickSetUnsetLink(parametersTableHeaderContains, normalVariableLabel1Contains);
        variableParametersPage = new VariableParametersPage(driver);

        /**
         * Verify that the correct information appears on the page.
         * Including that the parameter fields are empty.
         */
        assertThat(variableParametersPage.getVariableLabelHeader(), containsString(normalVariableLabel1Contains));
        assertThat(variableParametersPage.getVariableParametersHeader(), containsString(variableParametersHeaderContains));
        Thread.sleep(2000);
        List<String> variableParameterTableColumnHeaders = new ArrayList<String>();
        variableParameterTableColumnHeaders.add(meanHeaderContains);
        variableParameterTableColumnHeaders.add(standardDeviationHeaderContains);
        assertThat(variableParametersPage.getTableColumnHeaders(), equalTo(variableParameterTableColumnHeaders));

        List<String> variableParameterTableRowHeaders = new ArrayList<String>();
        variableParameterTableRowHeaders.add(groupLabel2TableEntry);
        variableParameterTableRowHeaders.add(groupLabel3TableEntry);
        assertThat(variableParametersPage.getTableRowHeaders(), equalTo(variableParameterTableRowHeaders));

        List<String> notSetColumnEntry = new ArrayList<String>();
        notSetColumnEntry.add(defaultParameterValueContains);
        notSetColumnEntry.add(defaultParameterValueContains);
        assertThat(variableParametersPage.getParameterColumnEntries(variableParameterTableColumnHeaders.get(0)), equalTo(notSetColumnEntry));
        assertThat(variableParametersPage.getParameterColumnEntries(variableParameterTableColumnHeaders.get(1)), equalTo(notSetColumnEntry));

        /**
         * Click the edit button, enter parameters and
         * click save.
         */
        assertThat(variableParametersPage.getEditButton(), containsString(editButtonContains));
        variableParametersPage.clickEditButton();
        assertThat(variableParametersPage.getSaveButton(), containsString(saveButtonContains));
        assertThat(variableParametersPage.getCancelButton(), containsString(cancelButtonContains));

        List<String> meanColumnEntry = new ArrayList<String>();
        meanColumnEntry.add(normalMean1Contains);
        meanColumnEntry.add(normalMean2Contains);
        variableParametersPage.enterDistributionParameters(variableParameterTableColumnHeaders.get(0), meanColumnEntry, variableParameterTableRowHeaders);

        List<String> standardDeviationColumnEntry = new ArrayList<String>();
        standardDeviationColumnEntry.add(normalStandardDeviation1Contains);
        standardDeviationColumnEntry.add(normalStandardDeviation2Contains);
        variableParametersPage.enterDistributionParameters(variableParameterTableColumnHeaders.get(1), standardDeviationColumnEntry, variableParameterTableRowHeaders);
        variableParametersPage.clickOkButton();

        /**
         * Verify that the parameters are now visible on
         * the UI.
         */
        assertThat(variableParametersPage.getParameterColumnEntries(variableParameterTableColumnHeaders.get(0)), equalTo(meanColumnEntry));
        assertThat(variableParametersPage.getParameterColumnEntries(variableParameterTableColumnHeaders.get(1)), equalTo(standardDeviationColumnEntry));

        /**
         * Navigate back to the variables page.
         */
        variableParametersPage.clickBackButton();

        /**
         * Check the URL of the page.
         */
        assertThat(variablesPage.getURL(), containsString(variablesPageURLContains));

        /**
         * Check that the variable parameters column now displays Set.
         */
        assertThat(variablesPage.getParametersColumnEntry(parametersTableHeaderContains, normalVariableLabel1Contains), containsString(setContains));
    }

    @Test (priority = 9, description = "TCM-364 - Test that the user can add a variable with Binomial distribution.")
    public void verifyAddBinomialVariable() throws Exception {
        /**
         * Less assertions here due to the test above this.
         */

        /**
         * Enter variable information.
         */
        variablesPage.enterVariableInformation(binomialVariableLabel1Contains, variable1DescriptionContains, binomialDistributionContains);
        variablesPage.clickCreateButton();

        /**
         * Verify that it appears in the variables list.
         */
        Thread.sleep(4000);
        assertThat(variablesPage.getParametersColumnEntry(parametersTableHeaderContains, binomialVariableLabel1Contains), containsString(unsetContains));
        assertThat(variablesPage.getTableColumnEntry(labelTableColumnHeaderContains, binomialVariableLabel1Contains), containsString(binomialVariableLabel1Contains));
        assertThat(variablesPage.getTableColumnEntry(descriptionTableColumnHeaderContains, variable1DescriptionContains), containsString(variable1DescriptionContains));
        assertThat(variablesPage.getTableColumnEntry(distributionDerivationTableHeaderContains, binomialDistributionContains), containsString(binomialDistributionContains));

        /**
         * Check that the action buttons are.
         */
        assertThat(variablesPage.copyButtonTableEntryDisplayed(binomialVariableLabel1Contains), equalTo(true));
        assertThat(variablesPage.deleteButtonTableEntryDisplayed(binomialVariableLabel1Contains), equalTo(true));
        assertThat(variablesPage.editButtonTableEntryDisplayed(binomialVariableLabel1Contains), equalTo(true));

        /**
         * Click the edit button for the variable.
         */
        variablesPage.clickSetUnsetLink(parametersTableHeaderContains, binomialVariableLabel1Contains);
        variableParametersPage = new VariableParametersPage(driver);

        /**
         * Verify that the correct information appears on the page.
         * Including that the parameter fields are empty.
         */
        assertThat(variableParametersPage.getVariableLabelHeader(), containsString(binomialVariableLabel1Contains));
        assertThat(variableParametersPage.getVariableParametersHeader(), containsString(variableParametersHeaderContains));
        Thread.sleep(2000);
        List<String> parametersColumnHeader = new ArrayList<String>();
        parametersColumnHeader.add(probabilityHeaderContains);
        assertThat(variableParametersPage.getTableColumnHeaders(), equalTo(parametersColumnHeader));

        List<String> variableParameterTableRowHeaders = new ArrayList<String>();
        variableParameterTableRowHeaders.add(groupLabel2TableEntry);
        variableParameterTableRowHeaders.add(groupLabel3TableEntry);
        assertThat(variableParametersPage.getTableRowHeaders(), equalTo(variableParameterTableRowHeaders));

        List<String> notSetColumnEntry = new ArrayList<String>();
        notSetColumnEntry.add(defaultParameterValueContains);
        notSetColumnEntry.add(defaultParameterValueContains);
        assertThat(variableParametersPage.getParameterColumnEntries(parametersColumnHeader.get(0)), equalTo(notSetColumnEntry));

        /**
         * Click the edit button, enter parameters and
         * click save.
         */
        assertThat(variableParametersPage.getEditButton(), containsString(editButtonContains));
        variableParametersPage.clickEditButton();
        assertThat(variableParametersPage.getSaveButton(), containsString(saveButtonContains));
        assertThat(variableParametersPage.getCancelButton(), containsString(cancelButtonContains));

        List<String> probabilityColumnEntry = new ArrayList<String>();
        probabilityColumnEntry.add(binomialProbability1Contains);
        probabilityColumnEntry.add(binomialProbability2Contains);
        variableParametersPage.enterDistributionParameters(parametersColumnHeader.get(0), probabilityColumnEntry, variableParameterTableRowHeaders);
        variableParametersPage.clickOkButton();

        /**
         * Verify that the parameters are now visible on
         * the UI.
         */
        assertThat(variableParametersPage.getParameterColumnEntries(parametersColumnHeader.get(0)), equalTo(probabilityColumnEntry));

        /**
         * Navigate back to the variables page.
         */
        variableParametersPage.clickBackButton();

        /**
         * Check the URL of the page.
         */
        assertThat(variablesPage.getURL(), containsString(variablesPageURLContains));

        /**
         * Check that the variable parameters column now displays Set.
         */
        assertThat(variablesPage.getParametersColumnEntry(parametersTableHeaderContains, binomialVariableLabel1Contains), containsString(setContains));
    }

    @Test (priority = 10, description = "TCM-365 - Test that a user can add a relation between two variables.")
    public void verifyAddRelation() throws Exception {
        variablesPage.clickCurrentStudyBreadcrumb();
        assertThat(studyHomePage.getURL(), containsString(studyHomeURLContains));
        studyHomePage.clickDefineRelationsButton();
        relationPage = new RelationPage(driver);

        /**
         * Verify that the correct elements are on the page.
         * Check the navigation links.
         */
        assertThat(relationPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(relationPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(relationPage.getAllStudiesBreadcrumb(), containsString(allStudiesBreadcrumbContains));
        assertThat(relationPage.getCurrentStudyBreadcrumb(), containsString(currentStudyBreadcrumbContains));
        assertThat(relationPage.getRelationsBreadcrumb(), containsString(relationBreadcrumbContains));
        assertThat(relationPage.getHomeIcon(), equalTo(true));
        assertThat(relationPage.getLogoutIcon(), equalTo(true));

        /**
         * Check the headers on the page.
         */
        assertThat(relationPage.getRelationsHeader(), containsString(relationsHeaderContains));
        assertThat(relationPage.getRelationListHeader(), containsString(relationListHeaderContains));

        /**
         * Check the headers on the variable and
         * relation type selection form.
         */
        List<String> variableRelationTableRowHeaders = new ArrayList<String>();
        variableRelationTableRowHeaders.add(variable1LabelContains);
        variableRelationTableRowHeaders.add(variable2LabelContains);
        variableRelationTableRowHeaders.add(relationTypeLabelContains);
        assertThat(relationPage.getVariableRelationTypeHeaders(), equalTo(variableRelationTableRowHeaders));

        /**
         * Check variable 1 field contents and default value.
         */
        List<String> variable1Options = new ArrayList<String>();
        variable1Options.add(emptyValue);
        variable1Options.add(normalVariableLabel1Contains);
        variable1Options.add(binomialVariableLabel1Contains);
        assertThat(relationPage.getVariable1Options(), equalTo(variable1Options));
        assertThat(relationPage.getVariable1Selection(), equalTo(emptyValue));

        /**
         * Check that the only option in the variable 2 field
         * is an empty value.
         */
        List<String> variable2Options = new ArrayList<String>();
        variable2Options.add(emptyValue);
        assertThat(relationPage.getVariable2Options(), equalTo(variable2Options));

        /**
         * Check relation type field contents and default value.
         */
        List<String> relationTypeOptions = new ArrayList<String>();
        relationTypeOptions.add(pleaseSelectDashedFieldContains);
        relationTypeOptions.add(spearmanRho);
        assertThat(relationPage.getRelationTypeOptions(), equalTo(relationTypeOptions));
        assertThat(relationPage.getRelationTypeSelection(), equalTo(pleaseSelectDashedFieldContains));

        /**
         * Check the headers in the relation parameters form.
         */
        List<String> relationParameterHeaders = new ArrayList<String>();
        relationParameterHeaders.add(group);
        relationParameterHeaders.add(relationParametersLabelContains);
        assertThat(relationPage.getRelationParametersHeaders(), equalTo(relationParameterHeaders));

        /**
         * Check the field labels on the relation parameters form
         * and the text for the add button.
         */
        assertThat(relationPage.getParameter1Label(), equalTo(groupLabel2TableEntry));
        assertThat(relationPage.getParameter2Label(), equalTo(groupLabel3TableEntry));
        assertThat(relationPage.getAddButton(), equalTo(addButtonContains));

        /**
         * Check that the relation list table is displayed correctly.
         */
        List<String> relationListHeaders = new ArrayList<String>();
        relationListHeaders.add(variable1LabelContains);
        relationListHeaders.add(variable2LabelContains);
        relationListHeaders.add(relationTypeLabelContains);
        relationListHeaders.add(group);
        relationListHeaders.add(valueHeaderContains);
        relationListHeaders.add(actionsTableColumnHeaderContains);
        assertThat(relationPage.getRelationListTableColumnHeaders(), equalTo(relationListHeaders));

        /**
         * Add a relation.
         * Select the first variable to be involved in the relation.
         */
        relationPage.selectVariable1(normalVariableLabel1Contains);
        /**
         * Check the default selection in the Variable 2 field.
         * Also check what options are available in the list.
         */
        assertThat(relationPage.getVariable2Selection(), equalTo(emptyValue));
        variable2Options.add(binomialVariableLabel1Contains);
        assertThat(relationPage.getVariable2Options(), equalTo(variable2Options));
        /**
         * Select the second variable to be involved in the relation and
         * the default relation type field.
         */
        relationPage.selectVariable2(binomialVariableLabel1Contains);
        assertThat(relationPage.getRelationTypeOptions(), equalTo(relationTypeOptions));
        assertThat(relationPage.getRelationTypeSelection(), equalTo(pleaseSelectDashedFieldContains));

        /**
         * Select the relation type and enter the relation parameters.
         */
        relationPage.selectRelationType(spearmanRho);
        relationPage.enterRelationParameter1(relationValue1);
        relationPage.enterRelationParameter2(relationValue2);
        relationPage.clickAddButton();

        Thread.sleep(4000);

        /**
         * Check that it appears in the relation list table.
         */
        assertThat(relationPage.getRelationListTableColumnHeaders(), equalTo(relationListHeaders));
        assertThat(relationPage.getTableColumnEntry(variable1LabelContains, normalVariableLabel1Contains), equalTo(normalVariableLabel1Contains));
        assertThat(relationPage.getTableColumnEntry(variable2LabelContains, binomialVariableLabel1Contains), equalTo(binomialVariableLabel1Contains));
        assertThat(relationPage.getTableColumnEntry(relationTypeLabelContains, spearmanRho), equalTo(spearmanRho));
        assertThat(relationPage.getRelation1Group1(), equalTo(groupLabel2TableEntry));
        assertThat(relationPage.getRelation1Group2(), equalTo(groupLabel3TableEntry));
        assertThat(relationPage.getRelation1Value1(), equalTo(relationValue1));
        assertThat(relationPage.getRelation1Value2(), equalTo(relationValue2));
        assertThat(relationPage.deleteButtonTableEntryDisplayed(relationListHeaders.get(5), normalVariableLabel1Contains, relationListHeaders.get(0)), equalTo(true));
        assertThat(relationPage.editButtonTableEntryDisplayed(relationListHeaders.get(5), normalVariableLabel1Contains, relationListHeaders.get(0)), equalTo(true));
    }

    @Test (priority = 11, description = "TCM-810 - Test that a user can declare subgroups using Group & binomial variable.")
    public void verifyAddSubgroups() throws InterruptedException {
        /**
         * Navigate back to the project dashboard and
         * click the Subgroup Builder button.
         */
        relationPage.clickCurrentProjectBreadcrumb();
        editProjectDetailsPage.clickSubgroupBuilderButton();
        subgroupBuilderPage = new SubgroupBuilderPage(driver);

        /**
         * Check the header links on the page.
         */
        assertThat(subgroupBuilderPage.getHomeIcon(), equalTo(true));
        assertThat(subgroupBuilderPage.getLogoutIcon(), equalTo(true));
        assertThat(subgroupBuilderPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(subgroupBuilderPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(subgroupBuilderPage.getSubgroupBuilderBreadcrumb(), containsString(subgroupBuilderBreadcrumbContains));

        /**
         * Check the section headers, the element labels, the default
         * element selection values and the Confirm button text.
         */
        assertThat(subgroupBuilderPage.getSubgroupBuilderHeader(), containsString(subgroupBuilderHeaderContains));
        assertThat(subgroupBuilderPage.getSubgroupListHeader(), containsString(subgroupListHeaderContains));
        assertThat(subgroupBuilderPage.getElement1(), containsString(binomialVariableLabel1Contains));
        assertThat(subgroupBuilderPage.element1CheckboxSelected(), equalTo(false));
        assertThat(subgroupBuilderPage.getElement2(), containsString(group));
        assertThat(subgroupBuilderPage.element2CheckboxSelected(), equalTo(false));
        assertThat(subgroupBuilderPage.getConfirmButton(), containsString(confirmButtonContains));

        /**
         * Make element selection & click confirm.
         */
        subgroupBuilderPage.selectElement1();
        subgroupBuilderPage.selectElement2();
        subgroupBuilderPage.clickConfirmButton();

        /**
         * Check that the save button appears, check the table headers,
         * table string entries, hide checkboxes and action buttons.
         */
        assertThat(subgroupBuilderPage.getSaveButton(), containsString(saveButtonContains));
        List<String> ExpectedColumnHeaders = new ArrayList<String>();
        ExpectedColumnHeaders.add(subgroupTableHeaderContains);
        ExpectedColumnHeaders.add(labelTableColumnHeaderContains);
        ExpectedColumnHeaders.add(hideTableHeaderContains);
        ExpectedColumnHeaders.add(actionsTableColumnHeaderContains);
        assertThat(subgroupBuilderPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        List<String> ExpectedSubgroups = new ArrayList<String>();
        ExpectedSubgroups.add(binomialVariableLabel1Contains + " = 0 and " + group + " = " + groupLabel2TableEntry);
        ExpectedSubgroups.add(binomialVariableLabel1Contains + " = 0 and " + group + " = " + groupLabel3TableEntry);
        ExpectedSubgroups.add(binomialVariableLabel1Contains + " = 1 and " + group + " = " + groupLabel2TableEntry);
        ExpectedSubgroups.add(binomialVariableLabel1Contains + " = 1 and " + group + " = " + groupLabel3TableEntry);
        assertThat(subgroupBuilderPage.getColumnEntries(subgroupTableHeaderContains), equalTo(ExpectedSubgroups));

        String subgroupLabel1 = binomialVariableLabel1Contains + "0" + groupLabel2TableEntry;
        String subgroupLabel2 = binomialVariableLabel1Contains + "0" + groupLabel3TableEntry;
        String subgroupLabel3 = binomialVariableLabel1Contains + "1" + groupLabel2TableEntry;
        String subgroupLabel4 = binomialVariableLabel1Contains + "1" + groupLabel3TableEntry;
        List<String> ExpectedSubgroupLabels = new ArrayList<String>();
        ExpectedSubgroupLabels.add(subgroupLabel1);
        ExpectedSubgroupLabels.add(subgroupLabel2);
        ExpectedSubgroupLabels.add(subgroupLabel3);
        ExpectedSubgroupLabels.add(subgroupLabel4);
        assertThat(subgroupBuilderPage.getColumnEntries(labelTableColumnHeaderContains), equalTo(ExpectedSubgroupLabels));

        List<Boolean> ExpectedHideColumnState = new ArrayList<Boolean>(Arrays.asList(new Boolean[4]));
        Collections.fill(ExpectedHideColumnState, Boolean.FALSE);
        assertThat(subgroupBuilderPage.getHideColumnEntries(hideTableHeaderContains), equalTo(ExpectedHideColumnState));

        assertThat(subgroupBuilderPage.editButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel1, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.deleteButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel1, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.editButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel2, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.deleteButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel2, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.editButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel3, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.deleteButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel3, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.editButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel4, labelTableColumnHeaderContains), equalTo(true));
        assertThat(subgroupBuilderPage.deleteButtonTableEntryDisplayed(actionsTableColumnHeaderContains, subgroupLabel4, labelTableColumnHeaderContains), equalTo(true));

        /**
         * Click the save button and check the success message appears.
         */
        subgroupBuilderPage.clickSaveButton();
        Thread.sleep(2000);
        assertThat(subgroupBuilderPage.getSuccessMessage(), containsString(successMessageContains));
    }

    @Test (priority = 12, description = "TCM-366 - Test that the user can add a Two-Sample T-Test for a Normal variable to the SAP.")
    public void verifyAddTwoSampleTTest() throws InterruptedException {
        /**
         * Navigate back to the project dashboard and
         * click the SAP button.
         */
        subgroupBuilderPage.clickCurrentProjectBreadcrumb();
        editProjectDetailsPage.clickStatisticalAnalysisPlanButton();

        statisticalAnalysisPlanPage = new StatisticalAnalysisPlanPage(driver);

        /**
         * Check the header links on the page.
         */
        assertThat(statisticalAnalysisPlanPage.getHomeIcon(), equalTo(true));
        assertThat(statisticalAnalysisPlanPage.getLogoutIcon(), equalTo(true));
        assertThat(statisticalAnalysisPlanPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(statisticalAnalysisPlanPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(statisticalAnalysisPlanPage.getStatisticalAnalysisPlanBreadcrumb(), containsString(statisticalAnalysisPlanButtonContains));

        /**
         * Check the page header.
         */
        assertThat(statisticalAnalysisPlanPage.getStatisticalAnalysisPlanHeader(), containsString(statisticalAnalysisPlanHeaderContains));

        /**
         * Check the field labels and the default field values.
         */
        assertThat(statisticalAnalysisPlanPage.getVariableLabel(), containsString(variableFieldLabelContains));
        assertThat(statisticalAnalysisPlanPage.getVariableField(), containsString(defaultSAPFieldContains));
        assertThat(statisticalAnalysisPlanPage.getTestLabel(), containsString(testFieldLabelContains));
        assertThat(statisticalAnalysisPlanPage.getTestField(), containsString(defaultSAPFieldContains));
        assertThat(statisticalAnalysisPlanPage.getGroupingLabel(), containsString(groupingFieldLabelContains));
        assertThat(statisticalAnalysisPlanPage.getGroupingField(), containsString(defaultSAPFieldContains));
        assertThat(statisticalAnalysisPlanPage.getBonferroniCorrectionLabel(), containsString(bonferroniFieldLabelContains));
        // The bonferroni checkbox should be ticked when you first land on the page.
        assertThat(statisticalAnalysisPlanPage.getBonferroniCheckBox(), equalTo(true));

        // Check the text in the button.
        assertThat(statisticalAnalysisPlanPage.getAddButton(), containsString(addButtonContains));

        /**
         * Check the header & table headers of the SAP List section.
         */
        assertThat(statisticalAnalysisPlanPage.getSAPListHeader(), containsString(sapListHeaderContains));
        List<String> ExpectedColumnHeaders = new ArrayList<String>();
        ExpectedColumnHeaders.add(variableFieldLabelContains);
        ExpectedColumnHeaders.add(testFieldLabelContains);
        ExpectedColumnHeaders.add(groupingFieldLabelContains);
        ExpectedColumnHeaders.add(valueHeaderContains);
        ExpectedColumnHeaders.add(actionsTableColumnHeaderContains);
        assertThat(statisticalAnalysisPlanPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));

        /**
         * Enter SAP selection. Check the population of the following
         * field once the selection has been made.
         */
        statisticalAnalysisPlanPage.selectVariable(normalVariableLabel1Contains);
        List<String> ExpectedContinuousTestOptions = new ArrayList<String>();
        ExpectedContinuousTestOptions.add(defaultSAPFieldContains);
        ExpectedContinuousTestOptions.add(twoSampleTTest);
        ExpectedContinuousTestOptions.add(anovaTest);
        ExpectedContinuousTestOptions.add(oneSampleTTest);
        assertThat(statisticalAnalysisPlanPage.getTestOptions(), equalTo(ExpectedContinuousTestOptions));

        statisticalAnalysisPlanPage.selectTest(twoSampleTTest);
        // Note: this assumes no subgroups have been created.
        List<String> ExpectedGroupingOptions = new ArrayList<String>();
        ExpectedGroupingOptions.add(defaultSAPFieldContains);
        ExpectedGroupingOptions.add(group);
        ExpectedGroupingOptions.add(subgroupTableHeaderContains);
        assertThat(statisticalAnalysisPlanPage.getGroupingOptions(), equalTo(ExpectedGroupingOptions));

        statisticalAnalysisPlanPage.selectGrouping(group);
        statisticalAnalysisPlanPage.selectBonferroniCorrection();
        statisticalAnalysisPlanPage.clickAddButton();
        Thread.sleep(6000);

        /**
         * Ensure the fields are reset to default.
         */
        assertThat(statisticalAnalysisPlanPage.getVariableField(), containsString(defaultSAPFieldContains));
        assertThat(statisticalAnalysisPlanPage.getTestField(), containsString(defaultSAPFieldContains));
        assertThat(statisticalAnalysisPlanPage.getGroupingField(), containsString(defaultSAPFieldContains));
        assertThat(statisticalAnalysisPlanPage.getBonferroniCheckBox(), equalTo(true));

        /**
         * Ensure that the SAP is added to the table
         */
        assertThat(statisticalAnalysisPlanPage.getTableColumnHeaders(), equalTo(ExpectedColumnHeaders));
        assertThat(statisticalAnalysisPlanPage.getTableColumnEntry(variableFieldLabelContains, normalVariableLabel1Contains), containsString(normalVariableLabel1Contains));
        assertThat(statisticalAnalysisPlanPage.getTableColumnEntry(testFieldLabelContains, twoSampleTTest), containsString(twoSampleTTest));
        assertThat(statisticalAnalysisPlanPage.getTableColumnEntry(groupingFieldLabelContains, group), containsString(group));
        assertThat(statisticalAnalysisPlanPage.getTableColumnEntry(valueHeaderContains, emptyValue), containsString(emptyValue));
        assertThat(statisticalAnalysisPlanPage.deleteButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), normalVariableLabel1Contains, ExpectedColumnHeaders.get(0)), equalTo(true));
        assertThat(statisticalAnalysisPlanPage.editButtonTableEntryDisplayed(ExpectedColumnHeaders.get(4), normalVariableLabel1Contains, ExpectedColumnHeaders.get(0)), equalTo(true));

        /**
         * Navigate back to the project home page.
         */
        statisticalAnalysisPlanPage.clickCurrentProjectBreadcrumb();
    }

    @Test (priority = 13, description = "TCM-765 - Test that the user can add a simple objective for the added SAP.")
    public void verifyAddTwoSampleTSimpleObjective() {
        /**
         * Navigate to the objective evaluation page.
         */
        editProjectDetailsPage.clickObjectiveEvaluationButton();
        objectiveEvaluationPage = new ObjectiveEvaluationPage(driver);

        /**
         * Check the header links on the page.
         */
        assertThat(objectiveEvaluationPage.getHomeIcon(), equalTo(true));
        assertThat(objectiveEvaluationPage.getLogoutIcon(), equalTo(true));
        assertThat(objectiveEvaluationPage.getAllProjectsBreadcrumb(), containsString(allProjectsBreadcrumbContains));
        assertThat(objectiveEvaluationPage.getCurrentProjectBreadcrumb(), containsString(currentProjectBreadcrumbContains));
        assertThat(objectiveEvaluationPage.getObjectiveEvaluationBreadcrumb(), containsString(objectiveEvaluationButtonContains));

        /**
         * Check the header text.
         */
        assertThat(objectiveEvaluationPage.getObjectiveEvaluationHeader(), containsString(objectiveEvaluationHeader));
        assertThat(objectiveEvaluationPage.getObjectiveListHeader(), containsString(objectiveListHeader));

        /**
         * Check the field labels & default field values.
         */
        assertThat(objectiveEvaluationPage.getVariableLabel(), containsString(variableFieldLabelContains));
        assertThat(objectiveEvaluationPage.getVariableField(), containsString(defaultSAPFieldContains));
        assertThat(objectiveEvaluationPage.getTestLabel(), containsString(testFieldLabelContains));
        assertThat(objectiveEvaluationPage.getTestField(), containsString(defaultSAPFieldContains));
        assertThat(objectiveEvaluationPage.getStatisticLabel(), containsString(statisticLabelContains));
        assertThat(objectiveEvaluationPage.getStatisticField(), containsString(defaultSAPFieldContains));
        assertThat(objectiveEvaluationPage.getGroupingComparisonLabel(), containsString(groupingComparisonLabelContains));
        assertThat(objectiveEvaluationPage.getGroupingComparisonField(), containsString(defaultSAPFieldContains));
        assertThat(objectiveEvaluationPage.getOperatorLabel(), containsString(operatorLabelContains));
        assertThat(objectiveEvaluationPage.getOperatorField(), containsString(defaultSAPFieldContains));

        List<String> ExpectedOperators = new ArrayList<String>();
        ExpectedOperators.add(defaultSAPFieldContains);
        ExpectedOperators.add(greaterThanLogic);
        ExpectedOperators.add(lessThanLogic);
        ExpectedOperators.add(equalToLogic);
        ExpectedOperators.add(greaterThanOrEqualToLogic);
        ExpectedOperators.add(lessThanOrEqualToLogic);
        ExpectedOperators.add(notEqualToLogic);
        assertThat(objectiveEvaluationPage.getOperatorOptions(), equalTo(ExpectedOperators));

        assertThat(objectiveEvaluationPage.getValueLabel(), containsString(valueHeaderContains));
        assertThat(objectiveEvaluationPage.getValueField(), containsString(emptyValue));
        assertThat(objectiveEvaluationPage.getSimpleLabelLabel(), containsString(objectiveLabelContains));
        assertThat(objectiveEvaluationPage.getSimpleLabelField(), containsString(emptyValue));

        /**
         * Check the button text.
         */
        assertThat(objectiveEvaluationPage.getAddButton(), containsString(addButtonContains));
        assertThat(objectiveEvaluationPage.getCombineObjectivesButton(), containsString(combineObjectiveButtonContains));

        /**
         * Check the table headers.
         */
        List<String> ExpectedTableHeaders = new ArrayList<String>();
        ExpectedTableHeaders.add(objectiveHeaderContains);
        ExpectedTableHeaders.add(actionsTableColumnHeaderContains);
        assertThat(objectiveEvaluationPage.getTableColumnHeaders(), equalTo(ExpectedTableHeaders));

        /**
         * Add an objective-check field population.
         */
        objectiveEvaluationPage.selectVariable(normalVariableLabel1Contains);
        objectiveEvaluationPage.selectTest(twoSampleTTest);
        objectiveEvaluationPage.selectStatistic(pValueContains);
        objectiveEvaluationPage.selectGroupingComparison(groupLabel2VSgroupLabel3);
        objectiveEvaluationPage.selectOperator(lessThanLogic);
        objectiveEvaluationPage.enterValue(objectiveValue);
        objectiveEvaluationPage.enterSimpleLabel(objective1Label);
        objectiveEvaluationPage.clickAddButton();

        /**
         * Check that the added objective is added to the table.
         */
        assertThat(objectiveEvaluationPage.getTableColumnEntry(ExpectedTableHeaders.get(0), objective1Label), equalTo(objective1Label));
        assertThat(objectiveEvaluationPage.editButtonTableEntryDisplayed(ExpectedTableHeaders.get(1), objective1Label, ExpectedTableHeaders.get(0)), equalTo(true));
        assertThat(objectiveEvaluationPage.deleteButtonTableEntryDisplayed(ExpectedTableHeaders.get(1), objective1Label, ExpectedTableHeaders.get(0)), equalTo(true));

        /**
         * Navigate back to the project dashboard.
         */
        objectiveEvaluationPage.clickCurrentProjectBreadcrumb();
    }

    @AfterClass
    public void tearDown(){
        driver.quit();
    }
}
